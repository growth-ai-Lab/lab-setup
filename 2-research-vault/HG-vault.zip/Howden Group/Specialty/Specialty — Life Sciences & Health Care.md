---
title: Specialty — Life Sciences & Health Care
type: knowledge-base
tags: [company, howden, specialty, life-sciences, health-care, clinical-trials, deep-dive]
crawled: 2026-07-10
source: howdengroup.com/uk-en/health-care/life-sciences-insurance
---

# Specialty — Life Sciences & Health Care

Part of [[Specialty Overview (Flexability)]]. Designs programmes across multiple legal/
regulatory jurisdictions. Key contacts: Richard Kelly (Exec Director), Luke Giles, Calum Bird.

## Stats
- **170 countries served**; **£90m+ premium** under management; **25 years' experience**.
- Panel of life-science claims lawyers with **40+ years combined** experience.
- Only uses minimum **A-rated** insurers.

## Sub-sectors covered
Pharmaceuticals; medical devices (invasive & non-invasive); biotechnology; cosmetics;
nutraceuticals & botanicals; veterinary products; universities; clinical research
organisations / trial sponsors / contract R&D; stem cells & tissue banks; **cannabis,
e-cigarettes & CBD**; vaccines; **psychoactive therapies**.

## Products
Products liability; professional liability; **MedTech Errors & Omissions**; public
liability; medical malpractice; employers' liability; **clinical trials cover**; vet
product cover. Can bundle into a package with a single renewal date / single contact.
Adjacent: Accident & Health, Product Recall (see [[Products & Services]]).

## Positioning
Emphasis on getting **initial claim notification right** (traceability); specialist
claims handlers; will leverage capacity to design bespoke cover for unlisted exposures.

## Ideation hooks
Emerging-therapy cover (psychedelics/psychoactive therapies, cell & gene therapy,
cannabis/CBD); clinical-trial parametric or portfolio structures; MedTech + AI/software-
as-a-medical-device E&O. Links [[Product Innovation & Ideation]].
