---
title: Specialty — Natural Resources & Energy
type: knowledge-base
tags: [company, howden, specialty, natural-resources, energy, deep-dive]
crawled: 2026-07-10
source: natural_resources_construction_apac_digital.pdf
---

# Specialty — Natural Resources & Energy

Part of [[Specialty Overview (Flexability)]]. "Everything you need under one roof"
across upstream, midstream, downstream, distribution, power, mining, sustainable energy
and energy transition. Global P&L across **London, Dubai and Singapore**.

> [!warning] **Scope: figures below are from the Asia Pacific capability report** (Singapore-
> based Howden Specialty APAC). They describe the **APAC hub**, not the **London HQ core** or
> global totals — even where the doc notes a "Global P&L across London, Dubai and Singapore."
> London is the principal market ([[Specialty Lines (Global)]]); the occupancy/product lists
> are broadly representative of the line, but the numbers are region-specific.

## Headline stats (APAC brochure)
- **US$1.2bn+** premium handled annually; **US$1.25bn** total claims collected over 4 years.
- **95 specialists**, **750+ clients**, **250+ specialist markets**.

## Sub-practice detail

### Power generation
Serves IPPs, state-owned utilities, lenders, PE houses (revenue via PPA or spot).
"Lloyd's market's largest income provider." Occupancies: thermal, gas, nuclear,
(ultra)supercritical, PCC/FBC, open/combined cycle & co-gen, base-load/peaking,
contracted/merchant, carbon capture & storage, transmission & distribution, substations.
Team: 30+ specialists, >280 GW under management, >US$300bn values, >US$300m premium.

### Upstream energy
Control of well / operators extra expense; operators/non-operators; platforms; FPSOs;
pipelines; subsea architecture; offshore construction. Team: 25+ specialists, 130+
clients, >US$150bn values, >US$100m premium.

### Midstream, Downstream & Mining (MDM)
Refining/petrochemical/chemicals; fertilizer; tank farms & terminals; mining (open-pit/
underground); biofuel/pyrolysis; LNG (liquefaction/regas); gas processing; pipelines.
Team: 20+ specialists, 100+ (incl. 8 NOCs & energy majors), >US$850m values (note:
brochure figures), >US$200m premium.

### Sustainable energy
On/near/offshore wind; hydro (impoundment, diversion, pumped storage); biomass;
subsea cables & interconnectors; concentrated solar + ground/rooftop/floating solar;
geothermal (dry steam/flash/binary); battery energy storage systems (BESS). Team: 30+
specialists, 100+ clients, >US$500m premium.

### Energy transition (dedicated director)
On/offshore **carbon capture & storage (CCS)**; **blue & green hydrogen** value chain;
**Voluntary Carbon Markets (VCM)** / carbon trading; carbon-credit-associated risks.
Innovative covers: **warranty backstop, new-technology cover, proxy revenue swap**.
Team: 40+ specialists, >US$400m values, >US$130m premium.

## Cover types
Full suite of construction, operational & liability covers; property damage + machinery
breakdown + BI; environmental liability; professional indemnity; marine hull + cargo;
delay in start-up / advanced loss of profits; control of well.

## Ideation hooks
Energy-transition is the richest whitespace: CCS leakage, hydrogen chain, BESS fire/
degradation, VCM integrity, proxy revenue swaps (parametric-adjacent). Links to
[[Sustainability & Social Impact]] and [[Product Innovation & Ideation]].
