---
title: Specialty — Cyber
type: knowledge-base
tags: [company, howden, specialty, cyber, financial-lines, deep-dive, insights]
crawled: 2026-07-10
source: howden-2025-cyber-report-rebooting-growth.pdf; 2024 cyber report; group insights
---

# Specialty — Cyber

Part of [[Specialty Overview (Flexability)]] and [[Sector Insights & Thought Leadership]].
Cyber is one of Howden's flagship research lines (annual global report). Global Head of
Cyber: Adam Codrington; Shay Simkin (Chair, Global Cyber); Jean Bayon de La Tour (Head,
International). Research led by Julian Alovisi (Head of Research).

## Product / proposition
- Standalone cyber policies bundling **loss coverage + proactive risk management +
  incident response** (forensics, legal, PR) as standard.
- **Cyber+** — Howden's productised offering launched 2024; grew **3x the broader
  market**, principally by improving SME access and transforming the buying journey.
- Aim: close the "cyber protection gap" (a societal issue, ~€300bn European cost since 2020).

## 2025 report ("Rebooting growth") — market state
- Market at an **inflection point**: global rates down **22%** from mid-2022 peak (still
  103% above pre-hard-market); exposure base not expanding fast enough.
- Global combined ratios averaging **70%**; **~US$9bn** underwriting profit 2022–24.
- Topline growth slowed to **6% CAGR** (2022–24) from **~40% CAGR** (2020–22).
- **US vs international divergence:** international rates −12% since early 2024 (low-to-mid
  teens reductions); US stabilising (privacy claims, biometric/pixel-tracking lawsuits).
- To hit ~US$20bn premium by 2027, insurers must grow exposures **~15%/yr**, mostly new
  business — reinsurance capacity ample.

## Threat landscape
- Ransomware incidents up every year since 2022; cumulative activity **+108% (2022–24)**.
- 2025 drivers: Cl0p mass-exploitation, Scattered Spider attacks on UK/US firms,
  supplier/third-party compromise via social engineering; Microsoft SharePoint (400+
  firms), Salesloft Drift (700+ firms).
- Progress: attacks stopped before encryption rose from **27% (2024) to 44% (2025)**.
- Mean recovery cost ~**US$1.5m** in 2025 (−45% YoY) on top of ransom.
- Business interruption = up to **70%** of claims cost for system-dependent firms (2024 report).
- ~90% of tracked attacks (Apr 2023–Mar 2024) politically motivated (2024 report).

## Europe opportunity (2025 report focus)
- **€307bn** estimated cost of attacks across DE/FR/IT/ES 2020–25; 49% of firms attacked.
- Penetration low: France/Germany/Spain 29%, Italy 22%, vs UK 39%.
- Matching US penetration could unlock **€1.2bn** additional premium across the four.
- **19% ROI** from cyber insurance for a €500m-revenue firm (≈€16m saved over 10 yrs).
- 41% of >€500m-revenue firms plan first-time purchase within 5 years; 45% of
  non-buyers "don't see the need" (education gap).
- Basic cyber hygiene (patching, strong passwords, email filtering) cuts attack
  frequency >1/3 and severity up to 87%.

## Ideation hooks
Embedded/on-demand incident response for SMEs; parametric cyber (cloud outage — see
[[Products & Services]]); penetration plays in underserved regions; premium-incentive
models tied to hygiene; systemic/aggregation and long-tail privacy solutions. Links
[[Product Innovation & Ideation]].
