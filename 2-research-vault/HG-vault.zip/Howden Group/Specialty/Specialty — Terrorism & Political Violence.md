---
title: Specialty — Terrorism & Political Violence
type: knowledge-base
tags: [company, howden, specialty, terrorism, political-violence, deep-dive]
crawled: 2026-07-10
source: howden_specialty_terrorism_political_violence_non_us_brochure_2024update.pdf
---

# Specialty — Terrorism & Political Violence (T&PV)

Part of [[Specialty Overview (Flexability)]]. One of Howden's most developed specialty
lines, with proprietary facilities and MGA authority.

## Team stats
- Places **US$100m+ premium** into the market per annum.
- Writes worldwide business ranging **US$1m to US$250bn** in size.
- **Widest appetite in industry — no minimum premiums.**
- Dedicated claims teams with **15+ years** T&PV claims experience.
- Fast turnaround: **1–48 hours** via key facilities.

## Core perils (standalone T&PV)
Sabotage; Terrorism; Strikes, Riots & Civil Commotion (SRCC); Malicious Damage;
Insurrection/Revolution/Rebellion; Mutiny and/or Coup d'État; War and/or Civil War;
Business Interruption / Contingent BI.

## Ancillary perils
Third-Party Terrorism Liability (can include employees' liability); Nuclear/Chemical/
Radioactive/Biological; Physical Damage following a Cyber-attack (from sabotage/
terrorism/malicious acts); Threat; Loss of Attraction / Non-Damage BI; Event
Cancellation; Looting following an insured peril; Active Assailant.

## Sub-products
- **Standalone terrorism & PV** — modular; perils can be bought individually.
- **SRCC standalone** — bespoke cover as all-risk insurers strip out/penalise SRCC;
  any occupancy (retail, offices, transport hubs, heavy industrial); can combine with
  Sabotage & Terrorism for better pricing.
- **Active Assailant** — fills the gap where an attack isn't legally "terrorism";
  triggers on a physical attack using a weapon (explosive, handheld, vehicle,
  corrosive substance). Covers: legal liability, property damage, BI, loss of
  attraction, bodily injury/death benefit, special coverage (PR consultancy,
  relocation, medical, counselling).
- **Cyber Attack** (physical damage) — bridges cyber-exclusion gaps; covers physical
  damage + consequential BI following an attack targeted at the insured via sabotage/
  terrorism/malicious act. **Exclusive facility up to US$295m capacity** from London
  markets; aggregated or non-aggregated; deductibles mirror property AOP.

## Market context / capacity
- Standalone terrorism market now has **>US$3bn** standalone capacity worldwide
  (vs. difficulty securing US$100m post-9/11).
- SRCC incidents since 2015 already **double** the prior decade's total.
- Terror methodology shifting to "lone wolf" events; 540 US mass shootings in 2022.

## Wordings (fixed market wordings)
- **LMA 3030** — Sabotage & terrorism only.
- **LMA 3092** — Sabotage & terrorism + riots, strikes, civil commotion & malicious damage.
- **LMA 5039** — Business interruption wording (if purchased).
- **AFB full political violence wording** — adds insurrection, revolution/rebellion,
  mutiny/coup, war & civil war.
- Can also cover "follow form / local wordings"; wordings amendable to client needs.

## Target sectors for political violence
Hotels, offices, pipelines, retail, manufacturing facilities, construction projects,
airports, market places, restaurants/bars/nightclubs/casinos, public transport, banks,
refineries, mining. (Note: businesses can be caught in events without being targeted.)

## Underwriting info needed to quote
Specific location(s); perils required; asset/occupancy; loss record; ownership;
security details; deductible level; target premium (if available).

## Distribution model
Coverholder (MGA) status offered to clients using Howden's key markets — authority to
quote/bind without referral to underwriters (streamlines volume business).

## Ideation hooks (see [[Product Innovation & Ideation]])
Cyber-physical convergence (the Cyber Attack facility is a template); parametric/rapid
payout on unrest indices; non-damage BI / loss of attraction; drone/emerging-methodology
terror cover flagged by Howden as "tomorrow's attacks."
