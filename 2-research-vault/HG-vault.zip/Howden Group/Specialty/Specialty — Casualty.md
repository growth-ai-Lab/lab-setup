---
title: Specialty — Casualty
type: knowledge-base
tags: [company, howden, specialty, casualty, liability, deep-dive]
crawled: 2026-07-10
source: howdengroup.com/uk-en/product/casualty
---

# Specialty — Casualty

Part of [[Specialty Overview (Flexability)]]. Broad liability division serving an
"increasingly litigious and socially aware world."

## Stats
- **90+ specialists**; **100+ client territories**; **US$1bn+ premium** placed annually.
- Team works in French, German, Portuguese, Spanish and English (international emphasis).

## Product lines
- **International Liability**
- **North American / US Liability**
- **UK Liability** (Public & Employers' Liability)
- **Accident & Health**
- **Product Recall** (see also [[Products & Services]])
- **Life Sciences** (see [[Specialty — Life Sciences & Health Care]])
- **Clinical Trials**

## Positioning
Cross-industry expertise to manage micro-to-macro change in operations & supply chains
(pandemic, political unrest, economic instability); multilingual teams for long-term
client/market partnerships.

## Ideation hooks
Supply-chain / systemic-liability products; US casualty (social inflation) analytics-led
pricing; casualty MGA (the group runs a "Casualty MGA USA" per [[Specialty Overview (Flexability)]]);
product-recall + parametric triggers. Links [[Product Innovation & Ideation]].
