---
title: Specialty — Financial Lines & D&O
type: knowledge-base
tags: [company, howden, specialty, financial-lines, directors-officers, deep-dive, insights]
crawled: 2026-07-10
source: Howden D&O Insurance Trends Report 2026 ("Fair Winds")
---

# Specialty — Financial Lines & D&O

Part of [[Specialty Overview (Flexability)]] and [[Sector Insights & Thought Leadership]].
Financial Lines spans Cyber ([[Specialty — Cyber]]), Professional Indemnity, Financial
Institutions, D&O, M&A ([[Specialty — M&A & Transactional Risks]]), Restructuring &
Resolution, Crime & Fidelity. Leadership: Lianne Gras (Global Head of D&O); Nick Chubb
(Head of Financial Lines). Data via Howden Financial Lines Group.

## D&O 2026 report ("Fair Winds") — market view
- Buyers' market continues: **premium reductions persisted through 2025**, but rates are
  **bottoming out** — more policies renewing "as expiry" in H2 2025; small US Public D&O
  rate uptick emerging.
- Insurers recalibrating: portfolio consolidation and appetite shifts (e.g. Markel
  Bermuda consolidated into London; Volante closed its book; Antares direct exit → facility-only;
  Allianz reviewing staffing). Brokers also trimming (e.g. Price Forbes) amid "wage-flation."

## Four key trends flagged
1. D&O premium declines **slowing** — market bottoming out.
2. **AI, cyber, and private credit** driving a new wave of claims.
3. **Securities class actions & derivative claims surging** — esp. tech, biotech, AI-linked sectors.
4. New UK legislation **(Economic Crime and Corporate Transparency Act — ECCTA)** creates
   fresh director liability (fraud-prevention / governance standards).

## Coverage emphasis
Report stresses cover **beyond price** — full spectrum of exposures: securities claims,
derivative claims, fraud-prevention/governance liabilities, cyber & AI-linked exposures,
private-credit concerns. Regional spotlights: Europe, Middle East, Latin America, Australia.

## Related financial-lines products
- **Professional Indemnity** — incl. construction & property consultants, financial
  consultants; 2026 insight: five trends reshaping risk for financial advisers; PI
  training modules for the legal profession.
- **Financial Institutions**, **Management Liability**, **Crime**, **Investment Risk**,
  **Intellectual Property** (see [[Products & Services]]).

## Ideation hooks
AI-liability / model-risk cover (named claims driver); private-credit risk products;
governance/ECCTA-linked director protections; derivative-claim defence facilities.
Links [[Product Innovation & Ideation]].
