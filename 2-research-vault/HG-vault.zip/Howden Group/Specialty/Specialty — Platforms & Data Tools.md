---
title: Specialty — Platforms & Data Tools
type: knowledge-base
tags: [company, howden, specialty, technology, platforms, data, cap]
crawled: 2026-07-10
source: Research export + howdengroup.com CAP pages
---

# Specialty — Platforms & Data Tools

Part of [[Specialty Overview (Flexability)]]. Proprietary digital platforms, chiefly in
Howden CAP (Credit & Political Risk). These are **revenue-relevant** assets — they
generate placement volume and defensibility (see [[Core Revenue vs Marketing (Assessment)]]).

## Tepfin (Howden CAP)
- Web-based **trading platform for Structured Credit & Political Risk Insurance**, built
  for high-volume business; free for clients to access.
- Launched **2004**; Howden states it has facilitated **3,000+ transactions**, traded
  **US$8bn+ of capacity** across **71 countries and 150+ obligors**.
- **Lloyd's-accredited** (1 Oct 2018) as an approved e-trading platform for Credit and
  Contract Frustration business — Howden says the **first broker-owned platform** to be accredited.

## Dynamite (Howden CAP)
- Data-management system for Structured Credit & Political Risk Insurance; paired with
  Tepfin as CAP's digital innovations.

## HX (group data/analytics)
- Historically the group's "data, digital and analytics business" (2021). Its current
  status/branding after the 2023 single-brand reorganisation is unclear (see
  [[Research Gaps & Contradictions]]). Referenced in [[Product Innovation & Ideation]]
  and [[Specialty — Construction]] (Cat-Kit nat-cat tool).

## Howden OS
- Group-level proprietary tech/data operating system (see [[Company Overview]],
  [[Product Innovation & Ideation]]).

Related: [[Specialty — Credit & Political Risk]], [[Product Innovation & Ideation]]
