---
title: Specialty — Fine Art & Specie
type: knowledge-base
tags: [company, howden, specialty, fine-art, specie, jewellery, deep-dive]
crawled: 2026-07-10
source: howdengroup.com/uk-en/fine-art-and-specie
---

# Specialty — Fine Art & Specie

Part of [[Specialty Overview (Flexability)]]. Lloyd's of London broker. Global Leader:
Barry Vickery.

## Stats
- **40+ specialists**; **US$100m** premium placed; **1,500 clients**; **400 claims/yr** settled.

## Core coverage
- **Fine art** — comprehensive All Risks for collectable items.
- **General specie** — precious metals, securities, cash, and **cryptocurrencies**.
- **Jewellery & gemstones** — solutions across industry operations.
- **Cash in transit** — All Risks physical loss/damage for cash, precious metals,
  valuables, at rest or in transit.

## Adjacent expertise offered
Professional indemnity; political risk; political violence incl. terrorism; crime
bonds; cyber risk; defective title; business interruption; UK & European buildings and
liabilities; global buildings capacity for high-net-worth homes.

## Structuring
Direct or reinsurance (facultative or treaty); extensive captive experience; can
arrange binding authorities on behalf of producing brokers / MGAs.

## Ideation hooks
Crypto/digital-asset custody & specie convergence (links [[Products & Services]] digital
assets); HNW private-client bundling; defective-title + art; parametric transit cover.
Links [[Product Innovation & Ideation]].
