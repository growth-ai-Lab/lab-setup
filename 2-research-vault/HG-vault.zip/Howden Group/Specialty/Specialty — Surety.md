---
title: Specialty — Surety
type: knowledge-base
tags: [company, howden, specialty, surety, bonds, guarantees, deep-dive]
crawled: 2026-07-10
source: howdengroup.com/uk-en/cover/surety
---

# Specialty — Surety

Part of [[Specialty Overview (Flexability)]] / Capital Advisory & Placement; adjacent to
[[Specialty — Credit & Political Risk]].

## What surety is
A tri-partite obligation where an insurer (the **Surety**) guarantees the contractual/
commercial obligations of a **Principal** to a **Beneficiary**, paying monetary
compensation if the Principal fails to perform. A **counter-indemnity** from the Principal
(and potentially parent) lets the Surety seek reimbursement on a paid claim.

## Stats
- **130 years' combined experience**; **£20bn+ bonds placed** worldwide; **40 countries**.

## Types of surety bonds
Performance bonds; advance payment guarantees; retention bonds; warranty bonds; LGPS
(local government pension scheme) bonds; PPP/PFI; pension-deficit guarantees;
**decommissioning bonds (oil & gas, mining)**; captive retention guarantees; land-purchase
guarantees (developers); travel bonds; Rural Payment Agency guarantees; Environment
Agency guarantees; appeal bonds; Section guarantees (developers); customs/import guarantees.

## Industries
Automotive, chemical, commodities, construction, electronics, engineering, food,
importers, IT services, machinery/equipment manufacturers, metal, mining, outsourcing,
retail, shipbuilding, telecommunications, travel, transport, waste.

## Why insurer-issued surety > bank surety
Bank bonds reduce credit headroom and limit growth; **insurer surety is generally
unsecured** (based on financial strength/track record), does not impact working capital
or bank facilities → boosts liquidity.

## Service benefits
Competitive pricing; market influence/buying power; bespoke solutions for complex deals;
local/regional/global facilities; access to all major providers; **syndication** of
multiple capacity for large bonds; market-leading bond/contract document analysis; full
facility administration.

## Ideation hooks
Decommissioning & environmental bonds (energy transition, links
[[Specialty — Natural Resources & Energy]]); surety expansion in a softening cycle
(per [[Specialty — Credit & Political Risk]]); ESG/green-project performance bonds;
digitised bond issuance. Links [[Product Innovation & Ideation]].
