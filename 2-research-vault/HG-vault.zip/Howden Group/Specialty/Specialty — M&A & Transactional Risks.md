---
title: Specialty — M&A & Transactional Risks
type: knowledge-base
tags: [company, howden, specialty, m-and-a, w-and-i, tax, title, environmental, deep-dive]
crawled: 2026-07-10
source: howden-m-and-a-2025-annual-review.pdf (FY2024 data)
---

# Specialty — M&A & Transactional Risks

Part of [[Specialty Overview (Flexability)]] and [[Business Segments]]. Howden M&A works
with the world's largest investors/advisors; specialists from law, banking, investment
management, tax, corporate advisory and insurance. 170+ experts across 15 countries
(UK, Europe, Asia); single Howden M&A structure & balance sheet for cross-border deals.

## FY2024 numbers
- **1,462 policies** placed across **872 deals** (policy count +43%, deal count +23% YoY).
- **€21.3bn** total W&I policy limit placed; **€131bn** aggregate enterprise value advised.
- **133** successful $1bn+ deals since 2014.
- Record **€190m+** in paid claims in 2024; claim notifications +14% (after +58% in 2023).

## Product suite

### Warranty & Indemnity (W&I) — largest line
Majority of policies. Trend: **synthetic warranties** shifting from last-resort to a
strategic deal tool (competitive auctions, single or full synthetic suites); broadening
cover as pricing softens; new use cases in loan-portfolio transactions, debt sphere, and
secondaries.

### Tax & Contingent Risks
~**£200m GWP** placed in 2024 (up from £102m in 2023, £44m in 2022); ~£8bn policy limit
(>£4bn in Q4 alone). Policies with limits >£500m, including a single ~£1bn tax policy.
Demand rising; pricing at all-time low.

### Title & Specific Risk
Largest dedicated title team in the M&A market. ~**300 policies in 2024 across 19
jurisdictions**. Drivers: real-estate financing (portfolio title policies), Certificate
of Title top-ups, renewables/data-centre/logistics developments (esp. Poland, Romania,
Italy, France, Portugal, Spain, Netherlands).

### Environmental Risk
Broadening scope — secured cover for **known PFAS contamination** (once uninsurable).
Rates: 3–4% for larger/higher-risk portfolios; as low as 0.3–0.8% for some sites. Moving
beyond pollution/contamination into wider **ESG / biodiversity** liabilities, incl.
outside the M&A context (asset owners reacting to existing-business liabilities).

### Transactional Diligence
- **Insurance Due Diligence** — rise in carve-outs and complex multi-jurisdictional deals.
- **Lenders' Insurance Advisory (LIA)** — launched 2023; 2024 financings across Europe &
  Africa >£3.5bn; PPPs, refinancings, restructurings; solar PV, onshore/offshore wind;
  growing data-centre demand from AI.

## Deals-by-sector (operational, 2024)
Manufacturing & Industrial 26%; Tech/Media/Telecoms 24%; Financial & Professional
Services 22%; Energy & Infrastructure 11%; Consumer 8%; Healthcare & Pharma 8%; Education 1%.
Real-estate mix: industrial & logistics 23%, hotels 16%, residential 13%, retail &
hospitality 9%, office 8%, land 6%, data centres 3%, healthcare 1%, mixed-use 21%.

## Pricing (rate on line, 2024)
Operational: Europe ~1.0%→0.9%; UK 0.95%→1.05% (diverged up on higher activity).
Real estate: UK 0.8%→0.7%; Europe 0.65%→0.55%.

## Claims insight
Financial-statement breaches = 56% of paid claims; tax 22%; information 7%; compliance
7%; material contracts 4%; fundamental warranties 4%. Largest W&I claim €120m (Schur
Flexibles/B&C, Austria); largest title claim €25m. Netherlands highest paid-claim
jurisdiction (24%). Seller-fraud claims tend to exceed policy limits.

## Ideation hooks
Synthetic-warranty productisation; PFAS/biodiversity/ESG liability outside M&A; title for
novel asset classes (data centres, renewables); AI/data-centre financing risk; W&I
extensions into debt & secondaries. Links [[Product Innovation & Ideation]].
