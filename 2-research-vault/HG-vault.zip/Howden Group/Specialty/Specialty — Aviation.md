---
title: Specialty — Aviation
type: knowledge-base
tags: [company, howden, specialty, aviation, aerospace, deep-dive]
crawled: 2026-07-10
source: howdengroup.com/uk-en/industry/logistics/aviation
---

# Specialty — Aviation

Part of [[Specialty Overview (Flexability)]]. London-based team with direct access to
world aviation insurance markets. Global Head of Aviation: Jason Humphreys.

## Client base
Whole aviation industry: aircraft owners, operators, service providers, manufacturers,
and airports.

## Positioning
- Industry's leading specialist aviation brokers.
- **In-house design & delivery of cutting-edge insurtech.**
- Custom solutions with minimum turnaround time.
- High-value, catastrophic-loss-exposed industry needing innovative, cost-competitive,
  individually tailored solutions.

## Service scope
Optimised placement structures; contractual advice; policy wordings; local regulation
compliance; **e-certificate production**; exemplary claims handling.

## Related lines
Aviation liabilities and aviation hull sit within the Logistics/Transportation grouping
(see [[Specialty — Marine & Cargo]] and [[Products & Services]]).

## Ideation hooks
Insurtech-enabled placement/e-certificates as a product; parametric aviation
(weather/delay); space-adjacency (links [[Specialty — Marine & Cargo]] pre-launch space,
and the group Space practice in [[Industries & Capabilities]]); eVTOL/drone/UAM emerging
cover. Links [[Product Innovation & Ideation]].
