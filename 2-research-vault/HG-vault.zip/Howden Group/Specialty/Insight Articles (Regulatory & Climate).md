---
title: Insight Articles (Regulatory & Climate)
type: knowledge-base
tags: [company, howden, insights, regulatory, climate, esg, articles]
crawled: 2026-07-10
source: howdengroup.com/uk-en/news-insights (rendered via browser)
---

# Insight Articles (Regulatory & Climate)

Part of [[Sector Insights & Thought Leadership]]. Full text of three client-rendered
"latest insights" articles, captured via the browser on 2026-07-10.

## 1. Carbon borders & competitiveness — CBAM (04 Jun 2026)
Author: Mike Cork (Director, Advisory & Client Solutions – Energy Transition).

- Thesis: trade is being "re-priced" by carbon and compliance; EU/UK seen as stable,
  rules-based markets, but access requires CBAM compliance.
- **EU CBAM in force Jan 2026; UK CBAM Jan 2027.** Similar objectives, differing structure/
  scope; linking negotiations early — manage separately for now. Some sectors: every
  importer impacted regardless of volume; others have a threshold.
- Covered hard-to-abate sectors: **cement, iron & steel, aluminium, fertilisers,
  hydrogen, electricity**. Cost = **embedded emissions** → lower emissions = lower cost =
  competitive advantage. Importers hold legal obligation; commercial pressure on producers.
- First step: **get emissions data right** (verified actuals beat default values + markup).
- Levers: energy efficiency, fuel switching, electrification; but process emissions are
  irreducible for some — **cement process emissions ≈60–65% of CO₂** → need **CCS**.
- Under EU CBAM, **CCS directly reduces verified embedded emissions** if storage is
  permanent and independently verifiable.
- **Hub-and-cluster CCS** (shared transport/storage infra) makes large-scale CCS viable;
  complex cross-value-chain risk → "new and innovative insurance approaches essential."
- Howden + **Energex** paper: *"Closing the risk gap"* (cross-CCS value-chain risk).
- Howden role: risk engineers/advisory from early solution development through
  construction to operations; identify/quantify/allocate cross-chain risks. Links
  [[Specialty — Natural Resources & Energy]].
- Note: draft EU rules may recognise international credits as carbon cost paid outside EU
  (undecided as of May 2026).

## 2. CSRD Omnibus — what SMEs need to know (01 Jun 2026)
Author: Lukas Brochard (Decarbonisation & ESG Lead).

- **Omnibus** narrows CSRD scope from **~45,000 to ~10,000 companies**; simplifies ESRS;
  in force **18 Mar 2026**. "Out of scope ≠ out of risk."
- New thresholds (both required): **>€450m net turnover AND avg >1,000 employees**;
  in-scope firms report from **FY2027**. "Wave one" firms continue FY2025 & FY2026 (may be
  exempted later if below thresholds).
- **"Protected undertakings"** = <1,000 employees + in a reporting company's value chain →
  can report voluntarily without verification and refuse requests beyond voluntary standards.
  "Value-chain cap" limits disproportionate data requests. Protection does NOT override
  due-diligence, financing, or risk-management information requests.
- Voluntary standards: delegated act by **19 Jul 2026**, based on **VSME** (Voluntary SME
  Standard); **Basic** and **Comprehensive** modules (fewer data points than ESRS).
- Why SMEs should still report: climate risk = financial risk (ECB/BoE); **ECB fined banks
  in Spain (2024) and France (2025)** for climate-disclosure failures; supports access to
  capital and insurance; TCFD/ISSB frameworks; supplier-bid competitiveness.
- Market stat: **physical-risk insurance premiums projected +~50% by 2030**; in 2024
  **60% of losses (~$223bn) were uninsured** (climate protection gap).
- Howden role: align to TCFD, resilience/continuity, insurance-access advice, decarbonisation-
  linked insurance products. Links [[Sustainability & Social Impact]].

## 3. Professional indemnity 2026 — five trends for financial advisers (01 Jun 2026)
Authors: Jack Scully (Claims Executive), Barnaby Rowland (Claims Handler).

Five PI claims trends:
1. **Ongoing adviser charges & annual reviews** — rising notifications; FCA review found
   2% of sampled customers had no annual-review contact in 7 years; claims-management
   companies advertising fee complaints (low loss, high investigation time).
2. **Vulnerable customers** — FCA fair-treatment guidance (2021, reviewed Mar 2025);
   hidden vulnerabilities (cognitive decline, mental health); risk on equity release & DB
   transfers.
3. **Similar 2-yr vs 5-yr mortgage rates** — human-error complaints where client placed on
   wrong term (early repayment charges, higher interest).
4. **Use of AI** — speed vs accuracy risk; AI-vs-adviser contradictions prompting
   complaints; FCA "technology-neutral" (relies on existing frameworks).
5. **FOS interest-rate amendment** — from 1 Jan 2026, redress interest cut from 8% to
   **1% above average BoE base rate** (8% can still apply for late payment).

Mitigation themes: governance & oversight — service-proposition reviews, vulnerable-
customer frameworks, file-checking/QA, audit trails, AI governance, monitoring FOS/
regulatory change, early broker/insurer engagement. Links [[Specialty — Financial Lines & D&O]].
