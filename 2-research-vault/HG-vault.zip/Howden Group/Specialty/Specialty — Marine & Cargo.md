---
title: Specialty — Marine & Cargo
type: knowledge-base
tags: [company, howden, specialty, marine, cargo, logistics, deep-dive]
crawled: 2026-07-10
source: marine_cargo_apac_digital.pdf
---

# Specialty — Marine & Cargo

> [!warning] **Scope: this note is sourced from the Asia Pacific capability report**
> (Howden Specialty Asia Pacific Pte. Ltd., Singapore-regulated). The team sizes, premium,
> policy counts and facility limits below describe the **APAC hub**, not the **London HQ
> core** or global totals. London is the principal market (see [[Specialty Lines (Global)]]
> and [[Global Footprint & Locations]]); treat these figures as region-specific until
> London/global marine figures are separately sourced.

Part of [[Specialty Overview (Flexability)]]. Marine team spans London, Europe, Middle
East and APAC, placing into Lloyd's, London and international markets. Shared divisional
balance sheet across offices.

## Marine (Hull & Liabilities)
Active sectors: subsea services, oilfield services, inland river tug & barge, vessel &
offshore construction, aquaculture, dredging/wet construction, offshore drilling,
liftboat operators, offshore supply vessels & workboats, bluewater operators, port
authorities & terminals, diving operations, commercial fishing.

**Products:** hull & machinery + ancillary interests; loss of hire / contingency / trade
disruption; mortgagees interest (+ additional perils); war risks; terrorism; cyber;
political risks; building/conversion risks; delay in delivery; onshore/offshore asset
physical damage; delegated authority.

**Liability lines:** programmes/agency reinsurance; primary marine liability; mutual P&I;
fixed-income P&I; maritime employers' liability; stevedores/wharfingers liability;
charterers liability; terminal operators/port authority liability; logistics/freight
forwarders liability; ship repairers liability; excess casualty (marine/offshore/onshore).
Team: 10+ specialists, 160+ specialist markets; supported by 20 dedicated marine claims specialists.

## Cargo & Stock Throughput
40+ team specialists; **$200m+ premium handled p.a.**; 3,000 cargo policies; 1,500+
claims annually; 11 cargo claims personnel. Broking teams in London, Singapore, Hong
Kong, Miami; embedded claims (London, Hong Kong) involved from program setup.

**Industries handled:** livestock, manufacturing, energy incl. power generation, mining
(ores/minerals), agricultural (soft commodities, cotton/grains), food & drink (fishing,
meat, poultry), pharmaceutical, commodity trading (incl. banks), consumer goods (incl.
retailers), **space (pre-launch)**.

**Products:** stock throughput; global programs; cargo war; terrorism; poultry & fishing
(bespoke, Lloyd's-lineslip-backed).

## Facilities (capacity)
- **Lloyd's lineslip** — limit US$50m any one loss/named location.
- **Company markets lineslip** — US$30m any one loss/location.
- **Non-complex binding authority** (100% Lloyd's security) — premium <US$75k/risk,
  limit US$10m any one loss/location.
- **Project Cargo (incl. delayed start-up)** — Lloyd's lineslip, US$200m (extra available).
- **Cargo war consortium** — US$100m (extra available).
- **Terrorism** — leader-only Lloyd's facility incl. stock, buildings, BI.

## Ideation hooks
Pre-launch space cargo; commodity-trade-disruption / trade-disruption parametric; war &
political-risk convergence (links [[Specialty — Terrorism & Political Violence]]);
delegated-authority/binder productisation for SME cargo.
