---
title: Specialty — Construction
type: knowledge-base
tags: [company, howden, specialty, construction, deep-dive]
crawled: 2026-07-10
source: Construction-Brochure-September-2022.pdf
---

# Specialty — Construction

Part of [[Specialty Overview (Flexability)]]. Positioned as a boutique-expertise +
large-international-power alternative to consolidated competitors. Global hubs: London,
Miami, Dubai, Singapore (+ Bermuda, Luxembourg); unique global P&L.

## Four construction types covered
Specialised Industrial Construction (oil refineries, process plants); Institutional &
Commercial Building (hospitals, retail, stadia, schools, skyscrapers, arenas);
Infrastructure & Heavy Construction (airports, tunnels, bridges, highways, ports,
pipelines); Residential (apartments, townhomes, city & rural).

## Cover across the project lifecycle
**Pre-construction:** design PI / contractual risk allocation; demolition GL; abortive
planning; legal indemnity (planning/title); bid bonds; site owners' pollution; existing
property.
**Construction:** performance/advance payment/retention bonds; professional indemnity;
Builders Risk / Erection "All Risks"; Delay in Start Up (DSU); general liability; goods
in transit / marine cargo DSU & contingent DSU.
**Post-construction:** property; business interruption; property owners' pollution;
public liability; latent/inherent defects (IDI); terrorism (standalone or TRIPRA/Pool
Re); O&M performance bonds; employers' liability / workers' comp / PA / travel; plant &
equipment; auto/motor; specialist cost-overrun; environmental impairment / contractors
pollution.

## Specialist teams
- **International** — power, oil & gas, mining, infrastructure; builders risk/EAR, DSU,
  inherent defects, plant & equipment, combined construction+operational, standalone
  terrorism, PI, casualty/GL.
- **UK Projects** — complex building, civils, utilities, transport; CAR, existing
  property, DSU, third-party liability, non-negligent indemnity (6.5.1), terrorism
  (Pool Re & standalone), contractual financial loss, inherent defects.
- **Inherent Defects Insurance (IDI)** — 20+ yrs at market forefront; new builds,
  residential (UK), mixed-use, commercial, civil, secondary IDI; innovator (mixed-use,
  civil, US/Europe expansion, PFI/PPP completed buildings).
- **Contractors** — annual & project-specific risk financing; all procurement methods
  (traditional → alliance contracting); one-stop-shop.
- **Contractor PI** — specialist (vs. generalist) approach; contractors provide
  professional + non-professional services needing tailored structuring.
- **Infrastructure Assets** — PPP/PFI/P3 "cradle to grave" (bid → construction →
  operational concession); portfolio solutions; blue light, bio-energy, defence,
  education, healthcare, social housing, student accommodation, transport, waste/
  wastewater.

## Data/tech edge
Works with **HX** (Howden's tech arm). Proprietary **Cat-Kit** nat-cat modelling tool:
models expected loss by return period and project phase, deductible exposure per phase,
across convective storm, earthquake, flood, windstorm, winter storm — informing limits/
deductibles and capacity sculpting.

## Strategic advice themes
Engage broker early (esp. hard market); adopt a global mindset (Bermuda, London, Dubai,
Singapore, China); high-quality underwriting information unlocks best terms.

## Ideation hooks
Nat-cat/parametric overlays for construction backlogs under climate change; portfolio/
PPP structures; IDI product extensions to new geographies; energy-transition
construction (links [[Specialty — Natural Resources & Energy]]).
