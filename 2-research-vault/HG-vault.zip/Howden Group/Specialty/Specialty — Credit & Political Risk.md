---
title: Specialty — Credit & Political Risk
type: knowledge-base
tags: [company, howden, specialty, credit, political-risk, cpri, surety, deep-dive, insights]
crawled: 2026-07-10
source: Howden's 2025 Credit and Political Risk Insurance Report ("Opportunity in flux")
---

# Specialty — Credit & Political Risk (CPRI)

Part of [[Specialty Overview (Flexability)]] and [[Sector Insights & Thought Leadership]].
Sits within Capital Advisory & Placement / Global Credit Solutions. Products: Political
Risks & Structured Credit, International Trade Credit, Surety/Bonds.

## 2025 report ("Opportunity in flux") — market view
- CPRI helps clients **trade and invest through elevated uncertainty** by protecting
  assets and **lowering cost of capital** on investments.
- **US$49bn premium base** across **six distinct product segments** (CPRI + surety) —
  surpasses most other specialty product lines.
- CPRI has **industry-leading underwriting results over the last decade**, resilient
  through pandemic, wars, commodity shocks, inflation.
- Premium growth **lags** other lines → room for faster growth; broader insurance cycle
  now **softening** → argues for increasing commitments and driving innovation.
- Themes analysed: intensifying geopolitical rivalries, trade/policy uncertainty,
  competition for **critical minerals**.

## Howden CAP — team & capacity (from research export)
Full name **Howden Capital, Advisory & Placement (CAP)**; the credit & political risk arm
folded into Specialty at the Oct 2023 reorganisation.
- **90+ professionals** (insurance, legal, banking, regulatory); political-risk/structured-
  credit team based in **London, Singapore, Dubai** (~30 experts, 300+ yrs collective), plus
  CAP offices cited in New York, Paris, Geneva.
- Manages a portfolio of **US$1bn+ of credit limits**; works with 50+ insurers.
- Stated capacity access: **Political Risk up to US$4bn** (tenors to 20 yrs); **Sovereign
  Non-Payment up to US$3.9bn** (to 15 yrs).
- Claims: **~US$500m+** client claims settled over ten years (Howden's claim).
- Covers expropriation, sanctions, embargoes, currency inconvertibility, political violence,
  terrorism, breach of contract.
- Platforms **Tepfin** and **Dynamite** → [[Specialty — Platforms & Data Tools]].
- Recognition: SCI Risk Sharing Awards Innovation of the Year 2024 & 2025 → [[Awards & Recognition]].

## Where it's used
Protecting cross-border trade and investment for corporates, banks/financial
institutions, commodity traders, and lenders — non-payment, expropriation, political
violence-linked asset risk, contract frustration, structured credit.

## Related lines
Trade Credit ([[Specialty — Marine & Cargo]] handles commodity trade too), Surety &
Performance Bonds, Structured Credit; overlaps with [[Specialty — Terrorism & Political Violence]]
on political-violence exposures.

## Ideation hooks
Critical-minerals / supply-chain resilience cover; structured-credit + parametric
triggers on geopolitical/trade indices; cost-of-capital-linked products for
energy-transition financing (links [[Specialty — Natural Resources & Energy]]);
surety expansion in a softening cycle. Links [[Product Innovation & Ideation]].
