---
title: Specialty Overview (Flexability)
type: knowledge-base
tags: [company, howden, specialty, deep-dive, products, overview]
crawled: 2026-07-10
source: specialty_overview_0711.pdf, marine_cargo_apac_digital.pdf, Construction-Brochure-September-2022.pdf
---

# Specialty Overview ("Flexability")

Part of [[Howden Group]] → [[Specialty Lines (Global)]]. Deep dive from the Howden
Specialty *Flexability* brochure and related PDFs. Model: *"Specialty expertise,
configured by you"* — clients assemble a bespoke team across specialties, markets and
regions; *"one line to the whole picture."*

## Scale (as stated in brochures; note vintage)
- **$27bn** premiums placed annually for clients (Flexability/T&PV brochures).
- **12,000+ Howden specialists**; **45 Howden territories**, extending to **100+
  territories / 20,000+ specialists** with Howden One Network.
- **150+ client territories**.
- Marine/cargo brochure cites **$10bn** premium placed into international markets via
  Specialty & Reinsurance broking, **11,000 specialists, 90+ territories**.
- Construction brochure (2022) cites **$14.5bn** premium into international markets,
  **9,000+ employees, 90+ territories**.

> [!note] Figures vary by brochure date; treat as directional. Newer group figures are
> in [[Company Overview]] / [[Financials]].

## Channels
Retail · Direct · Wholesale · Captive · Reinsurance · Binders/Facilities · MGA.
Delegated authority: master policies, binding authorities, lineslips, cross-class
programmes, underwriting facilities, treaty, casualty MGA (USA), global retro.

## The full specialty product matrix (grouped)
**Construction** — Onshore, Offshore, Contractors, Owners, Financiers, Developers.
**Natural Resources** — Upstream, Midstream, Downstream Energy; Mining; Power &
Utilities; Energy Liability; Sustainable Energy. See [[Specialty — Natural Resources & Energy]].
**Logistics/Marine** — Marine Hull, Marine Liabilities, Aviation, Cargo & Stock
Throughput, Protection & Indemnity (P&I), Yachts. See [[Specialty — Marine & Cargo]].
**Property** — North American, International, Public Entity & Infrastructure,
Terrorism & PV, Agriculture, Rural, Real Estate. See [[Specialty — International Property]].
**Casualty** — International Liability, US Liability, Product Recall, Life Sciences &
Clinical Trials, Accident & Health, Health & Care.
**Financial Lines** — Cyber, Professional Indemnity, Financial Institutions, D&O,
M&A, Restructuring & Resolution, Crime & Fidelity, Intellectual Property, Investment Risk.
**Capital Advisory & Placement** — Warranty & Indemnity; Tax; Title, real estate &
contingent risks; Environmental liability; Surety; Trade Credit; Political Risk &
structured solutions. See [[Specialty — M&A & Transactional Risks]].
**Fine Art & Specie** — Fine Art, Jewellers Block, Specie, Cash in Transit.
**Sport & Entertainment** — Sports Disability, Contingency, General Liability, Equine.
**Health & Care** — Specialist life science, Pharma/Bio/Nutraceutical liabilities,
Clinical trials.
**Global Credit Solutions** — Political Risks & Structured Credit, Trade Credit, Surety.

## Global hubs
London (HQ) · Bermuda · Singapore (APAC) · Luxembourg (Europe) · Dubai (DIFC) ·
Miami (LatAm/Caribbean). Unique **global P&L structure** so placement follows client
needs, not profit-centre silos. Detail in [[Specialty Lines (Global)]].

## Technology arm — HX
Howden's data/tech arm ("HX") turns data into analytics: actuarial risk assessment &
pricing, catastrophe modelling, exposure measurement, advisory (risk management /
capital deployment), research/thought leadership, business intelligence. Feeds
[[Product Innovation & Ideation]]. Example proprietary tool: **Cat-Kit** (nat-cat
modelling across a construction project lifecycle).

> [!important] **London is the principal hub / core offering.** The per-line deep dives for
> **Marine & Cargo, Natural Resources & Energy, and International Property** are sourced from
> **Asia Pacific capability reports** and carry APAC-region figures — see the scope warnings
> in those notes and the London-principal callout in [[Specialty Lines (Global)]]. Product/
> occupancy lists are broadly representative; the *numbers* in those three are region-specific.

## Per-line deep dives
- [[Specialty — Terrorism & Political Violence]]
- [[Specialty — Natural Resources & Energy]]
- [[Specialty — Construction]]
- [[Specialty — International Property]]
- [[Specialty — Marine & Cargo]]
- [[Specialty — M&A & Transactional Risks]]
