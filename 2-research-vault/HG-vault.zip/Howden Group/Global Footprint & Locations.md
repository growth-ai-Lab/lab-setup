---
title: Global Footprint & Locations
type: company-profile
tags: [company, howden, locations, geography, network]
crawled: 2026-07-10
source: howdengroup.com (region switcher), howdengroupholdings.com/about-us
---

# Global Footprint & Locations

Part of [[Howden Group]].

## Headquarters
**One Creechurch Place, London, EC3A 5AF, United Kingdom.**

## Reach
- **57 countries** with a direct presence (2026 figure).
- **115+ countries across 6 continents** including the partner network.
- **Howden One Network:** access to insurance problem-solving in **100–120+ territories**
  through one platform (launched 2017).

## Regions (as organised on the site)
- **Europe**
- **Asia Pacific**
- **The Americas** (incl. Howden Americas: US, Latin America & Caribbean)
- **Middle East & Africa**

## Country sites listed on howdengroup.com
**Europe:** Austria, Belgium, Denmark, Estonia, Finland, France, Germany, Greece,
Iceland, Ireland, Italy, Netherlands, Norway, Poland, Portugal, Spain, Sweden,
Switzerland, Turkey, United Kingdom.

**Asia Pacific:** Australia, New Zealand, Hong Kong, India, Indonesia, Japan,
Malaysia, Philippines, Singapore, Thailand.

**The Americas:** Brazil, Chile, Colombia, Mexico, Peru, USA.

**Middle East & Africa:** Bahrain, Israel, Morocco, Oman, Tanzania, UAE (plus Turkey).

## U.S. presence
Launched as full retail broker in 2025 (Atlantic Group + Gravitas). Within months:
**1,000+ colleagues and 50+ locations** across the U.S. US legal entity:
**Howden US Specialty LLC** (Delaware; licensed nationwide; CA dba Howden Specialty
Insurance Services).

## Corporate positioning
"Local expertise, global reach" — between local offices and a trusted partner network,
Howden serves multinationals needing a truly global broker and smaller businesses with
local needs.
