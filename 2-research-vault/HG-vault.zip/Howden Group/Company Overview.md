---
title: Company Overview
type: company-profile
tags: [company, howden, overview]
crawled: 2026-07-10
source: howdengroup.com/about, howdengroupholdings.com/about-us
---

# Company Overview

Part of [[Howden Group]].

## Identity
Howden is a specialist insurance broker that combines the strength of a global
broker with the personal touch of an employee-owned group. It describes itself as
**"the People First insurance group"** and, in its US positioning, as **the largest
independently-owned international retail insurance broker in the world**. The UK/about
page frames it as **"the largest European broker, serving clients all over the world."**

## Founding principle
Founded in **1994** by David Howden and friends on four themes: **trust, friendship,
employee ownership, and innovation**. Stated talent strategy: *"put our people first,
knowing that the P&L will follow."* Flat global structure with empowered local leadership.

## Ownership model
- **Employee-owned.** The largest shareholder group is the people who work in the business.
- Employees collectively own **more than 30%** of the company.
- Backed by **three long-term, minority growth-equity partners**: **General Atlantic,
  CDPQ / La Caisse, and Hg** — described as partners who share the vision to
  "build a business to last, one that will never be sold."
- Culture centred on an **"owner's mindset."**

## Corporate structure
- **Legal parent:** Howden Group Holdings Limited, registered in England & Wales,
  company registration number **2937398**.
- **Registered office / HQ:** One Creechurch Place, London, EC3A 5AF, UK.
- **London HQ phone:** +44 (0) 20 7623 3806.
- Formerly known as **Hyperion Insurance Group**.
- Operating brands: **Howden** (broking), **Howden Re** (reinsurance), **DUAL** (underwriting / MGA).

## Scale — headline figures (note the caveats)
Figures differ across pages because they were published at different times and count
different things (direct colleagues vs. experts vs. network reach):

| Metric | Value | Where stated |
|---|---|---|
| Premium under management | ~$38bn | Homepage / group about |
| People | 25,000+ "experts" | US "Our story", group about |
| People | 18,000 colleagues | group about-us narrative |
| Countries (direct) | 57 | US "Our story" (2026) |
| Countries (with network) | 115+ across 6 continents | group about |
| Global reach (network) | 100–120+ territories | Howden One Network |

> [!note] Treat headcount/country counts as approximate and dated. The lower
> "18,000" figure appears in older narrative copy; 2025–26 pages cite 25,000+.

## Positioning / differentiators
Five stated ways clients "see the Howden difference": **agile to the core**
(client-level decision-making), **unmatched talent**, **clients at the center**,
**shoulder to shoulder** (cross-industry/geography collaboration, no silos), and
**Howden OS** (proprietary tech & data operating system, free of legacy systems).
Additional themes: personally invested (employee ownership), freedom/autonomy to
do best work, and client-focused innovation.
