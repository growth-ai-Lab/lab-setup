---
title: Research Gaps & Contradictions
type: reference
tags: [company, howden, meta, gaps, method]
crawled: 2026-07-10
source: Research export (public sources)
---

# Research Gaps & Contradictions

Part of [[Howden Group]]. Imported from the cited research export's method note — the
known limits of the public record. Read alongside [[Sources]].

## Disambiguation
**Howden Joinery Group plc** (kitchens) and **Howden** (air/gas-handling engineering,
Chart Industries) are unrelated companies that dominate some searches — excluded here.

## Known gaps (as of 2026-07-01)
1. **CY2025 financial detail** — only headline figures public (£3.52bn adjusted; £4.23bn
   IFRS over the 15-month transition). No EBITDA/organic/divisional split. Primary source
   would be the Companies House filing (company 02937398).
2. **Howden Specialty financials** — revenue/headcount not broken out publicly.
3. **Specialty leadership split** — Sarah Hughes (CEO, Specialty since Oct 2023) vs
   Richard Haines ("Divisional CEO, Howden Specialty," 2026): division of responsibilities
   not publicly explained. (My vault credits Sarah Hughes in [[Leadership & Board]].)
4. **Board surnames** — some Key People entries retrieved only as first names.
5. **DUAL current GWP/leadership** — latest verified GWP ~£2.2bn (2021–22).
6. **HX (data/analytics unit)** — status after the 2023 single-brand reorg unclear.
7. **Clients/case studies** — minimal public client-level info (typical for broking).
8. **Awards** — no systematic trade-award sweep.
9. **Howden's response to US litigation** — no direct rebuttal captured ([[US Expansion & Litigation]]).
10. **S&P research update** — 'B' rating page exists; publication date not captured.

## Contradictions / inconsistencies
- **Headcount:** Howden's own pages state both **"19,000 experts in 55 countries"** and
  **"22,000 experts in 55 countries"** (different sponsorship pages, both live Jul 2026) —
  likely different vintages. (Elsewhere the site cites 18,000 / 25,000+ — see [[Company Overview]];
  treat all headcount/country counts as approximate and dated.)
- **Sarah Hughes' title** varies late 2025: "CEO, Specialty, Howden" vs "head of specialty
  global practices."
- **Atlantic Global Risk deal value** (>US$500m) attributed to "a person familiar," not confirmed.
- **Third-party M&A databases** (Tracxn, CB Insights) undercount/conflate Howden entities.

## Maintenance
- Re-verify after Howden's next results (first full calendar-year results expected early
  2027 after the year-end change) and after EPFS / Atlantic Global Risk completion.

Related: [[Sources]], [[Financials]]
