---
title: Sources
type: reference
tags: [company, howden, sources, provenance]
crawled: 2026-07-10
---

# Sources

Part of [[Howden Group]]. Pages crawled on **2026-07-10** for this catalogue.

## Primary — howdengroup.com
- About Howden — https://www.howdengroup.com/about
- Our story (US) — https://www.howdengroup.com/us-en/about-us/our-story
- What we do (US) — https://www.howdengroup.com/us-en/about-us/what-we-do
- What makes us different (US) — https://www.howdengroup.com/us-en/about-us/what-makes-us-different
- Homepage — https://www.howdengroup.com/
- Region/country switcher and industry/capability nav — https://www.howdengroup.com/us-en

## UK Broking articles (read 2026-07-10)
Editorial articles enumerated from `/uk-en/sitemap.xml` (436 articles, 2021–26) and 16
high-signal launch/partnership/appointment pieces read in full via the browser — see
[[UK Article Index (2021-2026)]] and [[Growth Strategy & Special Services (Article Signals)]].
Key article URLs (all under howdengroup.com/uk-en): CCS insurance facility (2024-01);
Carbon Credits W&I / Mere Plantations (2024-06); Howden Loss Assist (2024-03); Howden
Motor Risk (2024-08); Asset Protection/HALO (2024-09); Primary Cyber & Tech E&O facility
(2023-11); Howden Climate Parametrics (2023-10); Aviva/Sunsave solar (2024-02); Auxillis
partnership (2025-01); Gold Standard CORSIA (2025-07); Verra (2025-08); Skyline/Munich Re
Jamaica (2022-04); Mitiga (2025-09); Rowan Douglas appointment (2023-06); Robert Kennedy
CEO UK&I (2025-06); Howden Newcastle (2025-01).

## Research export (imported 2026-07-10, public sources)
A cited 30-note research vault was merged in, adding [[Ownership & Capital Structure]],
[[M&A Activity]], [[US Expansion & Litigation]], [[Publicly Stated Strategy]],
[[Awards & Recognition]], [[Clients & Case Studies]], [[Sponsorships & Brand Partnerships]],
[[Research Gaps & Contradictions]], plus CY2025/year-end data in [[Financials]]. Full
bibliography (50 URLs) in [[Master Source List (Research Export)]]. Key added sources:
Insurance Journal, Insurance Age, Insurance Times, Insurance Business, Money Marketing,
Companies House (company 02937398), and Howden press releases.

## Specialty, products & innovation (added 2026-07-10)
- Specialty overview — https://www.howdengroup.com/uk-en/specialty
- Specialty hubs — https://www.howdengroup.com/uk-en/about-us/global-expertise/hubs
- APAC capabilities — https://www.howdengroup.com/uk-en/specialty/asia-pacific-capabilities
- Full product/sector navigation — https://www.howdengroup.com/uk-en/insurance/parametrics
- Parametric Solutions — https://www.howdengroup.com/uk-en/insurance/parametrics
- Howden M&A — https://www.howdengroup.com/global-practices/mergers-and-acquisitions
- Howden Ventures — https://www.howdengroupholdings.com/about-us/howden-ventures
- Research & development — https://www.howdengroupholdings.com/about-us/research-and-development
- Climate Parametrics launch — https://www.howdengroup.com/uk-en/howden-launches-climate-parametric
- Innovation hub / £500m capacity — https://www.howdengroupholdings.com/news/howden-launches-world-first-insurance-innovation-hub-with-500m-of-delegated-underwriting-capacity
- Cloud Outage Insurance — https://www.howdengroup.com/de-en/product/cloud-outage-insurance

## Specialty brochures & capability PDFs (added 2026-07-10)
- Specialty overview "Flexability" — https://www.howdengroup.com/sites/huk.howdenprod.com/files/2023-11/specialty_overview_0711.pdf
- Marine & Cargo APAC capabilities — https://www.howdengroup.com/sites/huk.howdenprod.com/files/2023-10/marine_cargo_apac_digital.pdf
- Natural Resources & Construction APAC — https://www.howdengroup.com/sites/huk.howdenprod.com/files/2023-10/natural_resources_construction_apac_digital.pdf
- International Property APAC — https://www.howdengroup.com/sites/huk.howdenprod.com/files/2023-10/international_property_apac_digital.pdf
- Terrorism & Political Violence brochure (2024 update) — https://www.howdengroup.com/sites/huk.howdenprod.com/files/2024-01/h274272_p628410_5409_howden_specialty_terrorism_political_violence_non_us_brochure_digital_digital_2024update.pdf
- Construction Practice brochure (2022) — https://www.howdengroup.com/sites/huk.howdenprod.com/files/2022-11/Construction-Brochure-September-2022.pdf
- Howden M&A Annual Review 2025 (FY2024 data) — https://www.howdengroup.com/sites/huk.howdenprod.com/files/2025-03/howden-m-and-a-2025-annual-review.pdf

> [!note] Brochure scale figures ($27bn premium, 12,000 specialists, 45/90+ territories)
> are point-in-time marketing numbers from 2022–24 PDFs and differ from current group
> figures in [[Company Overview]]. Kept as-sourced with dates.

## Additional specialty lines (added 2026-07-10)
- Casualty — https://www.howdengroup.com/uk-en/product/casualty
- Parametric Solutions — https://www.howdengroup.com/uk-en/insurance/parametrics
- Real Estate — https://www.howdengroup.com/uk-en/real-estate-insurance
- Surety — https://www.howdengroup.com/uk-en/cover/surety

## Additional line & insight pages (added 2026-07-10)
- Fine Art & Specie — https://www.howdengroup.com/uk-en/fine-art-and-specie
- Aviation — https://www.howdengroup.com/uk-en/industry/logistics/aviation
- Sport & Entertainment — https://www.howdengroup.com/uk-en/sector/sport-and-entertainment
- Life Sciences — https://www.howdengroup.com/uk-en/health-care/life-sciences-insurance
- Carbon borders / CBAM — https://www.howdengroup.com/uk-en/news-insights/carbon-border-rules-eu-uk-market-access-hard-to-abate-sectors
- CSRD Omnibus / SMEs — https://www.howdengroup.com/uk-en/news-insights/crsd-omnibus-explained-what-smes-need-to-know
- World-first voluntary carbon-credit insurance — https://www.howdengroup.com/uk-en/Howden-launches-World-First-voluntary-carbon-credit-insurance-product-to-help-scale-the-market

## Flagship insight reports (added 2026-07-10)
- Cyber 2025 report "Rebooting growth" (PDF) — https://www.howdengroupholdings.com/sites/default/files/2025-09/howden-2025-cyber-report-rebooting-growth.pdf
- Cyber 2024 report (PDF) — https://www.howdengroupholdings.com/sites/default/files/2024-06/howden-2024-cyber-report.pdf
- Cyber report landing — https://www.howdengroupholdings.com/reports/2024-cyber-report
- Credit & Political Risk 2025 report — https://www.howdengroup.com/sg-en/howdens-2025-credit-and-political-risk-insurance-report
- D&O Insurance Trends 2026 "Fair Winds" — https://www.howdengroup.com/au-en/directors-and-officers-insurance-trends-report-2026-howden (full: https://view.publitas.com/howden-uk-group/howden-d-o-outlook-report-2026/)
- News & Insights feed (UK) — https://www.howdengroup.com/uk-en/news-insights
- Cyber premiums >US$50bn by 2030 (news) — https://www.howdengroupholdings.com/news/cyber-insurance-entering-a-new-phase-of-development-as-non-us-territories-set-to-capture-54-of-growth-up-to-2030

## Corporate — howdengroupholdings.com
- About us — https://www.howdengroupholdings.com/about-us
- Key people — https://www.howdengroupholdings.com/about-us/key-people
- Homepage / financials promo — https://www.howdengroupholdings.com/
- 2024 full-year results — https://www.howdengroupholdings.com/news/howden-announces-2024-full-year-results
- Financials — https://www.howdengroupholdings.com/about-us/financials
- Sustainability — https://www.howdengroupholdings.com/sustainability

## Caveats on figures
- **Headcount** varies by page (18,000 colleagues in older narrative vs. 25,000+ experts
  in 2025–26 copy). The higher figure is more current.
- **Country count**: 57 direct vs. 115+ with network — different definitions.
- **Premium ($38bn)** and **revenue (£3,010m FY2024)** are different measures in
  different currencies; keep them separate.
- Some deeper pages (capabilities/industry overviews, group "what we do") are
  client-rendered and returned little via plain fetch; content above is drawn from
  pages that rendered fully plus the site navigation.

> [!info] Crawl method: server-rendered pages fetched directly; a few figures
> cross-checked against the corporate results release. This is a website snapshot,
> not audited data.
