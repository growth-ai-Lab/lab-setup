---
title: Sustainability & Social Impact
type: company-profile
tags: [company, howden, sustainability, esg, foundation]
crawled: 2026-07-10
source: howdengroupholdings.com/sustainability, /about-us
---

# Sustainability & Social Impact

Part of [[Howden Group]].

## Three-pillar strategy
Howden frames sustainability across three pillars — the people it hires, the work it
does, and its own impact as a company:
1. **De-risking the energy transition** — climate risk & resilience capability,
   e.g. a first-of-its-kind Carbon Capture & Storage leakage facility and a
   Warranty & Indemnity policy for carbon credits.
2. **Empowering people** — social impact and community programmes.
3. **Being a responsible business** — governance and operational sustainability.

Leadership: **Nick Stace OBE**, Chief Global Impact Officer (appointed Dec 2025);
**Caroline Woodworth** chairs the board Sustainability Committee.
Reports published annually (2022, 2023, 2024 sustainability reports on the corporate site).

## Howden Foundation
- Established **2014**; group charitable foundation.
- Has donated **millions of dollars** to charitable partners in **38 countries**.
- 25th-anniversary fundraising raised over **$1.5m** for group and local charity partners.
- Site: howdenfoundation.com.

## Climate & resilience focus
Dedicated Climate Risk & Resilience capability; positions insurance as "a force for
good" and emphasises mitigating climate effects on the most vulnerable communities.
FY2024 (per research export): the Foundation distributed **over £1m** to climate
resilience in the Global South, incl. an extreme-heat product for women workers in India
with **Climate Resilience for All**; the **Howden Resilience Laboratory** (with Microsoft)
and joint climate research with **Boston Consulting Group** ([Howden, 5 Feb 2025](https://www.howdengroupholdings.com/news/howden-announces-2024-full-year-results)).

## Humanity Insured
Howden states it convened the industry to launch **Humanity Insured**, a global
not-for-profit aiming to make insurance accessible/affordable to the ~3.6 billion people
on the climate-crisis frontline (FY2024 release). See [[Clients & Case Studies]], [[Sponsorships & Brand Partnerships]].

## Governance / compliance references on site
Human rights and modern slavery statement, privacy notices, and cookie policy are
published; US entity licensing disclosed (see [[Global Footprint & Locations]]).
