---
title: History & Timeline
type: company-profile
tags: [company, howden, history, timeline]
crawled: 2026-07-10
source: howdengroup.com/us-en/about-us/our-story
---

# History & Timeline

Part of [[Howden Group]]. Sourced from the US "Our story" page plus corporate site.

## 1994 — Three young brokers and a dog called Flight
David Howden wins the first client with a promise of exceptional service. Founded
originally as a **wholesale broker** employing three people. David Howden had started
his career as a broker at Alexander Howden in 1981.

## 1995–2004 — International expansion begins
- Opens underwriting arm **DUAL** in Madrid (now one of the world's largest MGAs).
- **Howden Iberia** follows.
- By the 10th anniversary: reached **India and Australia**, **$26.8m global revenue**, **250 colleagues**.

## 2005–2014 — Middle East, Asia, and the U.S.
- **2008:** opens in Dubai.
- **2011:** enters Asia by acquiring Asia's largest independent retail broker; begins
  serving the U.S. as a London/Bermuda-based wholesaler via distribution partners.
- **2013:** expands DUAL into the U.S.
- **2014:** Latin America follows — offices in Colombia and Brazil.
- End of decade: **$268m global revenue, 2,000 colleagues, 37 countries.**

## 2014 — Howden Foundation set up
Group charitable foundation established; has since donated millions to partners in 38 countries.

## 2015–2024 — Scale, network, and reinsurance
- **2017:** **Howden One Network** goes live — connects clients to specialist expertise
  in 120+ countries through one platform.
- **2021:** acquires Align Financial Holdings (Kieran Sweeney).
- **2022:** acquires **Aston Lark** (UK & Ireland); RKH merger integration.
- **2023:** acquires U.S.-based **TigerRisk**, now **Howden Tiger** / part of Howden Re.
- End of decade: **$4.7bn revenue, 24,000 people, 56 countries**; becomes a top-10
  global broker and fastest-growing by organic growth.
- 25th anniversary: raised over **$1.5m** for charity partners worldwide.

## 2025–present — U.S. retail launch and Howden Americas
- **2025:** brings together **Atlantic Group** and **Gravitas** to launch **Howden U.S.**
  as a full retail broking business. **Mike Parrish** appointed CEO. Within months:
  **1,000+ colleagues, 50+ U.S. locations**, clients from family offices to Fortune 100.
- **Early 2026:** Howden U.S., Latin America & Caribbean united as **Howden Americas**,
  with Mike Parrish as CEO of the region. Group now exceeds **25,000 people in 57 countries.**

## Legacy note
Group was formerly branded **Hyperion Insurance Group**.
