---
title: Clients & Case Studies
type: company-profile
tags: [company, howden, clients, case-studies]
crawled: 2026-07-10
source: Research export (public sources, cited inline)
---

# Clients & Case Studies

Part of [[Howden Group]]. As a broker, Howden rarely names clients publicly; this records
what is public and flags the thinness (see [[Research Gaps & Contradictions]]).

## Client base as described by Howden
- **Specialty:** national/multinational corporates, governments, financial institutions,
  insurance professionals in **150+ territories**.
- **Retail:** "millions of clients," individuals & SMEs to global corporations.
- **CAP:** financial institutions, funds, corporates, traders, public agencies incl.
  Fortune 100 → [[Specialty — Credit & Political Risk]].
- **Captive/insurance management (Guernsey/Bermuda):** multinationals to private
  entrepreneurs, incl. a charity and a Community Interest Company.
- 2021 claim: acting for **37% of DAX and 63% of Euro Stoxx** constituents (dated).

## Documented transaction/outcome examples
- **CAP claims record:** ~US$500m+ client claims settled over ten years (Howden's claim).
- **Tepfin:** 3,000+ placements, US$8bn+ capacity traded across 71 countries.
- Award-winning risk-sharing deal with **BNP Paribas** (SCI Risk Sharing Awards 2025, joint).
- **Climate:** extreme-heat protection for women workers in India with Climate Resilience
  for All (via Howden Foundation) → [[Sustainability & Social Impact]].

Related: [[Products & Services]], [[Awards & Recognition]]
