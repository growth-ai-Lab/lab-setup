---
title: Sponsorships & Brand Partnerships
type: company-profile
tags: [company, howden, sponsorship, partnerships, brand]
crawled: 2026-07-10
source: Research export (public sources, cited inline)
---

# Sponsorships & Brand Partnerships

Part of [[Howden Group]]. Howden links sport sponsorships to its Sport & Entertainment
specialty → [[Specialty — Sport & Entertainment]].

## Rugby — The British & Irish Lions
- Four-year **Principal Partner** (announced 13 Jul 2023); front-of-jersey sponsor for the
  2025 men's tour to Australia; community via **Lions Origin Clubs**.
- First-ever **Series Title Partner** of the inaugural **Lions Women's Tour** (NZ, Sep 2027).
- Also: Howden Rosslyn Park National Schools Sevens (from 2024, 14,000+ participants);
  title sponsor of the 2025 Howden Melrose Sevens.

## Sailing — Emirates GBR SailGP Team
- **Tier 2 Partner** from Feb 2026 (remaining two years). Fronted by Richard Haines
  (Divisional CEO, Howden Specialty — see [[Research Gaps & Contradictions]] re: Hughes/Haines).

## Motorsport, racing & tennis
- **Goodwood Festival of Speed** — Official Insurance Partner (announced 2026).
- **Ascot** — five-year deal (2021), tied to equine insurance.
- **Victoria Racing Club** (title partner, Howden Victoria Derby Day from 2025); **Bahrain
  Turf Club** (since 2022); **Jockey Club of Saudi Arabia** (since 2024, incl. US$2m Howden
  NEOM Cup); **LTA** — Official Partner since 2024 (3,500+ venues).

## Corporate/tech collaborations
- **Microsoft** (Howden Resilience Laboratory) and **Boston Consulting Group** (climate
  research) → [[Sustainability & Social Impact]].

Related: [[Specialty — Sport & Entertainment]], [[Company Overview]]
