---
title: M&A Activity
type: company-profile
tags: [company, howden, m-and-a, acquisitions, growth]
crawled: 2026-07-10
source: Research export (public sources, cited inline)
---

# M&A Activity

Part of [[Howden Group]]. Acquisitions **by** Howden (as buyer). Imported from the cited
research export. Non-exhaustive — Howden reported **65 strategic acquisitions** (incl.
asset deals) in FY2024 alone; only prominent deals itemised. See also [[History & Timeline]].

## Volume (Howden's statements)
- FY2022: **31 acquisitions**; FY2024: **65** (28 in Europe) ([Howden, 5 Feb 2025](https://www.howdengroupholdings.com/news/howden-announces-2024-full-year-results)).

## Notable deals
| Year | Target | Notes |
|---|---|---|
| 2020 | A-Plan Group (UK retail) | |
| 2021 | Aston Lark (UK) | With A-Plan, ~£2bn UK investment over 24 months |
| 2021–22 | Align Financial Holdings (US MGA) | Expanded DUAL to $2bn+ GWP |
| 2022 | Assiteca (Italy) | |
| 2022 | TigerRisk Partners (reinsurance) | Basis of Howden Tiger / Howden Re (see [[Business Segments]]) |
| FY2024 | Haakon (Switzerland, reinsurance) | Became Howden Switzerland |
| FY2024 | ARM Holdings (captive management) | Entry into captive management |
| FY2024 | VLC (Netherlands), North Risk (Denmark), AGEO (France) | European retail expansion |
| 2025 | **Barnett Waddingham** (UK pensions/EB) | Announced Mar 2025; completed 7 Apr 2025 ([Money Marketing](https://www.moneymarketing.co.uk/news/howden-completes-acquisition-of-barnett-waddingham/)) |
| 2025 | **Evelyn Partners Financial Services (EPFS)** | Announced 11 Nov 2025; completion expected Q1 2026 ([Howden](https://www.howdengroupholdings.com/news/howden-to-acquire-the-employee-benefits-consultancy-arm-of-evelyn-partners)) |
| 2026 | **Atlantic Global Risk** (US, transaction liability) | Announced Jan 2026; founders reinvesting; >$500m value reported (unconfirmed) → [[Specialty — M&A & Transactional Risks]] |
| 2026 | International Passenger Protection (MGA, via DUAL UK) | Headline only (paywalled) |

## Deals not pursued
- Talks to acquire **Risk Strategies** (US) in early 2025 before choosing an **organic US
  launch** instead ([Insurance Journal, 5 Jan 2026](https://www.insurancejournal.com/news/national/2026/01/05/853065.htm)) — see [[US Expansion & Litigation]].

> [!note] Third-party M&A databases (Tracxn, CB Insights) conflate multiple companies
> named "Howden" and undercount group activity — excluded as unreliable.

Related: [[Publicly Stated Strategy]], [[Financials]], [[History & Timeline]]
