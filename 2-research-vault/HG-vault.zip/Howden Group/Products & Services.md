---
title: Products & Services
type: company-profile
tags: [company, howden, products, services, taxonomy]
crawled: 2026-07-10
source: howdengroup.com/uk-en (full product navigation)
---

# Products & Services

Part of [[Howden Group]]. Full offering taxonomy captured from the UK site
navigation (the most complete product menu on howdengroup.com). Complements
[[Specialty Lines (Global)]] and [[Industries & Capabilities]].

## Insurance products (by cover)
- **Aviation**
- **Business Interruption**
- **Carbon Capture & Storage** *(emerging)*
- **Cargo & Stock Throughput**
- **Casualty** — Accident & Health; Clinical Trials; International Liability; Life Sciences; Product Recall; UK Liability; US/North American Liability
- **Climate Risk & Resilience** *(emerging)*
- **Contingency** — Contractual Bonus & Prize Indemnity; Event Cancellation & Non-Appearance; Over-Redemption & Fixed Fee; Weather Risks
- **Credit & Political Risks** — Political Risks / Structured Credit; International Trade Credit
- **Crime**
- **Cyber**
- **Directors' & Officers'** — Financial Institutions; Management Liability
- **Digital Assets, Crypto & Blockchain** *(emerging)*
- **Driving Data** *(telematics/data-driven)*
- **Fine Art & Specie** — Cash / Cash-in-Transit; Fine Art & Collectibles; Jewellery; General Specie
- **Insolvency & Restructuring**
- **Kidnap & Ransom**
- **Litigation & Legal** — Court of Protection/Trustees & Estates (deputy bonds); Legal Expenses & Litigation Funding
- **Marine** — Cargo & Stock Throughput; Super Yachts
- **Mergers & Acquisitions** (W&I) — see [[Business Segments]] for stats
- **Medical Indemnity**
- **Motor Trade**
- **Natural Resources** — Energy Liability; Midstream/Downstream & Mining; Power & Utilities; Upstream
- **Parametric Solutions** *(see [[Product Innovation & Ideation]])*
- **Product Guarantee**
- **Product Recall**
- **Professional Indemnity** — Construction & Property Consultants; Financial Consultants
- **Property** — International; North American; Public Entity & Infrastructure; Real Estate; Landlords; Masonic Buildings
- **Surety Bonds & Guarantees** — Performance Bonds; Surety
- **Terrorism & Political Violence**
- **Trade Credit**
- **Tax & Contingent Risks**

## Additional product lines (from full sitemap audit, 2026-07-10)
Product/cover pages present in the UK sitemap that weren't itemised above:
- **Drone insurance** (`/insurance/drone-insurance`) *(emerging)*
- **Employment Practices Liability (EPL)** (`/insurance/employement-practices-liability`)
- **Weather Parametrics** (`/cover/weather-parametrics`) — see [[Specialty — Parametric Solutions]]
- **Death, Disgrace & Disablement** (`/cover/death-disgrace-and-disablement-insurance`) — sport & entertainment
- **Credit & Capital** (`/insurance/credit-and-capital`) incl. performance bonds
- **Banks / Bankers Blanket Bond** (`/cover/banks`); **Wealth Management** (`/cover/wealth-management`) — financial institutions
- **Intellectual Property insurance** (`/cover/intellectual-property-insurance`)
- **Medical Malpractice** (consultants/surgeons); **Insurance/medical clinics**
- **Prize Indemnity**, **Contractual Bonus**, **Over-Redemption & Fixed Fee** — contingency sub-lines
- Profession-specific PI micro-pages (IT & management consultants, insurance brokers, clerks of works, etc.)

> Coverage confirmed: the sitemap's `/product`, `/cover`, `/insurance`, `/industry` trees
> (73 pages) map to the taxonomy above with no *core* line missing — see [[Site Map & Coverage Check]].

## Sectors served (by industry)
Agriculture; Aviation; Charity & Not-for-Profit; Climate Risk & Resilience;
Construction & Infrastructure; Education; **Energy Storage**; Equine; Financial
Institutions; **Fintech**; Fine Art & Specie; Health & Care; Hospitality;
**Life Sciences**; Manufacturing; Marine; Media; M&A; Motor Trade; Natural
Resources; Professional Services; Public Sector; Real Estate; Retail; SME Business;
Sport & Entertainment; Transportation/Storage/Logistics; **Technology**.

## Employee benefits & health
Employee Benefits Consulting; SME benefit solutions; **Benefits Tech** (Flexible
Benefits, "Howden Be"); Business Protection; Communications & Engagement; Employee
Wellbeing; Global Benefits Management; Group Healthcare (PMI, Dental, Health Cash
Plans); Group Risk (Critical Illness, Income Protection, Life); International PMI;
Pensions & Financial Wellbeing; People Risk; sector specialisms (charities, asset
management, legal).

## Risk advisory (fee-based services, not risk transfer)
Enterprise Risk Management; Cyber Risk & Data Privacy; Motor Risk; People Risk;
Property Risk / Asset Protection; **Risk Tech** — *Celestia Risk* and a client
*Risk Portal*.

## Capital markets & advisory
Howden Capital Markets & Advisory (HCMA) — ILS, alternative capital, structured/
capital solutions; Howden Re for reinsurance. See [[Business Segments]].

## Delivery channels
Retail, direct, wholesale, captive, reinsurance; personal lines and small business
via howdeninsurance.co.uk in the UK.

> [!note] Items tagged *(emerging)* are newer/climate- or tech-driven covers and are
> the most fertile ground for the ideation work in [[Product Innovation & Ideation]].
