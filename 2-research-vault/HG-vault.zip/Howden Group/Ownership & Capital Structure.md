---
title: Ownership & Capital Structure
type: company-profile
tags: [company, howden, ownership, capital, financials]
crawled: 2026-07-10
source: Research export (public sources, cited inline)
---

# Ownership & Capital Structure

Part of [[Howden Group]]. Imported from the cited research export (public sources).
Complements [[Company Overview]] and [[Financials]].

## Shareholders
- Per press reporting (Jan 2026), Howden is owned by **5,300 employee-shareholders**,
  PE firms **General Atlantic** and **HgCapital**, Canadian pension fund **La Caisse**
  (formerly CDPQ), and the **Howden Foundation** ([Insurance Journal, 5 Jan 2026](https://www.insurancejournal.com/news/national/2026/01/05/853065.htm)).
- Employee-shareholder count over time: ~1,300 (2020) → 3,500 (2022) → 5,300 (2026).
- 2021 capital: **£500m from Hg** plus **£300m** from General Atlantic and CDPQ, part-funding
  the Aston Lark purchase ([Insurance Times, 20 Jan 2022](https://www.insurancetimes.co.uk/news/howden-group-boosts-revenue-by-48-in-2021-thanks-to-organic-growth-uptick/1440064.article)).
- Ranked by the Employee Ownership Association as the **UK's 5th-largest employee-owned business**.

## Valuation
- Equity valued at **£10bn (~US$13.4bn) in 2024** ahead of an internal share sale;
  **enterprise value ~£20bn** incl. debt ([Insurance Journal, 5 Jan 2026](https://www.insurancejournal.com/news/national/2026/01/05/853065.htm); Howden's own FY2024 release cites "an Enterprise Value approaching £20bn").

## Debt & ratings (Howden FY2024 release, 5 Feb 2025)
- Dec 2024: repriced existing **US$2,925m and €900m Term Loan B** tranches (lower margins,
  USD tranche upsized by US$200m).
- Ratings reaffirmed **B2 Stable (Moody's)** and **B Stable (S&P)** — characterised by
  Howden as among the best of levered brokers.

## IPO intention (attributed claim)
- David Howden said (Times interview, Jul 2025) he plans to complete an **IPO by 2030**,
  venue uncommitted — a stated intention, not a confirmed transaction ([Insurance Journal, 5 Jan 2026](https://www.insurancejournal.com/news/national/2026/01/05/853065.htm)).

Related: [[Financials]], [[Company Overview]], [[M&A Activity]]
