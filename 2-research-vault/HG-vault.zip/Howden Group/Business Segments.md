---
title: Business Segments
type: company-profile
tags: [company, howden, segments, business-lines]
crawled: 2026-07-10
source: howdengroup.com/us-en/about-us/what-we-do, howdengroupholdings.com
---

# Business Segments

Part of [[Howden Group]]. Howden is building a "full-spectrum platform" across the
insurance value chain.

## Retail broking
Tailored risk solutions to mid-market and corporate clients through
industry-specialist teams. Serves SMEs, corporates, and multinationals.

## Specialty lines
Cyber, D&O, professional liability, construction, energy, marine, financial
institutions, and more. Group-level [[Leadership & Board|Howden Specialty]]
also covers natural resources, property, casualty, logistics, sport & entertainment,
fine art & specie, M&A, tax & contingent risk, credit & political risk, surety,
climate transition risk, and real estate.

## Reinsurance — Howden Re
The global reinsurance arm; offers access to capital, analytics, and data-driven
solutions. Includes **Howden Capital Markets & Advisory (HCMA)** and
**Bowood & Howden Re Programs**. Grew via the 2023 TigerRisk acquisition
(**Howden Tiger**). Facultative arm cited at 750+ people across 38 offices,
revenues over $450m.

## Underwriting — DUAL
One of the world's largest **managing general agents (MGAs)**. Per the corporate
site: **1,800+ people in 21 countries, creating solutions across ~70 product lines.**
Founded in Madrid (see [[History & Timeline]]).

## Capital advisory
Supports clients in **M&A, risk financing, and insurance-linked securities (ILS)** —
delivered largely through Howden Capital Markets & Advisory.

## Employee benefits and health
Helps organisations design and manage benefit programs aligned to their people and
strategy. UK Health & Employee Benefits led at group level by Glenn Thomas.

## Enabling platform — Howden OS
Proprietary technology and data "operating system" built around clients rather than
legacy systems; used as a key differentiator.

## Corporate site framing
The group corporate site splits into two public sub-sites:
- **Broking** — global retail, specialty, and reinsurance broking to mid-market,
  large corporates, SMEs, and personal lines.
- **Underwriting (DUAL)** — the MGA business.
