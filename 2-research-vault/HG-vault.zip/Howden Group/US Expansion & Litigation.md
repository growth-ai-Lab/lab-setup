---
title: US Expansion & Litigation
type: company-profile
tags: [company, howden, us, litigation, hiring]
crawled: 2026-07-10
source: Research export (public sources, cited inline)
---

# US Expansion & Litigation

Part of [[Howden Group]]. Factual record of publicly reported disputes from Howden's
US hiring-led launch. **Reported allegations are claims by the parties, not established
findings**; most outcomes were not public as of the export date. See [[History & Timeline]]
(2025–present) and [[M&A Activity]] (Risk Strategies talks not pursued → organic launch).

## Reported lawsuits
- Per Insurance Journal (28 Jan 2026), **Alliant, Aon, Marsh and Willis Towers Watson**
  brought legal actions against Howden over its US launch; **Brown & Brown** filed a
  lawsuit in December 2025 ([Insurance Journal, 28 Jan 2026](https://www.insurancejournal.com/news/national/2026/01/28/855949.htm)).
- Howden US CEO **Mike Parrish** was reported sued by former employer Marsh.

## Brown & Brown statements (attributed claims)
- On a 27 Jan 2026 analysts' call, CEO J. Powell Brown said ~**275 former Brown & Brown
  employees** joined Howden US, taking customers representing ~**US$23m** annual revenue,
  and that Brown & Brown had obtained an **injunction**; most were in employee benefits,
  not producers.
- Brown called it "what appears to be a highly coordinated plan to lift entire teams from
  its competitors," while noting Howden "is one of many" firms hiring aggressively.
- A later headline put the revenue impact at **US$31m** ("Cost of Howden-Driven Talent
  War Rises to $31M for Brown & Brown").

## Howden's response
- No direct Howden rebuttal was captured in the export sources — open gap (see
  [[Research Gaps & Contradictions]]).

Related: [[Company Overview]], [[M&A Activity]], [[Publicly Stated Strategy]]
