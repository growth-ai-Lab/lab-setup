---
title: Core Revenue vs Marketing (Assessment)
type: analysis
tags: [company, howden, analysis, revenue, marketing, strategy]
crawled: 2026-07-10
source: synthesis across vault (analytical view, not Howden's own framing)
---

# Core Revenue vs Marketing (Assessment)

Part of [[Howden Group]]. An **analytical judgment** (ours, not Howden's) on which
activities actually **drive revenue to the core broking/underwriting business** versus
those that are primarily **brand, PR and social-impact positioning**. Howden doesn't break
out revenue by activity ([[Research Gaps & Contradictions]]), so this is reasoned from how
each activity earns — placement commission/fees vs. no direct premium flow.

## How to read the tiers
- **Tier 1 — Core revenue engines:** produce placement commission, fee, or underwriting/
  MGA income at scale. This is the business.
- **Tier 2 — Revenue-supporting services:** modest/indirect income, but win, retain and
  deepen Tier-1 relationships. Justified by retention and organic growth.
- **Tier 3 — Brand / thought-leadership / social impact:** little or no direct premium;
  build reputation, talent draw, and market access. Real strategic value, but not revenue.

## Tier 1 — Core revenue engines
- **Retail & commercial broking** (UK 200+ branches, Europe, APAC, US) → [[Howden Broking — Retail & Regions]]
- **Howden Specialty lines** — marine, property, NR & energy, construction, casualty,
  financial lines, T&PV, fine art & specie, aviation, sport & entertainment → [[Specialty Lines (Global)]]
- **Howden CAP / Credit & Political Risk** — US$1bn+ limits, Tepfin volume → [[Specialty — Credit & Political Risk]]
- **M&A / transactional risks (W&I, tax, title)** → [[Specialty — M&A & Transactional Risks]]
- **Cyber** incl. the **Primary Cyber & Tech E&O facility** (proprietary capacity, EU mid-
  market) → [[Specialty — Cyber]] *(the user's example of a revenue-driving initiative — agreed)*
- **Howden Re** (reinsurance broking) and **DUAL** (MGA underwriting income) → [[Business Segments]]
- **Employee benefits & health** (Barnett Waddingham, EPFS) → [[M&A Activity]]
- **Surety** (£20bn+ bonds placed) → [[Specialty — Surety]]
- **Enabling platforms** that scale placement: **Tepfin/Dynamite**, Howden OS → [[Specialty — Platforms & Data Tools]]

## Tier 2 — Revenue-supporting services (retention / organic growth)
- **Risk Management pillars** — Motor Risk, Asset Protection/HALO → [[Specialty — Casualty]], [[Specialty — Real Estate]]
- **Howden Loss Assist** and **Auxillis** claims services → [[Growth Strategy & Special Services (Article Signals)]]
- **Flagship research reports** (Cyber, D&O, CPRI, M&A) — lead-gen/credibility that feeds
  Tier-1 lines → [[Sector Insights & Thought Leadership]]
- **Captive & risk-advisory** services → [[Specialty Lines (Global)]]
- **Commercial parametric** (weather/nat-cat for corporates & public entities) — *can* be a
  real premium line where a paying buyer exists → [[Specialty — Parametric Solutions]]

## Tier 3 — Brand / thought-leadership / social impact (not core revenue)
- **Sponsorships** — British & Irish Lions, SailGP, Goodwood, racing, LTA → [[Sponsorships & Brand Partnerships]]
- **Howden Foundation, Humanity Insured, Resilience Laboratory** → [[Sustainability & Social Impact]]
- **Carbon-market "gatekeeper" appointments** (Gold Standard, Verra, CORSIA) — position
  Howden as trusted infrastructure; negligible direct premium → [[Growth Strategy & Special Services (Article Signals)]]
- **Developing-market / charitable parametric** (Jamaica farmers, India extreme-heat) —
  proof-of-concept & ESG brand; Howden funded some premiums itself.
- **Climate research & partnerships** (BCG, Mitiga, Climeworks, SMI) — thought leadership.

## On the two examples given
- **Cyber / Tech E&O facility → Tier 1 (revenue).** Agreed: proprietary Lloyd's-backed
  capacity (limits to €20m) placed for a defined, paying mid-market — it earns commission
  and is defensible.
- **"Climate Parametrics" → mostly Tier 3, but split the label.** The *Howden Climate
  Parametrics practice* as publicly presented leans on charitable/developing-market and
  ESG-brand use cases (low or self-funded premium) — so as a **headline it is marketing/
  positioning, not a core revenue driver**, consistent with your read. **However**,
  parametric risk transfer itself is a legitimate premium product when sold to corporates,
  public entities or (re)insurers (see [[Specialty — Parametric Solutions]]). So the
  *technique* can be Tier 1; the *climate-parametrics brand programme* is largely Tier 3.
  Worth watching whether it converts brand into a commercial book.

## Why this matters for prioritisation
- **Revenue depth work** should concentrate on Tier 1 (specialty lines, CAP, cyber, M&A,
  Re, DUAL, retail) and the Tier-2 services that protect them.
- **Tier 3** is real strategic value (talent, access, licence-to-operate on climate) but
  should not be mistaken for a revenue line when sizing opportunities in
  [[New-Product Opportunity Register]].

> [!warning] Judgment call, not audited data. Howden publishes no activity-level revenue
> split; tiering is inferred from how each activity earns. A single initiative can span
> tiers (e.g. carbon-credit W&I is Tier-3 brand today but a plausible Tier-1 line if the
> voluntary carbon market scales).
