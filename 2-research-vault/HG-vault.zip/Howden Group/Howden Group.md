---
title: Howden Group
type: company-profile
tags: [company, howden, insurance-broker, moc]
aliases: [Howden, Howden Group Holdings, Hyperion]
crawled: 2026-07-10
sources: [howdengroup.com, howdengroupholdings.com]
---

# Howden Group

> Map of content for everything catalogued about Howden Group, crawled from
> **howdengroup.com** (and the linked corporate site **howdengroupholdings.com**) on 2026-07-10.

## What it is
Howden is a specialist, employee-owned international insurance group — broking,
reinsurance broking, and underwriting (via DUAL). Founded 1994 by David Howden.
Now one of the world's top 10 insurance brokers and the largest independently /
employee-owned international retail broker.

## Notes in this catalogue
- [[Company Overview]] — snapshot, identity, ownership model, key facts
- [[History & Timeline]] — 1994 → present, milestones by era
- [[Business Segments]] — retail broking, specialty, Howden Re, DUAL, capital advisory, benefits
- [[Specialty Lines (Global)]] — global specialty ethos, hubs, captive services, product classes
  - Deep dives (from brochures/PDFs): [[Specialty Overview (Flexability)]] · [[Specialty — Terrorism & Political Violence]] · [[Specialty — Natural Resources & Energy]] · [[Specialty — Construction]] · [[Specialty — International Property]] · [[Specialty — Marine & Cargo]] · [[Specialty — M&A & Transactional Risks]]
  - Insight-led lines (from flagship reports): [[Specialty — Cyber]] · [[Specialty — Financial Lines & D&O]] · [[Specialty — Credit & Political Risk]] · [[Sector Insights & Thought Leadership]]
  - More lines: [[Specialty — Fine Art & Specie]] · [[Specialty — Aviation]] · [[Specialty — Sport & Entertainment]] · [[Specialty — Life Sciences & Health Care]] · [[Specialty — Casualty]] · [[Specialty — Parametric Solutions]] · [[Specialty — Real Estate]] · [[Specialty — Surety]]
- [[Products & Services]] — full product/sector/benefits/advisory taxonomy
- [[Product Innovation & Ideation]] — Ventures, R&D, parametrics, whitespace + ideation framework
- [[New-Product Opportunity Register]] — consolidated, ranked new-product hypotheses
- [[Leadership & Board]] — Global Leadership Team and Group Board
- [[Global Footprint & Locations]] — countries, regions, HQ, network
- [[Financials]] — FY2024 results, premium and revenue figures
- [[Sustainability & Social Impact]] — three-pillar strategy, Howden Foundation
- [[Industries & Capabilities]] — sectors served and product lines
- [[Ownership & Capital Structure]] — shareholders, valuation, debt/ratings, IPO intent *(research export)*
- [[M&A Activity]] — acquisition history and deals not pursued *(research export)*
- [[US Expansion & Litigation]] — competitor lawsuits over the US hiring launch *(research export)*
- [[Publicly Stated Strategy]] — Howden's stated growth formula & priorities *(research export)*
- [[Awards & Recognition]] · [[Clients & Case Studies]] · [[Sponsorships & Brand Partnerships]] *(research export)*
- [[Research Gaps & Contradictions]] — known gaps & inconsistencies in the public record *(research export)*
- [[Site Map & Coverage Check]] — full sitemap architecture + what's covered vs long-tail
- [[UK Article Index (2021-2026)]] — themed inventory of 436 UK Broking articles
- [[Growth Strategy & Special Services (Article Signals)]] — what the articles imply *(synthesis)*
- [[Core Revenue vs Marketing (Assessment)]] — which activities drive revenue vs brand *(analysis)*
- [[Howden Broking — Retail & Regions]] — retail backbone by region
- [[Specialty — Platforms & Data Tools]] — Tepfin, Dynamite, HX, Howden OS
- [[Sources]] — pages crawled and figure caveats
- [[Master Source List (Research Export)]] — 50 cited URLs from the imported research

## Quick facts (headline, see notes for caveats)
- **Founded:** 1994 (David Howden + 2 colleagues + a dog called Flight)
- **HQ:** One Creechurch Place, London, EC3A 5AF, UK
- **Legal parent:** Howden Group Holdings Limited (England & Wales, reg. no. 2937398)
- **People:** ~25,000 experts (some pages cite 18,000 colleagues — see [[Company Overview]])
- **Reach:** 57 countries directly; 115+ via network
- **Premium under management:** ~$38bn
- **FY2024 adjusted revenue:** £3,010m (+23%; 15% organic)
- **Ownership:** Employee-owned; staff own >30% of the company
