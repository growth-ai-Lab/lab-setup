---
title: Leadership & Board
type: company-profile
tags: [company, howden, leadership, people, board]
crawled: 2026-07-10
source: howdengroupholdings.com/about-us/key-people
---

# Leadership & Board

Part of [[Howden Group]]. Captured from the group "Key people" page (Global
Leadership Team + Group Board) plus role notes from howdengroup.com.

## Founder & Group CEO
- **David Howden CBE** — Group CEO. Started as a broker at Alexander Howden (1981);
  founded the Group in 1994. Leads Group M&A and overall strategy.

## Global Leadership Team
- **David Shalders** — Group Chief Operating Officer (board 15 Oct 2024; chairs the Group Operating Committee). Ex-LSEG, Willis Towers Watson, RBS.
- **Susan Panuccio** — Group Chief Financial Officer (joined Jan 2026; ex-News Corp CFO).
- **Mark Craig** — Chief Investment Officer (from Jan 2026; previously Group CFO for six years).
- **Andrew Richards** — Group Chief Technology Officer.
- **Chris Dalrymple** — Group Chief Legal Officer (ex-Alleghany).
- **Joanne Jolly** — Group General Counsel.
- **Rebecca Scott** — Group Chief Risk Officer.
- **Kirk Southern** — Group Chief People Officer.
- **Louise Cable-Alexander** — Group Chief of Staff; one of the three founding members.
- **Nick Stace OBE** — Chief Global Impact Officer (appointed Dec 2025).
- **Peter Blanc** — Group Head of M&A (ex-Aston Lark Group CEO).
- **Andy Bragoli** — Global Head of Placement, Howden; Chair of LIIBA (2024).

## Regional & divisional leaders
- **Mike Parrish** — CEO, **Howden US** / CEO, **Howden Americas** (joined Sep 2025; ex-Aon, ex-Marsh).
- **Luigi Sturani** — CEO, Howden Europe.
- **Robert Kennedy** — CEO, Howden UK & Ireland.
- **Barnaby Rugge-Price** — Chair, Howden UK & Ireland.
- **Rohan Bhappu** — CEO, Howden Asia (from 1 Oct 2025; ex-Marsh McLennan HK & Macau).
- **Matt Bacon** — CEO, Howden Pacific.
- **Sonia Caamaño** — CEO, International Growth Markets (India, Middle East, Africa, LatAm).
- **Paul Redgate** — Chair, Howden Specialty & Chair, International Growth Markets.
- **Sarah Hughes** — CEO, Howden Specialty.
- **Glenn Thomas** — CEO, UK Health & Employee Benefits, and Global Practice Leader.

### Reinsurance (Howden Re) & DUAL
- **Tim Ronda** — CEO, Howden Re (appointed Jan 2024; ex-Howden Tiger / TigerRisk president).
- **Elliot Richardson** — Executive Chair, Howden Re (ex-CEO Aon Broking).
- **Rob Bredahl** — Vice Chair, Howden Re & Executive Chair, Howden Capital Markets & Advisory (ex-CEO Howden Re / TigerRisk).
- **Richard Clapham** — CEO, DUAL Group (joined 2016).
- **Kieran Sweeney** — Executive Chair, DUAL Group (founder of Align, acquired 2021).
- **Toby Pollard** — Managing Director, Howden Markets.

## Group Board
- **Dominic Collins** — Executive Chairman (board Chairman since May 2015; ex-RKH, Lloyd Thompson, JLT).
- **David Howden CBE** — Group CEO (see above).
- **David Shalders** — Group COO.
- **Susan Panuccio** — Group CFO.
- **Jim Hays** — Vice Chairman, Howden Group Holdings (founder of Hays Company, sold to Brown & Brown 2018).

### Non-Executive Directors (investor-nominated + independent)
- **John Bernstein** — NED (General Atlantic legacy; led GA's Howden investment; board since Jul 2013).
- **Caroline Woodworth** — NED, MD at **General Atlantic**; chairs the Sustainability Committee.
- **David Hodgson** — NED, Vice Chairman of **General Atlantic** (board since Jul 2013).
- **James Parry-Crooke** — NED, Principal at **La Caisse (formerly CDPQ)** (board since May 2022).
- **Ralph Friedwagner** — NED, MD/Operating Partner at **La Caisse (CDPQ)** (board since Nov 2020).
- **Justin von Simson** — NED, Managing Partner at **Hg**.
- **Clement B (Clem) Booth** — NED (board Oct 2015; ex-Allianz SE board, ex-Aon Re International).
- **Mark Stephen** — NED, chairs Audit & Risk and Remuneration Committees (board May 2018; ex-PwC).
- **Kelly Lyles** — NED (board Jul 2021; ex-AIG, ex-XL Catlin/AXA).

> [!note] Investor nominees on the board map to the three growth-equity partners:
> General Atlantic, CDPQ/La Caisse, and Hg — consistent with the ownership model in [[Company Overview]].
