---
title: Awards & Recognition
type: company-profile
tags: [company, howden, awards, recognition]
crawled: 2026-07-10
source: Research export (public sources, cited inline)
---

# Awards & Recognition

Part of [[Howden Group]]. Only awards verifiable in public sources; not a systematic
sweep (see [[Research Gaps & Contradictions]]).

- **SCI Risk Sharing Awards — Innovation of the Year, 2024 & 2025** (Howden CAP / Credit
  & Political Risk team; 2025 jointly with BNP Paribas) → [[Specialty — Credit & Political Risk]].
- **Risk & Insurance 2025 Power Broker (Finance)** — Ron Borys, Head of Financial Lines, Howden US.
- **Employee Ownership Association** — ranked UK's **5th-largest employee-owned business**.
- **Lloyd's accreditation of Tepfin** (1 Oct 2018) as an approved e-trading platform —
  described by Howden as a first for a broker-owned platform.
- **Honours:** David Howden styled **CBE** in Howden's communications.

Related: [[Clients & Case Studies]], [[Leadership & Board]]
