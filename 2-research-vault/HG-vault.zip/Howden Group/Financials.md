---
title: Financials
type: company-profile
tags: [company, howden, financials]
crawled: 2026-07-10
source: howdengroupholdings.com/news/howden-announces-2024-full-year-results
---

# Financials

Part of [[Howden Group]]. Howden is privately held (employee-owned); it publishes
annual results on the corporate site rather than filing as a listed company. See also
[[Ownership & Capital Structure]] and [[M&A Activity]].

> [!important] **Year-end change:** Howden moved its financial year-end from **30 Sep** to
> **31 Dec** during 2025. The transition Companies House filing covers a **15-month period**
> (£4.23bn IFRS revenue, incl. Q4 2024). First full calendar-year results expected early 2027.

## Revenue history (adjusted revenue as reported)
| Period | Adj. revenue | Notes |
|---|---|---|
| FY2020 | £777m | +7%; organic 6% |
| FY2021 | £1,148m | +48%; organic 19%; adj. EBITDA £335m |
| FY2022 | £1.84bn | +60%; organic 19%; adj. EBITDA £565m; 31 acquisitions |
| FY2023 | £2,442m | organic 13% |
| FY2024 | £3,010m | +23%; organic 15%; adj. EBITDA £922.2m (~31% margin) |
| CY2025 | **£3.52bn** | Year-end moved to 31 Dec; 15-month transition filing shows £4.23bn IFRS revenue |

Source for FY2020–22 and CY2025: trade press (Insurance Business, Insurance Times,
[Insurance Age, Jun 2026](https://www.insuranceage.co.uk/insight/7958529/howden-reveals-revenue-topped-ps35bn-in-2025)); FY2023–24 from Howden's [5 Feb 2025 release](https://www.howdengroupholdings.com/news/howden-announces-2024-full-year-results). CY2025 detail is limited/partly paywalled — see [[Research Gaps & Contradictions]].

## FY2024 full-year results
- **Adjusted revenue:** **£3,010m** (FY23: £2,442m) — up **23%**.
- **Organic revenue growth:** **15%** — the fourth consecutive year of double-digit
  organic growth; first year revenue broke through £3bn.
- **Adjusted consolidated EBITDA:** **£922.2m** (FY23: £780m).
- **Adjusted EBITDA margin:** ~**31%** (broadly steady).

### Organic growth by division (FY2024)
- **Insurance broking:** +14%
- **Reinsurance:** +30%
- **Managing General Agent (DUAL):** +6%

## Scale metrics (non-P&L)
- **Premium under management:** ~**$38bn** (used across howdengroup.com and corporate site).
- Prior-decade marker: **$4.7bn revenue** cited at end of the 2015–2024 era (USD basis, see [[History & Timeline]]).

## Notes
- FY2024 headline figures are GBP; premium/scale figures are quoted in USD on the
  public sites — do not mix currencies.
- 2024 full-year results were the latest published set surfaced during this crawl
  (corporate homepage promoted "Our 2024 full-year results are out").
- See [[Sources]] for the results release and financials page URLs.
