---
title: Site Map & Coverage Check
type: reference
tags: [company, howden, sitemap, coverage, gaps]
crawled: 2026-07-10
source: howdengroup.com/sitemap_index.xml, robots.txt, per-locale sitemaps
---

# Site Map & Coverage Check

Part of [[Howden Group]]. Built from the site's own XML sitemaps (retrieved via the
browser) to confirm the vault isn't missing core material. See also [[Sources]].

## Sitemap architecture
- **robots.txt** points to a sitemap **index**: `howdengroup.com/sitemap_index.xml`.
- The index lists **~62 per-locale sitemaps** (one per country/language: `uk-en`, `us-en`,
  `au-en`, `de-de`, `fr-fr`, `es-es`, `it-it`, `jp-ja`, etc.). Same content, localised —
  **not 62× unique pages**.
- **Separate sibling domains** (own sitemaps): `howdengroupholdings.com` (corporate/HQ),
  `howdenre.com` (reinsurance), `howdencma.com` (capital markets), `dualgroup.com` /
  `dualinsurance.com` (DUAL/MGA), `howdenfoundation.com`, `privatewealth.howdengroup.com`.

## Scale (principal targets)
| Sitemap | URLs | Nature |
|---|---|---|
| **uk-en** (London/UK core) | **2,883** | Mostly long-tail content (see below) |
| **howdengroupholdings.com** (corporate/HQ) | **508** | Strategic/corporate + news |

> The UK site is large because it absorbed **A-Plan / Aston Lark** retail networks — hundreds
> of pages are local office and acquired-broker microsites, plus a deep news/insight archive.

## UK (`/uk-en/`) top sections (from captured sample)
- **/author/** — 144+ author bio pages (content long tail)
- **/news-insights/**, **/news/**, **/insights/**, **/article/** — hundreds of articles
- **/sector/** — industry sector pages (motor-trade, fintech, hospitality, sport, etc.)
- **/cover/, /insurance/, /product/** — product/cover pages
- **/employee-benefits/, /risk-advisory/** — division pages
- **Regional office pages** — birmingham, manchester, cambridge, scotland, wales, etc.
- **Acquired-broker microsites** — e.g. bruce-stevenson, essex-insurance-brokers,
  plester-group, oakes-insurance-consultants (legacy A-Plan/Aston Lark brands)
- **SME/consumer + campaign pages** — hubs, guides, webinars

## Corporate (`howdengroupholdings.com`) — strategic pages
Core (non-news): `/about-us` (+ `/awards`, `/financials` [+ `/tax-strategy`],
`/howden-ventures` [+ `/case-studies/ceto`], `/key-people`, `/our-shareholders`,
`/our-story`, `/research-and-development`), `/sponsorship/*` (Lions, LTA), `/like-no-other/*`
(employee stories), `/reports/*` (e.g. 1.1.25 market report; men's European football injury
index), governance (`/gender-pay-gap`, `/human-rights-and-modern-slavery-statement`,
`/modern-slavery-statement-2023`), `/merge-with-us`, `/early-careers`, and an `/insights/`
thought-leadership stream (cyber, climate, CAP, MGA explainers).

## Coverage check — core offering vs vault
| Core area | Vault note | Status |
|---|---|---|
| Group overview / identity | [[Company Overview]] | ✅ |
| History / milestones | [[History & Timeline]] | ✅ |
| Divisions (broking, Re, DUAL, EB) | [[Business Segments]] | ✅ |
| Specialty (all lines) | [[Specialty Lines (Global)]] + 20 deep dives | ✅ |
| Full product/sector/cover taxonomy | [[Products & Services]] | ✅ |
| Leadership & board | [[Leadership & Board]] | ✅ |
| Locations / hubs | [[Global Footprint & Locations]] | ✅ |
| Ownership / shareholders / financials | [[Ownership & Capital Structure]], [[Financials]] | ✅ |
| M&A | [[M&A Activity]] | ✅ |
| Strategy | [[Publicly Stated Strategy]] | ✅ |
| Sustainability / foundation / Humanity Insured | [[Sustainability & Social Impact]] | ✅ |
| Ventures / R&D / innovation | [[Product Innovation & Ideation]] | ✅ |
| Flagship insight reports | [[Sector Insights & Thought Leadership]] | ✅ |
| Awards, clients, sponsorships | [[Awards & Recognition]], [[Clients & Case Studies]], [[Sponsorships & Brand Partnerships]] | ✅ |

## Deliberately NOT catalogued (long tail — breadth, not core)
- News/insight article archive (hundreds) — only flagship reports + a few key articles captured.
- Author bio pages (144+).
- Regional office pages and acquired-broker microsites (A-Plan / Aston Lark legacy).
- SME/consumer campaign pages, webinars, hubs.
- Employee-story ("like no other") pages.

## Candidate additions worth considering (strategic, not yet in vault)
- **Tax strategy** (`/about-us/financials/tax-strategy`) and **gender pay gap** / modern-
  slavery statements — governance detail.
- **Corporate `/insights/` stream** items not yet captured (e.g. "July 2024 global IT
  outage," "deepfakes to hacking-for-hire," "four forces shaping insurance 2025,"
  classic-car product, "what is an MGA").
- **`/reports/1-1-25-market-report`** and other Howden Re/market reports.
- **Sibling-domain sites** (howdenre.com, howdencma.com, dualgroup.com) — not yet crawled;
  relevant if scope extends beyond the broking/specialty core.

> [!note] Conclusion: the vault covers the **entire curated core offering** (every item in
> the site's main navigation) and the strategic corporate pages. What remains in the 2,883-URL
> UK sitemap is overwhelmingly content long-tail (news, authors, local/acquired-broker pages),
> not missing product/offering material. The items above are optional depth, not gaps in scope.
