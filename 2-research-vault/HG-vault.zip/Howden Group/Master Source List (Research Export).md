# Master Source List — All Links and Articles Cited

**50 unique sources** across the 30-note vault, grouped by publisher/domain. Each entry shows the URL and the label(s) used when citing it in the vault (title/date as captured at research time).

---


## apacoutlookmag.com

- **APAC Outlook profile, c.2024**  
  https://www.apacoutlookmag.com/company-profiles/371-howden-broking-group-apac

## barnett-waddingham.co.uk

- **Barnett Waddingham, 7 Apr 2025**  
  https://www.barnett-waddingham.co.uk/comment-insight/news/howden-completes-acquisition-of-barnett-waddingham/

## cbinsights.com

- **CB Insights profile**  
  https://www.cbinsights.com/company/howden-specialty

## eservices.mas.gov.sg

- **MAS eServices directory**  
  https://eservices.mas.gov.sg/fid/institution/detail/2185-HOWDEN-SPECIALTY-ASIA-PACIFIC-PTE-LTD

## find-and-update.company-information.service.gov.uk

- **Companies House filing history**  
  https://find-and-update.company-information.service.gov.uk/company/02937398/filing-history

## howdengroup.com

- **Howden — Marine Hull**  
  https://www.howdengroup.com/ma-en/sector/marine/marine-hull
- **Howden, 13 Jul 2023**  
  https://www.howdengroup.com/news-insights/howden-announces-new-four-year-partnership-with-the-british-and-irish-lions
- **Howden M&A Annual Review 2025, Mar 2025 / Howden M&A Annual Review 2025, PDF, Mar 2025**  
  https://www.howdengroup.com/sites/huk.howdenprod.com/files/2025-03/howden-m-and-a-2025-annual-review.pdf
- **Howden — Our Hubs**  
  https://www.howdengroup.com/uk-en/about-us/global-expertise/hubs
- **For Brokers / Howden — For Brokers**  
  https://www.howdengroup.com/uk-en/brokers
- **CAP page / CAP pages / Howden UK — Political Risks**  
  https://www.howdengroup.com/uk-en/cover/political-risks-structured-credit-insurance
- **Credit & Political Risks page / Howden — Credit & Political Risks**  
  https://www.howdengroup.com/uk-en/credit-political-risks
- **Aviation page / Howden UK — Aviation**  
  https://www.howdengroup.com/uk-en/industry/logistics/aviation
- **Howden — Specialty page / Specialty page**  
  https://www.howdengroup.com/uk-en/specialty
- **Howden — Specialty Asia Pacific Capabilities**  
  https://www.howdengroup.com/uk-en/specialty/asia-pacific-capabilities
- **howdengroup.com/us-en**  
  https://www.howdengroup.com/us-en
- **Howden US — Meet our team**  
  https://www.howdengroup.com/us-en/about-us/meet-our-us-team

## howdengroupholdings.com

- **About Us / Howden Group Holdings — About Us**  
  https://www.howdengroupholdings.com/about-us
- **Howden Group Holdings — Howden Ventures page**  
  https://www.howdengroupholdings.com/about-us/howden-ventures
- **Howden Group Holdings — Key People / Key People**  
  https://www.howdengroupholdings.com/about-us/key-people
- **Howden — Sponsorship page / Sponsorship page**  
  https://www.howdengroupholdings.com/about-us/sponsorship
- **Howden — sponsorship page / Lions pages**  
  https://www.howdengroupholdings.com/about-us/sponsorship/lions
- **Lions Principal Partner page / Lions partner page**  
  https://www.howdengroupholdings.com/about-us/sponsorship/the-british-and-irish-lions
- **Howden, 26 Sep 2023**  
  https://www.howdengroupholdings.com/news-insights/howden-to-unify-business-under-single-management-structure
- **5 Feb 2025 release / Howden results release, 5 Feb 2025 / Howden, 5 Feb 2025**  
  https://www.howdengroupholdings.com/news/howden-announces-2024-full-year-results
- **Howden, 11 Nov 2025**  
  https://www.howdengroupholdings.com/news/howden-to-acquire-the-employee-benefits-consultancy-arm-of-evelyn-partners
- **Howden, Oct 2025**  
  https://www.howdengroupholdings.com/news/uri-dallal-appointed-as-executive-vice-president-financial-lines-howden-us

## howdenre.com

- **Howden Re FY2025 earnings overview, Mar 2026 / Howden Re, Mar 2026**  
  https://www.howdenre.com/news-insights/howden-re-global-reinsurance-earnings-overview-full-year-2025
- **howdenre.com — Risk Advisory**  
  https://www.howdenre.com/risk-advisory

## insuranceage.co.uk

- **Insurance Age, 2023**  
  https://www.insuranceage.co.uk/commercial/7953354/howden-to-sponsor-british-irish-lions
- **Insurance Age, Jun 2026**  
  https://www.insuranceage.co.uk/insight/7958529/howden-reveals-revenue-topped-ps35bn-in-2025

## insuranceasianews.com

- **InsuranceAsia News, 8 Aug 2025**  
  https://insuranceasianews.com/howden-specialty-asia-pacific-promotes-matthew-savitt/

## insurancebusinessmag.com

- **IB Canada, 27 Jan 2021 / Insurance Business Canada, 27 Jan 2021**  
  https://www.insurancebusinessmag.com/ca/news/breaking-news/howden-group-announces-yearend-results-244690.aspx
- **Insurance Business — Reinsurance, 2025 / Insurance Business — Reinsurance, 6 Aug 2025**  
  https://www.insurancebusinessmag.com/reinsurance/news/breaking-news/howden-re-secures-dubai-license-to-expand-reinsurance-services-545167.aspx
- **Insurance Business, 16 May 2023**  
  https://www.insurancebusinessmag.com/uk/news/breaking-news/howden-announces-business-overhaul-446034.aspx
- **Insurance Business, 20 Oct 2025**  
  https://www.insurancebusinessmag.com/us/news/breaking-news/howden-expands-us-leadership-553506.aspx
- **IB US, 30 Jan 2023 / Insurance Business US, 30 Jan 2023 / Insurance Business, 30 Jan 2023**  
  https://www.insurancebusinessmag.com/us/news/breaking-news/howden-group-announces-fullyear-financial-results-434376.aspx

## insurancejournal.com

- **Insurance Journal, 17 Mar 2026**  
  https://www.insurancejournal.com/news/international/2026/03/17/862195.htm
- **Insurance Journal, 5 Jan 2026**  
  https://www.insurancejournal.com/news/national/2026/01/05/853065.htm
- **Insurance Journal, 28 Jan 2026**  
  https://www.insurancejournal.com/news/national/2026/01/28/855949.htm

## insurancetimes.co.uk

- **Insurance Times, 20 Jan 2022**  
  https://www.insurancetimes.co.uk/news/howden-group-boosts-revenue-by-48-in-2021-thanks-to-organic-growth-uptick/1440064.article

## irmi.com

- **IRMI year-in-review, 2026**  
  https://www.irmi.com/articles/expert-commentary/2025-insurance-year-in-review-and-2026-developments

## lionsrugby.com

- **Lions commercial partners page**  
  https://www.lionsrugby.com/en/commercial-partners

## moneymarketing.co.uk

- **Money Marketing, 7 Apr 2025**  
  https://www.moneymarketing.co.uk/news/howden-completes-acquisition-of-barnett-waddingham/

## reinsurancene.ws

- **Reinsurance News, 30 Oct 2025**  
  https://www.reinsurancene.ws/aons-uri-dallal-named-evp-financial-lines-howden-us/
- **Reinsurance News, 11 Nov 2025**  
  https://www.reinsurancene.ws/howden-agrees-to-acquire-evelyn-partners-financial-services/
- **Reinsurance News, 30 Apr 2025**  
  https://www.reinsurancene.ws/howden-expands-latin-american-footprint-with-new-miami-leadership-appointment/

## sg-reinsurers.org.sg

- **SRA member page**  
  https://sg-reinsurers.org.sg/howden-specialty-asia-pacific

## spglobal.com

- **S&P Global Ratings**  
  https://www.spglobal.com/ratings/en/regulatory/article/-/view/sourceId/13396853

## uk.linkedin.com

- **Howden LinkedIn**  
  https://uk.linkedin.com/company/howden-insurance