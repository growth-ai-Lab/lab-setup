---
title: Howden Broking — Retail & Regions
type: company-profile
tags: [company, howden, broking, retail, regions]
crawled: 2026-07-10
source: Research export (public sources, cited inline)
---

# Howden Broking — Retail & Regions

Part of [[Howden Group]] / [[Business Segments]]. The retail broking backbone — "direct to
millions of clients, from private individuals and SMEs to global corporations." A **core
revenue engine** (see [[Core Revenue vs Marketing (Assessment)]]).

## UK & Ireland (the London-HQ home market)
- Built via **A-Plan Group** (2020) and **Aston Lark** (2021) — ~£2bn UK investment over 24 months.
- **200+ high-street branches**, ~**6,500 employees** across UK & Ireland.
- Leadership: **Robert Kennedy** CEO UK&I from Oct 2025 (succeeding **Carl Shuker** → Deputy
  Chairman) — see [[Leadership & Board]], [[Growth Strategy & Special Services (Article Signals)]].

## Europe
- Led by **Luigi Sturani** (CEO Howden Europe); Salvador Marin (CEO Northern Europe),
  Danny Sever (chairman); Turkey folded into Europe.
- FY2024: 28 of 65 deals in Europe (VLC/Netherlands, North Risk/Denmark entry, AGEO/France).
- 2021 claim: acted for 37% of DAX and 63% of Euro Stoxx constituents (dated).

## Asia Pacific
- **Rohan Bhappu** CEO Asia Pacific (from Marsh McLennan HK & Macau), overseeing retail
  broking + **Private Wealth** (HNW life insurance broking).
- FY2024 hires: Kentaro Tada (CEO Japan), Jan Tinus Larsen (CEO Norway); growth in
  Australia, Greece, Middle East, Singapore, Japan.

## Americas / MEA / India (from 1 Apr 2026)
- **Mike Parrish** CEO Americas; **Sonia Caamaño** CEO LatAm & Caribbean; India (Amit
  Agarwal) aligned to Asia; **Paul Redgate** chairman MEA & Howden India. See
  [[History & Timeline]] (Howden Americas) and [[US Expansion & Litigation]].

## Captives
- Captive management entered via FY2024 **ARM Holdings** acquisition; Guernsey/Bermuda-
  regulated capability (see [[Specialty Lines (Global)]]).

Related: [[Business Segments]], [[Global Footprint & Locations]], [[M&A Activity]]
