# Growth AI Lab

A product-development toolkit, custom for the Growth AI Lab. It bundles three skills that work
together to run a **citation-first research knowledge base** for a company, market, or client —
so product and growth hypotheses are built on cited evidence rather than memory.

## The skills

| Skill | What it does | Use it when |
|---|---|---|
| **kb-init** | Stands up (or unpacks a `.zip` seed of) a shared, citation-first research vault and the research agent that maintains it. | "set up / bootstrap / seed a research vault", "unpack this knowledge-base seed" |
| **kb-vault-attach** | Attaches an existing research vault to an already-bootstrapped personal agent (from `setup-agent`), so one agent runs both its personal memory and the research KB without mixing them. | "connect my research vault to my agent", "attach the KB to my assistant" |
| **kb-deep-dive** | Draws on and **extends** an existing vault: learns its house style, fills the gaps with fresh (cited) research, writes notes back in-format, and returns a synthesis briefing. Schema-agnostic. | "do a deep dive on X and add it to our notes", "deepen our product-development research on X" |

## Typical workflow

1. **setup-agent** (external, `agent-bootstrap`) — the user already has a personal agent + memory vault.
2. **kb-init** — stand up or seed the research vault.
3. **kb-vault-attach** — bridge that vault to the existing agent (evidence-first mode inside it).
4. **kb-deep-dive** — extend the vault on real topics, tuned to a client or business line.

## Design principles baked in

- **Citation-first**: every claim traces to a source; company claims are distinguished from verified facts.
- **Provenance incl. geography/scope**: region- or subsidiary-specific figures are never presented as global.
- **No cascade-edits**: contradictions are flagged for a human, never silently overwritten.
- **Research method**: understand the goal, ask what already exists, map before crawling, detect
  rendering mode, parallelise, and label date-and-scope (see each skill's `references/`).

## Extending

Add a new skill by dropping `skills/<name>/SKILL.md` in, bump the version in
`.claude-plugin/plugin.json`, and repackage — skills auto-discover, no manifest wiring needed.
