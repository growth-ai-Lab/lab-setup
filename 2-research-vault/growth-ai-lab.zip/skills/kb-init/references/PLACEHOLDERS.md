# Placeholder Substitution Rules

The templates in this folder use four placeholder tokens. The initialization wizard replaces them with
the user's real values everywhere. Use these same rules if rebuilding or hand-editing the vault.

| Token | Replace with | Example |
|---|---|---|
| `[Agent Name]` | The name the user gives the knowledge-base agent | `Atlas` |
| `[Your Name]` | The user's own name | `Jordan` |
| `[Vault Name]` | The connected vault folder's name | `Acme Knowledge Base` |
| `[agent-tag]` | `#` + first letter of the agent name (lowercased) + `-note` | `Atlas` → `#a-note` |

**Tag fallback:** if the agent name does not start with a letter, use `#kb-note`.

## Destination map

The vault (`[Vault Name]/`) is a **user-owned folder** connected to the conversation alongside the agent
project folder, living **outside** the project folder. The project folder holds the boot protocol and
persona; the vault holds all knowledge.

| Template | Written to |
|---|---|
| `boot-protocol-template.md` | `<project folder>/CLAUDE.md` |
| `agent-persona-template.md` | `<project folder>/SOUL.md` (only if none exists) |
| `vault-structure.md` | reference only — not copied; the schema is mirrored into `Meta/Conventions.md` |
| `vault-skeleton/**` | `[Vault Name]/**` (Branch B only — when there is no seed `.zip` to extract) |

## Branch A vs Branch B

- **Branch A (seed `.zip` provided):** extract the zip into the vault folder; do **not** copy
  `vault-skeleton/` over it. The skeleton is used only for verification reference.
- **Branch B (no seed):** copy `vault-skeleton/**` into the vault, substituting tokens, then continue.
