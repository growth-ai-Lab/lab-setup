# Knowledge
[origin: core]

One note per discrete, verifiable claim. Each Knowledge note links back to the Source(s) it came from via
`sources:` and is tagged with exactly one `domain`. Facts the user knows without a documented source are
legitimate: use `source_type: internal` and do not fabricate a citation. Filename: `<slug>.md`.
See `Meta/Conventions.md`.
