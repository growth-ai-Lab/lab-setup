---
type: knowledge
claim: "Self-serve SMB SaaS averages roughly 4.2% monthly churn."
domain: market
sources: ["[[Sources/2025-01-15_example-market-report]]"]
source_type: example
data_as_of: 2025-01-15
review_status: example
created_by: knowledge-base-init
created_date: 2025-01-15
last_updated_by: knowledge-base-init
last_updated: 2025-01-15
---

# EXAMPLE — SMB churn benchmark

> [!example] Teaching sample. Not real data; never used as evidence.

A Knowledge note isolates **one** discrete, verifiable claim and points back at the Source it came from
via `sources:`. Keep the body short: the claim, the exact figure, and any caveats about scope or
`data_as_of` staleness. This note is the unit that Hypotheses cite as evidence.
