---
type: hypothesis
claim: "A guided onboarding flow will cut first-90-day SMB churn below the 4.2% monthly benchmark."
domain: growth-trajectory
evidence: ["[[Knowledge/example-smb-churn-benchmark]]"]
falsification_criterion: "90-day churn for the onboarding cohort is not lower than the control cohort."
addresses: "gap: high early-stage SMB churn eroding net revenue"
status: proposed
created_by: knowledge-base-init
created_date: 2025-01-15
last_updated_by: knowledge-base-init
last_updated: 2025-01-15
---

# EXAMPLE — Guided onboarding reduces early churn

> [!example] Teaching sample. Not real data.

A Hypothesis note is a testable bet built from Knowledge (via `evidence:`, never citing Sources directly).
It states what would **disprove** it (`falsification_criterion`) and which gap/need it `addresses`. Its
`status` moves proposed → testing → supported/refuted as evidence accumulates.
