# Hypotheses
[origin: core]

One note per testable product/growth hypothesis. Hypotheses cite Knowledge notes as `evidence:` (never
Sources directly), state a one-sentence `falsification_criterion`, and name the gap or need they
`addresses`. Filename: `<slug>.md`. See `Meta/Conventions.md`.
