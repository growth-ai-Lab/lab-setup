# Sources
[origin: core]

One note per external source consulted — report, article, webpage, dataset, interview. A Source note is
the origin of a fact; it cites nothing itself. Filename: `<yyyy-mm-dd>_<slug>.md` (date ingested).
See `Meta/Conventions.md` for the required frontmatter.
