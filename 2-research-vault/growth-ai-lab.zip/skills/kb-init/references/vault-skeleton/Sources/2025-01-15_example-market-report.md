---
type: source
title: "EXAMPLE — SMB SaaS Market Outlook 2025 (teaching sample, not real data)"
domain: market
source_type: example
url: https://example.com/smb-saas-outlook-2025
author: Example Analytics
published: 2025-01-15
data_as_of: 2025-01-15
review_status: example
created_by: knowledge-base-init
created_date: 2025-01-15
last_updated_by: knowledge-base-init
last_updated: 2025-01-15
---

# EXAMPLE — SMB SaaS Market Outlook 2025

> [!example] This is a worked teaching example shipped with the seed. It is **not real data** and must
> never be counted as evidence. Delete it once the vault has real notes, or keep it as a reference.

A Source note records what was consulted. Notice: full citation metadata in the frontmatter, one
`domain`, `review_status: example`. Below you'd capture the relevant passages or figures, verbatim or
closely paraphrased, with page/section markers so a Knowledge note can point at exactly what it used.

- "The SMB segment is projected to grow 18% YoY through 2026." (p.4)
- "Churn in self-serve SMB SaaS averages 4.2% monthly." (p.11)
