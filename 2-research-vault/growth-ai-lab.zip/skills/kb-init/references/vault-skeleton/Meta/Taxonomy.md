# Taxonomy
[origin: core — extend by explicit user approval only, never rewrite]

The controlled vocabulary of domains for this vault. Every note is tagged with exactly one `domain` from
this list. To add a domain, **append** a new bullet with the approver and date — never rewrite or reorder
the existing entries.

- company — the company itself: strengths, limitations, assets, positioning
- industry — the broader industry / vertical
- market — market size, segments, dynamics, pricing, demand signals
- customer-needs — jobs-to-be-done, pain points, unmet needs
- gaps — where the market or company falls short; whitespace
- growth-trajectory — trends, momentum, forecasts, growth levers

<!-- Added domains (append below, one per line): "- <domain> — <desc>  [added by <who>, <yyyy-mm-dd>]" -->
