# Conventions
[origin: core — the contract every agent working in this vault is bound by]

Read this before writing anything to the vault. It is the shared rulebook: other agents, and future
sessions of the same agent, rely on it because they arrive without this conversation's context. The full
schema (frontmatter fields, examples) lives in the initialization skill's `references/vault-structure.md`;
this file is the operating contract in brief.

## Note types

- **Source** (`Sources/`) — one per external thing consulted. It is the origin; it cites nothing.
- **Knowledge** (`Knowledge/`) — one discrete verifiable claim, citing its Source(s).
- **Hypothesis** (`Hypotheses/`) — a testable claim built from Knowledge notes (not Sources directly).

The chain is always Source → Knowledge → Hypothesis.

## Required frontmatter

Every note carries provenance: `created_by`, `created_date`, `last_updated_by`, `last_updated`.

- Source: `type, title, domain, source_type, data_as_of, geography, review_status` (+ `url/author/published` if known)
- Knowledge: `type, claim, domain, sources, source_type, data_as_of, geography, review_status`
- Hypothesis: `type, claim, domain, evidence, falsification_criterion, addresses, status`

## Filenames

- `Sources/<yyyy-mm-dd>_<slug>.md`
- `Knowledge/<slug>.md`
- `Hypotheses/<slug>.md`

Slugs are lowercase, hyphen-separated, descriptive.

## review_status

- `draft` — captured, not yet verified. Default for anything new.
- `verified` — checked against a live source. **Never set without checking a live source.**
- `example` — shipped teaching example; never counted as evidence.

## Geography / scope

Record the geographic or entity scope of every source and claim in `geography` (global | region | country |
single-entity), inheriting it from source to knowledge. Never present a region- or subsidiary-specific
figure (e.g. an "APAC report" or a US-only filing) as a global or whole-company fact — flag the mismatch.
See the initialization skill's `research-method.md` for the full gathering playbook.

## Domains

One `domain` per note, drawn only from `Meta/Taxonomy.md`. Never invent a domain in a note. New domains
are appended to `Taxonomy.md` with explicit user approval only.

## MOCs

No global index. Each domain has one MOC in `MOCs/`. Add every new note to its domain's MOC, and check
the MOC before creating a note to avoid duplicates.

## No cascade edits

When new information contradicts an existing note, flag it — add a `> [!review]` callout naming the
conflicting note and date, and lower `review_status` to `draft` if it was `verified`. Never silently
rewrite another note. A human or review pass resolves it.

## Multi-agent boot protocol

Before writing anything, an agent must:
1. Read `Meta/Taxonomy.md` and this file.
2. Check the relevant domain MOC before creating a note.
3. Never invent a domain, never skip provenance, never mark `verified` without a live source, never
   cascade-edit.
