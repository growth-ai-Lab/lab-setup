# Market — Map of Content
[origin: core] domain: `market`

Entry point for the **market** domain: market size, segments, dynamics, pricing, demand signals. Every note tagged `domain: market` is linked
below. Check here before creating a note in this domain to avoid duplicates.

## Sources

- [[Sources/2025-01-15_example-market-report]] `example`

## Knowledge

- [[Knowledge/example-smb-churn-benchmark]] `example`

## Hypotheses

<!-- - [[Hypotheses/<slug>]] -->
