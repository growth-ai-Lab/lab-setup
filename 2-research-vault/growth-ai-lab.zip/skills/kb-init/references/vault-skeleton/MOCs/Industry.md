# Industry — Map of Content
[origin: core] domain: `industry`

Entry point for the **industry** domain: the broader industry / vertical the company operates in. Every note tagged `domain: industry` is linked
below. Check here before creating a note in this domain to avoid duplicates.

## Sources

<!-- - [[Sources/<yyyy-mm-dd>_<slug>]] -->

## Knowledge

<!-- - [[Knowledge/<slug>]] -->

## Hypotheses

<!-- - [[Hypotheses/<slug>]] -->
