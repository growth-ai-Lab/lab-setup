# Gaps — Map of Content
[origin: core] domain: `gaps`

Entry point for the **gaps** domain: where the market or company falls short; whitespace. Every note tagged `domain: gaps` is linked
below. Check here before creating a note in this domain to avoid duplicates.

## Sources

<!-- - [[Sources/<yyyy-mm-dd>_<slug>]] -->

## Knowledge

<!-- - [[Knowledge/<slug>]] -->

## Hypotheses

<!-- - [[Hypotheses/<slug>]] -->
