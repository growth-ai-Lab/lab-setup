# Company — Map of Content
[origin: core] domain: `company`

Entry point for the **company** domain: the company itself: strengths, limitations, assets, positioning. Every note tagged `domain: company` is linked
below. Check here before creating a note in this domain to avoid duplicates.

## Sources

<!-- - [[Sources/<yyyy-mm-dd>_<slug>]] -->

## Knowledge

<!-- - [[Knowledge/<slug>]] -->

## Hypotheses

<!-- - [[Hypotheses/<slug>]] -->
