# Growth-Trajectory — Map of Content
[origin: core] domain: `growth-trajectory`

Entry point for the **growth-trajectory** domain: trends, momentum, forecasts, growth levers. Every note tagged `domain: growth-trajectory` is linked
below. Check here before creating a note in this domain to avoid duplicates.

## Sources

<!-- - [[Sources/<yyyy-mm-dd>_<slug>]] -->

## Knowledge

<!-- - [[Knowledge/<slug>]] -->

## Hypotheses

- [[Hypotheses/example-onboarding-reduces-churn]] `example`
