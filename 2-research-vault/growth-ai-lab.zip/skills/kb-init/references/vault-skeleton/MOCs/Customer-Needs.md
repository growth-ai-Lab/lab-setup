# Customer-Needs — Map of Content
[origin: core] domain: `customer-needs`

Entry point for the **customer-needs** domain: jobs-to-be-done, pain points, unmet needs. Every note tagged `domain: customer-needs` is linked
below. Check here before creating a note in this domain to avoid duplicates.

## Sources

<!-- - [[Sources/<yyyy-mm-dd>_<slug>]] -->

## Knowledge

<!-- - [[Knowledge/<slug>]] -->

## Hypotheses

<!-- - [[Hypotheses/<slug>]] -->
