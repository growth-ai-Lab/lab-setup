# Research Method — how the agent gathers before it writes

This is the operating playbook for **doing research** that feeds the vault. The rest of the schema governs
*how notes are structured*; this governs *how you find and vet what goes in them*. These principles were
distilled from real research runs — front-loading them prevents the most common and costly rework:
capturing the wrong things, capturing region-specific figures as if they were global, and discovering the
shape of a source only after crawling it piecemeal.

Follow them in order. The first two happen **before** any gathering.

## 1. Understand the goal first
Before collecting anything, know what decision the research serves and what the deliverable is. A vault
built to support product ideation is tagged and prioritised differently from one built for competitive
monitoring or due diligence. If the objective is fuzzy, ask 1-3 sharp questions (what will this be used
for? what format do you need? what's in scope?) rather than cataloguing everything and bolting the purpose
on afterward. The goal shapes what to capture, how deep to go, and how to tag it.

## 2. Ask what already exists
Ask the user whether prior research, exports, documents, spreadsheets, or a starting vault already exist -
**before** crawling from scratch. This respects their expertise and knowledge, avoids duplicating work
they've already done, and often hands you a better starting point than the open web. (A supplied seed
`.zip` is one form of this; the broader habit is to *ask* at the start of any new research thread, not
just at initial setup.) Reconcile against what they give you instead of building in parallel and merging later.

## 3. Map the estate before crawling
For a website, get the structure before the content. Fetch `robots.txt` and the XML sitemap / sitemap
index first, then enumerate the URL space: how many pages, which sections are core vs long-tail (news,
author bios, legacy/acquired-brand pages), and whether there are separate sub-domains. Scope deliberately
from that map instead of discovering scale one page at a time. The same idea applies beyond the web:
find the index/table-of-contents of any large corpus before reading it.

## 4. Detect rendering mode early
Probe whether pages are server-rendered (plain fetch returns the real content) or client-rendered
(JavaScript-only - a plain fetch returns an empty shell or "enable JavaScript"). Do this once, up front,
on a representative page. Route JavaScript-only pages through a browser tool that executes scripts. Prefer
extracting clean URL lists from the sitemap (and running small scripts in-page) over fetching pages heavy
with navigation boilerplate - it is faster and keeps your context clean.

## 5. Parallelise the gathering
When you have a batch of independent pages or sources to read, fan them out to subagents that fetch and
**distil** in parallel, returning compact findings rather than raw dumps. This keeps the main context lean
and is dramatically faster than reading serially. Reserve serial work for chains where each step depends
on the last.

## 6. Label provenance - especially geography and scope
Record each source's date **and** its geographic/entity scope, and carry that into the notes it produces.
This is crucial: information that is clearly labelled for a **different region or sub-entity** (e.g. an
"Asia Pacific capability report", a US-only filing, a single subsidiary's numbers) must **not** be
presented as global, whole-company, or headquarters fact. When a figure is region- or unit-specific, say
so on the note and flag any place it might be mistaken for the whole. Also keep the standard distinction
between a company's *own claims* and independently *verified* facts (see `review_status`). Getting scope
wrong quietly corrupts everything built on top of it.

## Verify as you go
Cross-check load-bearing figures rather than trusting the first occurrence. Real sources contradict
themselves (e.g. two "headcount" numbers on different pages) - when they do, record both with their dates
and flag the conflict per the no-cascade-edit rule instead of silently picking one.

---

**In short:** clarify the goal -> ask what exists -> map before you crawl -> detect rendering mode -> fetch in
parallel -> label date-and-scope on everything. Plan first; the gathering goes faster and cleaner when you
know the shape of the thing before you touch it.
