# Vault Structure — Citation-First Knowledge Base

This is the canonical schema for the shared knowledge vault. It is self-contained: every convention the
initialization wizard and every future agent needs lives here, so no external document is required. When
in doubt about a field, a filename, or a rule, this file wins — and if this file and an agent's own
instructions disagree, this file still wins, because the vault outlives any single conversation.

> **Why this exists.** This is a *shared, citation-first* knowledge base, not a personal memory file.
> Its rules must live in the vault itself, because other agents — and future sessions of you — will work
> here without this conversation's context. Never assume a convention; read it here or write it here.

> **How to gather.** This file governs how notes are *structured*. For how to *find and vet* what goes in
> them — understand the goal, ask what already exists, map before crawling, detect rendering mode,
> parallelise, and label geography/scope — see `research-method.md` in this folder.

## Table of contents

1. What this vault is for
2. Top-level folder structure
3. The taxonomy (domains)
4. The three note types
5. Frontmatter schemas per note type
6. Filename conventions
7. `review_status` and provenance
8. MOCs (Maps of Content)
9. The no-cascade-edit rule
10. Multi-agent boot protocol

---

## 1. What this vault is for

The vault accumulates verifiable knowledge about a company and its market so that product and growth
hypotheses can be built on evidence rather than memory. Every non-obvious claim traces back to a source.
Hypotheses trace back to the knowledge that supports them. Nothing important is ever silently overwritten.

## 2. Top-level folder structure

```
<Vault>/
├── Meta/          Governance: Taxonomy.md, Conventions.md, Seed-Manifest.md (if seeded)
├── Sources/       One note per external source (report, article, page, dataset)
├── Knowledge/     One note per discrete, verifiable claim, each citing its source(s)
├── Hypotheses/    Testable product/growth hypotheses built from Knowledge notes
└── MOCs/          One Map of Content per taxonomy domain — the entry points
```

Each of `Sources/`, `Knowledge/`, `Hypotheses/`, `MOCs/` holds a short `_README.md` stating its purpose.

## 3. The taxonomy (domains)

Domains are the vault's controlled vocabulary. Every note is tagged with exactly one `domain`. The
default seed domains are:

- `company` — the user's own company: strengths, limitations, assets, positioning
- `industry` — the broader industry / vertical the company operates in
- `market` — market size, segments, dynamics, pricing, demand signals
- `customer-needs` — jobs-to-be-done, pain points, unmet needs
- `gaps` — where the market or the company falls short; whitespace
- `growth-trajectory` — trends, momentum, forecasts, growth levers

Domains live in `Meta/Taxonomy.md`. **Never invent a new domain in a note.** New domains are added to
`Taxonomy.md` only with explicit user approval, by appending (never rewriting), with a note of who added
it and when.

## 4. The three note types

| Type | Folder | Answers | Cites |
|---|---|---|---|
| **Source** | `Sources/` | "What did I read/consult?" | nothing — it *is* the origin |
| **Knowledge** | `Knowledge/` | "What discrete fact is true, and how do I know?" | one or more Sources (or `internal`/`example`) |
| **Hypothesis** | `Hypotheses/` | "What might be true and worth acting on?" | Knowledge notes (never Sources directly) |

The chain is always **Source → Knowledge → Hypothesis**. Hypotheses cite evidence (Knowledge), not raw
sources, so the reasoning stays inspectable.

## 5. Frontmatter schemas per note type

Every note carries provenance: `created_by`, `created_date`, `last_updated_by`, `last_updated`.

**Source note**
```yaml
---
type: source
title: <human title of the source>
domain: <one taxonomy domain>
source_type: report | article | webpage | dataset | interview | internal | example
url: <link if external, else omitted>
author: <source author/publisher if known>
published: <yyyy-mm-dd if known>
data_as_of: <yyyy-mm-dd — the date the information reflects>
geography: <scope the source covers: global | region (e.g. apac, emea) | country | single-entity/subsidiary>
review_status: draft | verified | example
created_by: <agent or user>
created_date: <yyyy-mm-dd>
last_updated_by: <agent or user>
last_updated: <yyyy-mm-dd>
---
```

**Knowledge note**
```yaml
---
type: knowledge
claim: <one-sentence statement of the fact>
domain: <one taxonomy domain>
sources: [<link to Source note>, ...]   # omit or use internal/example when no external source
source_type: external | internal | example
data_as_of: <yyyy-mm-dd>
geography: <scope the claim holds for: global | region | country | single-entity — inherit from the source>
review_status: draft | verified | example
created_by: <agent or user>
created_date: <yyyy-mm-dd>
last_updated_by: <agent or user>
last_updated: <yyyy-mm-dd>
---
```

**Hypothesis note**
```yaml
---
type: hypothesis
claim: <the hypothesis in one sentence>
domain: <one taxonomy domain>
evidence: [<link to Knowledge note>, ...]   # Knowledge notes, NOT Sources
falsification_criterion: <one sentence — what observation would disprove this>
addresses: <the gap or customer-need this speaks to>
status: proposed | testing | supported | refuted
created_by: <agent or user>
created_date: <yyyy-mm-dd>
last_updated_by: <agent or user>
last_updated: <yyyy-mm-dd>
---
```

## 6. Filename conventions

- Sources: `Sources/<yyyy-mm-dd>_<slug>.md` (date the source was ingested)
- Knowledge: `Knowledge/<slug>.md`
- Hypotheses: `Hypotheses/<slug>.md`

Slugs are lowercase, hyphen-separated, and descriptive (`smb-churn-benchmark`, not `note1`).

## 7. `review_status` and provenance

- `draft` — captured but not yet verified against a live source. The default for anything new.
- `verified` — checked against a live source by a human or a review-agent pass. **Never mark `verified`
  without actually checking a live source.**
- `example` — a worked teaching example shipped with the seed; not real data, never counted as evidence.

Provenance fields are required on **every** note, including an agent's own. `internal` knowledge (a fact
the user knows but has no documented source for) is legitimate: set `source_type: internal`,
`review_status: draft`, and do not fabricate a citation.

**Geography / scope.** Record the geographic or entity scope of every source and claim in the `geography`
field, and inherit it from source to knowledge. This matters as much as the date: a figure from a
region-specific or single-subsidiary document (e.g. an "Asia Pacific capability report", a US-only
filing) must never be presented as a global or whole-company fact. When a claim is region- or
unit-specific, keep `geography` accurate and flag anywhere it could be mistaken for the whole. Prefer a
`geography: global` claim over a regional one when both exist for the same fact.

## 8. MOCs (Maps of Content)

There is **no single global index**. Instead, each taxonomy domain has one MOC in `MOCs/` (e.g.
`MOCs/Market.md`) that links the notes belonging to that domain. When you create a note, add it to its
domain's MOC. Before creating a note, check the relevant MOC to avoid duplicating what already exists.

## 9. The no-cascade-edit rule

When new information seems to contradict an existing note, **do not silently rewrite the old note.** Flag
it for review instead: add a short `> [!review]` callout at the top of the affected note naming the
conflicting note and the date, and lower its `review_status` to `draft` if it was `verified`. A human (or
a review-agent pass) resolves the contradiction. This keeps history honest and prevents one agent's new
read from erasing another's verified work.

## 10. Multi-agent boot protocol

Any agent — including a future session of you — must, before writing anything to this vault:

1. Read `Meta/Taxonomy.md` and `Meta/Conventions.md`. These are the contract.
2. Check the relevant domain MOC before creating a note.
3. Never invent a new domain (append to `Taxonomy.md` only with explicit user approval).
4. Never skip provenance fields.
5. Never mark `verified` without checking a live source.
6. Never cascade-edit — flag contradictions per §9.

If `Meta/Conventions.md` is missing or empty, stop and tell the user; do not proceed on assumptions.
