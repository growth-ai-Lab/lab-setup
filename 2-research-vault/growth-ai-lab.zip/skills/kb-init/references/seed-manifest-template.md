# Seed-Manifest (template)

A seed `.zip` must contain this file at `Meta/Seed-Manifest.md`. It lets the initialization wizard verify,
in Branch A, that every expected file actually arrived — so a truncated or corrupted download is caught
before any agent starts trusting the vault. Whoever packages a seed fills this in; the wizard reads it.

```markdown
# Seed Manifest
version: 1.0.0
created_date: <yyyy-mm-dd>
created_by: <who packaged this seed>

## Files
- Meta/Taxonomy.md
- Meta/Conventions.md
- Sources/_README.md
- Knowledge/_README.md
- Hypotheses/_README.md
- MOCs/Company.md
- MOCs/Industry.md
- MOCs/Market.md
- MOCs/Customer-Needs.md
- MOCs/Gaps.md
- MOCs/Growth-Trajectory.md
# (list every additional file the seed ships, including any worked examples)
- Sources/2025-01-15_example-market-report.md
- Knowledge/example-smb-churn-benchmark.md
- Hypotheses/example-onboarding-reduces-churn.md
```

Verification rule: the wizard confirms every path listed here exists in the unpacked folder. If any is
missing, it stops and tells the user rather than reconstructing the file from memory.
