---
name: kb-init
description: >
  Initialize a shared, citation-first knowledge base and the research agent that operates it. Use this
  skill whenever the user wants to set up, bootstrap, scaffold, seed, or stand up a knowledge base,
  knowledge vault, research vault, or "second brain" for a company/market — especially when a starting
  knowledge base is supplied as a .zip seed to unpack and verify. Trigger on phrases like "initialize my
  knowledge base", "set up the research vault", "unpack this knowledge-base seed", "bootstrap a
  citation-first vault", or "create a knowledge base and an agent to maintain it", even if the user
  doesn't name the note types or schema. Also use it to verify or repair an existing vault's governance
  files (Taxonomy, Conventions, MOCs).
metadata:
  version: 1.1.0
---

# Knowledge-Base Init

This skill stands up a **shared, citation-first knowledge base** and the **research agent** that will
maintain it, in one guided pass. The knowledge base is a governed, multi-agent vault — its rules live in
the vault itself, not in any one agent's instructions, so other agents and future sessions can work in it
without today's context. Your job is to do the setup work while the user just answers a few questions.

Keep the conversation in plain language. Don't expose file paths, frontmatter fields, or schema internals
unless the user asks — but always *write* the conventions to disk, because that is what makes the vault
usable by other agents later.

## The two things you're setting up

1. **The vault** — a user-owned folder (the knowledge base itself: `Meta/`, `Sources/`, `Knowledge/`,
   `Hypotheses/`, `MOCs/`). It holds all knowledge and its own rulebook. It lives **outside** the agent's
   project folder so the user owns it.
2. **The agent** — a boot protocol (`CLAUDE.md`) and persona (`SOUL.md`) written into the project folder,
   turning this Claude into a research analyst that reads the vault's contract before every write.

## Bundled templates

All under this skill's `references/` folder (paths below are relative to the skill directory):
- `vault-structure.md` — the canonical, self-contained schema (note types, frontmatter, conventions).
  This is the source of truth for the rules; read it before writing governance files.
- `research-method.md` — the gathering playbook the agent follows when researching (understand the goal,
  ask what already exists, map before crawling, detect rendering mode, parallelise, label geography/scope).
  It's referenced by the boot protocol so every session inherits it.
- `boot-protocol-template.md` → becomes the project folder's `CLAUDE.md`.
- `agent-persona-template.md` → becomes the project folder's `SOUL.md`.
- `vault-skeleton/` → copied into the vault **only in Branch B** (no seed zip).
- `PLACEHOLDERS.md` → the token substitution rules (`[Agent Name]`, `[Your Name]`, `[Vault Name]`,
  `[agent-tag]`).

## Two starting conditions — decide first

- **Branch A — a seed `.zip` was provided** (the common case). You unzip and **verify** it; you do not
  rebuild the core files from scratch.
- **Branch B — no seed.** You build the core files from `vault-skeleton/` and the schema in
  `vault-structure.md`.

Determine which branch applies before Step 1.

---

## Step 1 — Locate the target folder

Find or confirm a folder the **user owns** (not inside your own project folder) to hold the vault. If a
`.zip` was supplied, this is where you'll extract it. If no suitable folder is connected, ask the user to
connect one (use `mcp__cowork__request_cowork_directory`), or ask where they'd like it created. Do not
proceed until the folder is confirmed. This folder's name becomes `[Vault Name]`.

## Step 2 — Unpack or scaffold

**Branch A:** Extract the `.zip` into the folder from Step 1. Do **not** modify any extracted file yet,
and do **not** overwrite it with `vault-skeleton/`.

**Branch B:** Copy `references/vault-skeleton/**` into the vault folder, substituting the placeholder
tokens per `references/PLACEHOLDERS.md` as you write each file. This gives you `Meta/Taxonomy.md`,
`Meta/Conventions.md`, the folder `_README.md`s, the six domain MOCs, and the worked examples. Then skip
to Step 4 — there is no manifest to verify.

## Step 3 — Verify seed integrity (Branch A only)

1. Open `Meta/Seed-Manifest.md`. Confirm it lists a version number and a file list.
2. Confirm every file the manifest lists actually exists in the unpacked folder. If anything is missing,
   **stop and tell the user** — do not reconstruct missing seed files from memory.
3. Confirm `Meta/Taxonomy.md` and `Meta/Conventions.md` are both present and non-empty before continuing.

## Step 4 — Confirm or create `Meta/Taxonomy.md`

**Branch A:** Open it. Read the domain list back to the user in plain language (default seed domains:
company, industry, market, customer-needs, gaps, growth-trajectory). Ask if they want to add any
company- or industry-specific sub-domains. If yes, **append** — never rewrite the existing list — and
record who added the entry and when.

**Branch B:** The skeleton already contains the six default domains. Show them to the user, let them add
any, and append (with approver + date) rather than rewriting.

## Step 5 — Confirm or create `Meta/Conventions.md`

**Branch A:** Open and read it. Summarize its contents to the user in plain language: the three note types,
the required frontmatter per type (including the `geography`/scope field), filename rules,
`review_status` values, the no-cascade-edit rule, and the multi-agent boot protocol. Do not let the user skip this — it is the contract every future agent is
bound by.

**Branch B:** The skeleton ships a complete `Conventions.md`. Confirm it's present and read it back. If it
were ever missing, rebuild it from `references/vault-structure.md` (which carries the full schema).

## Step 6 — Confirm the remaining folders

Ensure each exists with its short `_README.md`: `Sources/`, `Knowledge/`, `Hypotheses/`, and `MOCs/` with
one file per taxonomy domain (`Company.md`, `Industry.md`, `Market.md`, `Customer-Needs.md`, `Gaps.md`,
`Growth-Trajectory.md`, plus any domain added in Step 4). Each MOC starts with a heading and a one-line
description of its domain. In Branch B these come from the skeleton; in Branch A verify they're all there.

## Step 7 — Write the agent (CLAUDE.md + SOUL.md)

Now set up the agent that will operate the vault. Ask the user, together in one `AskUserQuestion` call:
1. **Agent name** — what to call the research agent (becomes `[Agent Name]`). Derive `[agent-tag]` per
   `PLACEHOLDERS.md`.
2. **Your name** — what it should call the user (`[Your Name]`).
3. Confirm the vault folder name (`[Vault Name]`).

Then:
- Read `references/boot-protocol-template.md`, substitute all tokens, and write it to `CLAUDE.md` at the
  **project folder root** (not the vault). This is the permanent boot protocol — it makes every future
  session read `Taxonomy.md` and `Conventions.md` before writing.
- If no `SOUL.md` exists at the project root, read `references/agent-persona-template.md`, substitute
  tokens, and write it. If one exists, leave it alone.

## Step 8 — Ask the setup questions, one batch

Ask the user together (one `AskUserQuestion` call):
1. Company name and a one-line description.
2. Primary industry / vertical.
3. Which product area(s) or markets to start mapping first.
4. Who else will write to this vault — this agent only, or other named agents/tools? (Determines how
   strictly to apply the concurrency conventions.)
5. Who verifies claims — the user personally, or a second-agent review pass? (Determines how
   `review_status` is used going forward.)

## Step 9 — Seed the user's own known facts

Interview the user briefly on what they already know: company strengths/limitations, known competitors,
market facts, customer needs and gaps, anything about growth trajectory. For each fact volunteered
**without** a documented source, create a Knowledge note with `source_type: internal`,
`review_status: draft`, and **no** `sources` link — do not fabricate a citation. Tag its `domain` and set
`data_as_of` (use today's date if they can't give a more specific one, and say so). Add each to its
domain MOC.

## Step 10 — Ingest one real external source, live

**Branch A with a worked example:** first walk the user through the shipped example — its Source note, the
Knowledge note it produced, and how it links into an MOC — before doing a real one.

Then, with the user, ingest one actual source for their company (a market report, competitor page, analyst
article):
1. Create the Source note with full citation metadata.
2. Extract one or two Knowledge notes, each linking back via `sources:` and tagged with the right
   `domain`, `data_as_of`, and `geography`/scope — flag if the source is region- or subsidiary-specific
   rather than global (see `references/research-method.md`).
3. Add all of them to the relevant domain MOC(s).

## Step 11 — Draft one real hypothesis, live

Using the Knowledge notes now in the vault, write one testable hypothesis end to end: the claim,
`evidence:` links to supporting Knowledge notes (not Sources), a one-sentence `falsification_criterion`,
the gap/need it `addresses`, and `status: proposed`. Add it to the relevant domain MOC(s).

## Step 12 — Explain the maintenance loop

Tell the user in plain language: how stale `data_as_of` dates get flagged, how a contradiction between an
old claim and new information is handled (flagged for review, never silently rewritten), how `draft` notes
get promoted to `verified` (only after a live-source check), and roughly how often they'll be asked to
review something.

## Step 13 — Offer a periodic vault-health pass

Ask if they want a scheduled weekly or monthly check that sweeps for: stale `data_as_of` dates, Knowledge
notes with no `sources` link (other than `internal`/`example`), and everything still in `draft`. If yes,
schedule it with `mcp__scheduled-tasks__create_scheduled_task`; if no, note it can be run on demand.

## Step 14 — Close

Tell the user briefly: where the taxonomy and conventions live, what's now in the vault, how they'd add
the next source/claim/hypothesis themselves, and — because this is a multi-agent vault — that any agent
(including a future you) must read `Meta/Taxonomy.md` and `Meta/Conventions.md` first, exactly as you did.

---

## Do not

- Do not invent a new taxonomy domain without the user's explicit approval.
- Do not mark anything `verified` without checking it against a live source.
- Do not silently rewrite another note when new information contradicts it — flag it instead.
- Do not create a single global index that every note must be added to — use the per-domain MOCs.
- Do not skip provenance fields, even on your own notes — including `geography`/scope.
- Do not present region- or subsidiary-specific figures as global/whole-company facts; label the scope.
- Do not overwrite an extracted seed with the bundled skeleton (Branch A).

## Reference

The full schema — every frontmatter field, filename rule, and example — is in
`references/vault-structure.md`. Read it before writing or repairing any gover