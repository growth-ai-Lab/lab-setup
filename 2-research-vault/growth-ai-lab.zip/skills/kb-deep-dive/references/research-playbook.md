# Research Playbook — gathering for a deep-dive

Read this before the Step 4 gathering. These principles were distilled from real research runs; they
prevent the most common and costly rework: capturing the wrong things, treating region-specific figures as
global, and discovering the shape of a source only after crawling it piecemeal. In a deep-dive the goal is
already set and the "what do we already know" question is answered by the existing knowledge itself — so
the work here is efficient, well-scoped *gathering* to fill named gaps.

## Map the estate before crawling
Get structure before content. For a website, fetch `robots.txt` and the XML sitemap / sitemap index first,
then enumerate the URL space: how big is it, which sections are core vs long-tail (news, author bios,
legacy/acquired-brand pages), are there separate sub-domains? Scope deliberately from that map instead of
discovering scale one page at a time. For any large corpus, find its index / table of contents before reading.

## Detect rendering mode early
Probe once, on a representative page, whether it is server-rendered (a plain fetch returns the real
content) or client-rendered (JavaScript-only — a plain fetch returns an empty shell or an "enable
JavaScript" message). Route JavaScript-only pages through a browser tool that executes scripts. Prefer
pulling clean URL lists from the sitemap (and running small scripts in-page) over fetching pages heavy with
navigation boilerplate — it's faster and keeps your context clean.

## Parallelise the gathering
When you have a batch of independent pages or sources to read, fan them out to subagents that fetch and
**distil** in parallel, returning compact findings rather than raw dumps. This keeps the main context lean
and is dramatically faster than reading serially. Keep serial work only for chains where each step depends
on the previous one.

## Draw on the existing evidence base
Before gathering anything new, reuse sources the knowledge base already cites where they cover the gap. A
deep-dive extends an evidence base; it shouldn't re-source facts that are already well-cited. New sources
are for genuine gaps.

## Label provenance — especially geography and scope
Record each source's date **and** its geographic/entity scope, and carry that into whatever you write.
This matters as much as the date: material clearly labelled for a **different region or sub-entity** (e.g.
an "Asia Pacific capability report", a US-only filing, a single subsidiary's numbers) must **not** be
presented as global, whole-organisation, or headquarters fact. When a figure is region- or unit-specific,
say so, and flag anywhere it could be mistaken for the whole. Keep the distinction between a source's *own
claims* and independently *verified* facts.

## Verify as you go
Cross-check load-bearing figures rather than trusting the first occurrence. Real sources contradict
themselves (e.g. two different headcount numbers on different pages); when they do, record both with their
dates and flag the conflict rather than silently picking one.

---

**In short:** map before you crawl → detect rendering mode → fetch in parallel → reuse existing sources
first → label date-and-scope on everything → verify the load-bearing numbers.
