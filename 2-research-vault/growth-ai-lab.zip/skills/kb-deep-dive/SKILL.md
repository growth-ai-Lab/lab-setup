---
name: kb-deep-dive
description: >
  Perform a focused deep-dive into a topic that draws on and EXTENDS an existing body of notes or
  knowledge - not a one-off web search. Use whenever the user wants to go deeper on a subject they
  already have notes/research about and have the findings folded back in. Triggers: "do a deep dive on X",
  "go deeper on X", "research X and add it to our notes/vault", "expand/build on what we know about X",
  "flesh out the section on X", or pointing at an existing notes folder to extend it - even without the
  word "vault". Explicitly includes client-research and product-development framings: "research my client
  Acme's market and add it to our vault", "deepen our product-development research on X", "tune our vault toward a
  client/business line". Prefer over generic research
  when there is prior knowledge to build on and output should be written back into it. Schema-agnostic:
  learns the existing note style and conforms to it. For standing up a NEW vault, use kb-init.
metadata:
  version: 1.0.0
---

# Deep-Dive (draw on and extend existing knowledge)

A deep-dive is different from open-web research in one decisive way: **there is already knowledge here, and
your job is to build on it, not beside it.** You first learn what's already known and how it's organised,
then you research only what's missing, then you fold the new findings back in using the *existing* house
style — and finish with a short briefing so the person can see what changed.

Two outputs, always: (1) new/updated notes written into the existing knowledge in its own conventions, and
(2) a written synthesis briefing of what you learned, added, and still don't know.

The skill is **schema-agnostic**. It does not assume any particular note format. If the knowledge is a
governed citation-first vault, obey its contract; if it's a loose folder of markdown, match that. Learn the
structure before you touch it — imposing a foreign format is the most common way a deep-dive damages an
existing knowledge base.

---

## Step 0 — Understand the goal
Before anything, know what the deep-dive is *for* and how deep to go. A dive to support a product decision
is scoped differently from one to brief an exec or settle a factual dispute. If the objective or the topic
boundary is fuzzy, ask 1–3 sharp questions (what will this inform? how deep? what's in/out of scope?). The
goal decides what to capture and when you're done — without it you'll over- or under-dig.

## Step 1 — Locate and learn the existing knowledge
Find the existing notes/vault (ask the user to point at the folder if it isn't obvious; request access if
needed). Then **learn its house style before writing anything**:
- How are notes structured — filenames, frontmatter fields, tags, how they link to each other?
- Is there a governing contract (e.g. `Conventions.md`, `Taxonomy.md`, a README, an index/MOC)? If so,
  read it and treat it as binding. If not, infer the conventions from a few representative notes.
- How is provenance handled — citations, dates, source links? Match whatever exists.

You are a guest in someone's knowledge base. Conform to it. If you genuinely can't tell the conventions,
state your best read and confirm with the user rather than guessing.

## Step 2 — Draw on what's already known
Read the existing notes on the topic **first**, and inventory what the knowledge base already asserts:
established facts, open questions, stale or uncited claims, and where the topic connects to adjacent notes.
This does two things: it stops you duplicating work, and it turns the dive into *extension* — you now know
the specific gaps worth filling. Write down (for the briefing) what was already known before you add anything.

## Step 3 — Scope the gaps
From Step 2, name the concrete gaps this dive will close: missing sub-topics, unsupported claims that need a
source, stale figures needing a refresh, contradictions to resolve, or the specific new angle the user
asked for. This gap list is your research plan — it keeps the dive focused instead of re-summarising what's
already there.

## Step 4 — Research to fill the gaps
Gather new material for the gaps, following the research playbook in `references/research-playbook.md`.
The essentials: map a source before crawling it (sitemaps/indexes first), detect whether pages are
server- or JavaScript-rendered and route accordingly, fan independent fetches out to subagents that return
distilled findings, and record each source's date **and geographic/entity scope**. Reuse sources already
cited in the vault where they cover the gap — draw on the existing evidence base, don't just bolt on new.

## Step 5 — Extend the knowledge (in its own style)
Write the new findings back into the existing knowledge, matching the conventions learned in Step 1:
- New atomic notes / entries in the same format, filename pattern, and linking style as their neighbours.
- Link new material into the existing indexes/MOCs/parent notes so it's discoverable, not orphaned.
- **Carry provenance, including geography/scope.** Never present a region- or subsidiary-specific figure as
  a global/whole fact — label the scope. Distinguish the source's own claims from independently verified facts.
- **Never silently overwrite.** When a new finding contradicts an existing note, flag the conflict (a short
  review callout naming the note and date) and leave the original for a human to resolve. Extending
  knowledge must not erase it.

## Step 6 — Synthesise the briefing
Finish with a concise written briefing (in your reply, not buried in the vault) using this structure:

```
## Deep-dive: <topic>
**Goal:** <what this dive was for>
**Already known (before):** <2–5 bullets of what the vault already had>
**What I added:** <new notes/claims, each linking to where it now lives + its source>
**Changed / contradicted:** <anything that conflicts with prior notes — flagged, not overwritten>
**Still open:** <gaps that remain, stale items, things needing verification>
**Suggested next dive:** <the most valuable follow-up>
```

Keep it tight — it's a map of what moved, not a re-dump of the content.

---

## Do not
- Do not impose a note format foreign to the existing knowledge — learn and match the house style first.
- Do not re-summarise what the vault already knows; spend the effort on the gaps.
- Do not silently overwrite or "correct" existing notes — flag contradictions for a human.
- Do not drop provenance, dates, or geographic/entity scope on anything you add.
- Do not present region- or unit-specific figures as global/whole-company facts.
- Do not treat a source's own marketing claims as verified fact — mark the distinction.

## Reference
`references/research-playbook.md` — how to gather efficiently (map before crawl, rendering-mode detection,
parallelise, label date-and-scope, verify). Read it before the Step 4 gathering.
