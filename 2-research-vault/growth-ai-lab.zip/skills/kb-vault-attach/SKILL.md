---
name: kb-vault-attach
description: >
  Attach an EXISTING citation-first research vault (or research-notes folder) to an already-bootstrapped
  personal Claude agent, so one agent can operate both its personal memory and a separate research
  knowledge base without mixing them. Use when someone set up a personal agent (via setup-agent) and now
  wants it to also work in a research/knowledge vault. Triggers: "connect my research vault to my agent",
  "attach the Howden knowledge base to my assistant", "make my agent use my client research KB", "hook up
  my research notes to my agent", "my agent should also work in my research vault". Attach-only: it wires
  up the connection and appends a boot addendum that puts the agent in evidence-first mode inside the
  research vault; it does NOT create or seed the vault (use kb-init) and does NOT do the
  research (use kb-deep-dive). Keeps personal memory and shared research cleanly separate.
metadata:
  version: 1.0.0
---

# Attach Research Vault (bridge an existing agent to a research KB)

This skill connects an **existing** research knowledge base to a personal agent that was already set up
with `setup-agent`, and teaches that one agent to work in both — its **personal memory vault** (who the
user is, projects, daily notes, persona) and a **separate research vault** (external, cited knowledge) —
**without letting the two contracts bleed into each other.**

Why keep them separate: a personal-memory vault records what happened and who the user is (private,
low-citation); a research vault holds verifiable, cited knowledge that is often shared or client-specific.
Merging them erodes the citation discipline and creates a privacy problem. So we don't merge — we attach,
and give the agent a clear rule for switching modes.

**Attach-only.** This skill does not create, scaffold, or seed a research vault (that's
`kb-init`), and it does not perform research (that's `kb-deep-dive`). It wires up the connection
and writes the boot addendum. If the research vault doesn't exist yet, stop and point the user to
`kb-init` first.

---

## Step 0 — Confirm both pieces exist
- **The agent:** a project folder with a `CLAUDE.md` boot protocol and a personal `<Agent Name> Vault`
  (the output of `setup-agent`). If there's no bootstrapped agent, stop — point the user to `setup-agent`.
- **The research vault:** an existing folder of research — either a `kb-init` vault (has
  `Meta/Conventions.md` + `Meta/Taxonomy.md`) or any existing research-notes folder. If none exists yet,
  stop and point the user to `kb-init`. Do not create one here.

## Step 1 — Connect the research vault
Ensure the research-vault folder is connected to the conversation **alongside** the personal vault (ask the
user to add it / use `mcp__cowork__request_cowork_directory` if it isn't). Confirm you can read both. Note
the research vault's folder name and path — you'll register them in the addendum.

## Step 2 — Learn the research vault's contract (don't assume)
Read its governing files if present: `Meta/Conventions.md` and `Meta/Taxonomy.md` (a `kb-init`
vault). If there's no explicit contract, infer the house style from a few representative notes — filename
pattern, frontmatter, how notes link, how provenance is recorded. You are a guest here; conform to what
exists rather than imposing a format. Record whether the vault is *governed* (has a contract) or *informal*.

## Step 3 — Append the boot addendum to CLAUDE.md
Append the block below to the **workspace `CLAUDE.md`** (the agent's boot protocol), substituting the
vault name(s) and path(s). Rules:
- **Append only** — never edit or reorder the existing personal-memory boot steps.
- **Idempotent** — the block is delimited by the markers below. If it already exists, update the vault
  list in place instead of adding a second block. Support multiple attached research vaults (one bullet each).

```markdown
<!-- BEGIN attached-research-vaults (managed by kb-vault-attach) -->
## Attached research vault(s)

Besides your personal memory vault, one or more **citation-first research knowledge bases** are connected.
These are NOT personal memory — treat them under a different contract:

- **<Research Vault Name>** — `<path or connected-folder name>` — <governed | informal> research KB.

When working in a research vault (reading it, or when asked to add to it):
1. **Keep the two separate.** Personal memory, persona, daily notes and projects live in your
   `<Agent Name> Vault`. External, cited research lives in the research vault. Never copy personal or
   private context into a shared research vault.
2. **Load its contract first.** If the research vault has `Meta/Conventions.md` / `Meta/Taxonomy.md`, read
   them and treat them as binding while you work there. Otherwise infer and match its house style.
3. **Evidence-first mode.** Every claim cites a source; carry provenance including date and
   geography/scope; never present a region- or subsidiary-specific figure as a global/whole fact;
   distinguish a source's own claims from independently verified facts; never cascade-overwrite — flag
   contradictions for a human.
4. **Use the right skill.** For a research pass that draws on and extends the vault, use `kb-deep-dive`. To
   stand up a NEW research vault, use `kb-init`.
5. This attachment does **not** change the personal-memory boot sequence above; that still runs first.
<!-- END attached-research-vaults -->
```

## Step 4 — Verify
Re-read the addendum you wrote. Confirm the agent can reach both the personal vault and each research
vault. Do a quick smoke test: list the research vault's entry points (its MOCs/index or a couple of
representative notes) to prove the connection and that you've read the house style correctly.

## Step 5 — Explain and hand off
Tell the user in plain language: their agent now operates two spaces — personal memory and the attached
research KB(s) — and switches into evidence-first mode in the latter. For an actual research pass they run
`kb-deep-dive`; to create another research vault they run `kb-init`. Mention how to **detach**:
remove the delimited block from `CLAUDE.md` (and disconnect the folder) — nothing else changes.

---

## Do not
- Do not create, scaffold, or seed a research vault — that's `kb-init`. This skill only attaches.
- Do not perform the research itself — that's `kb-deep-dive`.
- Do not merge the vaults or move personal notes into the research vault (privacy + contract integrity).
- Do not rewrite or reorder the existing personal-memory boot steps — append the delimited block only.
- Do not duplicate the addendum on re-runs — update the existing block in place.
