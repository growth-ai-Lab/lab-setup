---
type: knowledge
claim: Howden manages approximately US$38bn of premium on behalf of clients.
domain: company
sources:
  - "[[2026-07-01_howden-about-page]]"
source_type: external
data_as_of: 2026-07-01
geography: global
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Howden manages approximately US$38bn of premium on behalf of clients.

**Domain:** company · **Geography/scope:** global · **Data as of:** 2026-07-01 · **Status:** draft

Sources: [[2026-07-01_howden-about-page]]
