---
type: knowledge
claim: SMEs are under-protected on cyber and value embedded incident-response; Howden's Cyber+ grew at ~3x the broader market by improving SME access.
domain: customer-needs
sources:
  - "[[2025-09-01_cyber-report-2025]]"
source_type: external
data_as_of: 2025-09-01
geography: europe
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# SMEs are under-protected on cyber and value embedded incident-response; Howden's Cyber+ grew at ~3x the broader market by improving SME access.

**Domain:** customer-needs · **Geography/scope:** europe · **Data as of:** 2025-09-01 · **Status:** draft

Sources: [[2025-09-01_cyber-report-2025]]
