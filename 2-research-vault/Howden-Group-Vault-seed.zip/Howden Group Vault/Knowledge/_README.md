# Knowledge

One discrete, verifiable claim per note, each citing its Source(s) and tagged with domain + geography.
