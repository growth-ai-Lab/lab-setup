---
type: knowledge
claim: Physical-risk insurance premiums are projected to rise ~50% by 2030.
domain: market
sources:
  - "[[2026-06-01_csrd-article]]"
source_type: external
data_as_of: 2026-06-01
geography: global
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Physical-risk insurance premiums are projected to rise ~50% by 2030.

**Domain:** market · **Geography/scope:** global · **Data as of:** 2026-06-01 · **Status:** draft

Sources: [[2026-06-01_csrd-article]]
