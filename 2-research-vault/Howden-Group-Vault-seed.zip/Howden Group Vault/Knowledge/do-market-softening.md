---
type: knowledge
claim: The D&O market is bottoming out after a multi-year price decline, with AI, cyber and private-credit exposures driving new claims.
domain: market
sources:
  - "[[2026-04-29_do-report-2026]]"
source_type: external
data_as_of: 2026-04-29
geography: global
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# The D&O market is bottoming out after a multi-year price decline, with AI, cyber and private-credit exposures driving new claims.

**Domain:** market · **Geography/scope:** global · **Data as of:** 2026-04-29 · **Status:** draft

Sources: [[2026-04-29_do-report-2026]]
