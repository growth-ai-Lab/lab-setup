---
type: knowledge
claim: In Asia Pacific, Howden Specialty's marine team has 10+ specialists across 160+ markets and its cargo team 40+ specialists handling US$200m+ premium p.a. — an APAC-hub figure, not a global total.
domain: company
sources:
  - "[[2023-10-01_marine-cargo-apac-pdf]]"
source_type: external
data_as_of: 2023-10-01
geography: apac
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# In Asia Pacific, Howden Specialty's marine team has 10+ specialists across 160+ markets and its cargo team 40+ specialists handling US$200m+ premium p.a. — an APAC-hub figure, not a global total.

**Domain:** company · **Geography/scope:** apac · **Data as of:** 2023-10-01 · **Status:** draft

Sources: [[2023-10-01_marine-cargo-apac-pdf]]
