---
type: knowledge
claim: Howden announced (Nov 2025) the acquisition of Evelyn Partners' financial-services/employee-benefits arm (EPFS).
domain: company
sources:
  - "[[2025-11-11_howden-evelyn-partners-epfs]]"
source_type: external
data_as_of: 2025-11-11
geography: uk
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Howden announced (Nov 2025) the acquisition of Evelyn Partners' financial-services/employee-benefits arm (EPFS).

**Domain:** company · **Geography/scope:** uk · **Data as of:** 2025-11-11 · **Status:** draft

Sources: [[2025-11-11_howden-evelyn-partners-epfs]]
