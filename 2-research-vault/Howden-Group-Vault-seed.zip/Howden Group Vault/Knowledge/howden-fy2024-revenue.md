---
type: knowledge
claim: Howden's FY2024 adjusted revenue was £3,010m (+23%; 15% organic) with adjusted EBITDA of £922.2m (~31% margin).
domain: company
sources:
  - "[[2025-02-05_howden-fy2024-results]]"
source_type: external
data_as_of: 2024-12-31
geography: global
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Howden's FY2024 adjusted revenue was £3,010m (+23%; 15% organic) with adjusted EBITDA of £922.2m (~31% margin).

**Domain:** company · **Geography/scope:** global · **Data as of:** 2024-12-31 · **Status:** draft

Sources: [[2025-02-05_howden-fy2024-results]]
