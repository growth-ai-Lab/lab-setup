---
type: knowledge
claim: Global cyber insurance rates are down ~22% from the mid-2022 peak, with combined ratios averaging ~70% and ~US$9bn underwriting profit across 2022-24.
domain: market
sources:
  - "[[2025-09-01_cyber-report-2025]]"
source_type: external
data_as_of: 2025-09-01
geography: global
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Global cyber insurance rates are down ~22% from the mid-2022 peak, with combined ratios averaging ~70% and ~US$9bn underwriting profit across 2022-24.

**Domain:** market · **Geography/scope:** global · **Data as of:** 2025-09-01 · **Status:** draft

Sources: [[2025-09-01_cyber-report-2025]]
