---
type: knowledge
claim: Howden UK & Ireland has 200+ high-street branches and ~6,500 employees, built largely via the A-Plan and Aston Lark acquisitions.
domain: company
sources:
  - "[[2023-09-26_howden-single-brand-reorg]]"
source_type: external
data_as_of: 2023-09-26
geography: uk
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Howden UK & Ireland has 200+ high-street branches and ~6,500 employees, built largely via the A-Plan and Aston Lark acquisitions.

**Domain:** company · **Geography/scope:** uk · **Data as of:** 2023-09-26 · **Status:** draft

Sources: [[2023-09-26_howden-single-brand-reorg]]
