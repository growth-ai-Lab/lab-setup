---
type: knowledge
claim: Howden Re delivered 30% organic revenue growth in FY2024.
domain: industry
sources:
  - "[[2025-02-05_howden-fy2024-results]]"
source_type: external
data_as_of: 2024-12-31
geography: global
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Howden Re delivered 30% organic revenue growth in FY2024.

**Domain:** industry · **Geography/scope:** global · **Data as of:** 2024-12-31 · **Status:** draft

Sources: [[2025-02-05_howden-fy2024-results]]
