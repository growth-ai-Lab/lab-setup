---
type: knowledge
claim: Howden operates broking, reinsurance broking (Howden Re) and underwriting (DUAL, an MGA), with Credit & Political Risk (CAP) inside Specialty since the 2023 single-brand reorganisation.
domain: company
sources:
  - "[[2023-09-26_howden-single-brand-reorg]]"
  - "[[2025-02-05_howden-fy2024-results]]"
source_type: external
data_as_of: 2023-09-26
geography: global
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Howden operates broking, reinsurance broking (Howden Re) and underwriting (DUAL, an MGA), with Credit & Political Risk (CAP) inside Specialty since the 2023 single-brand reorganisation.

**Domain:** company · **Geography/scope:** global · **Data as of:** 2023-09-26 · **Status:** draft

Sources: [[2023-09-26_howden-single-brand-reorg]], [[2025-02-05_howden-fy2024-results]]
