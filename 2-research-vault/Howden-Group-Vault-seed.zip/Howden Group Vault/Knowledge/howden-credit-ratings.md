---
type: knowledge
claim: Howden holds B2 (Moody's) / B (S&P) ratings; in Dec 2024 it repriced its US$2,925m and €900m Term Loan B tranches.
domain: company
sources:
  - "[[2025-02-05_howden-fy2024-results]]"
source_type: external
data_as_of: 2024-12-31
geography: global
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Howden holds B2 (Moody's) / B (S&P) ratings; in Dec 2024 it repriced its US$2,925m and €900m Term Loan B tranches.

**Domain:** company · **Geography/scope:** global · **Data as of:** 2024-12-31 · **Status:** draft

Sources: [[2025-02-05_howden-fy2024-results]]
