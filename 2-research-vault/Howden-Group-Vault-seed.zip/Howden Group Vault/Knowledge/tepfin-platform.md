---
type: knowledge
claim: Howden CAP's Tepfin trading platform (launched 2004) has facilitated 3,000+ transactions and US$8bn+ of capacity across 71 countries, and was Lloyd's-accredited in 2018 as the first broker-owned e-trading platform.
domain: company
sources:
  - "[[2026-07-01_cap-political-risks-page]]"
source_type: external
data_as_of: 2018-10-01
geography: global
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Howden CAP's Tepfin trading platform (launched 2004) has facilitated 3,000+ transactions and US$8bn+ of capacity across 71 countries, and was Lloyd's-accredited in 2018 as the first broker-owned e-trading platform.

**Domain:** company · **Geography/scope:** global · **Data as of:** 2018-10-01 · **Status:** draft

Sources: [[2026-07-01_cap-political-risks-page]]
