---
type: knowledge
claim: Howden was founded in 1994 by David Howden, originally as a wholesale insurance broker.
domain: company
sources:
  - "[[2026-07-01_howden-about-page]]"
source_type: external
data_as_of: 1994-01-01
geography: global
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Howden was founded in 1994 by David Howden, originally as a wholesale insurance broker.

**Domain:** company · **Geography/scope:** global · **Data as of:** 1994-01-01 · **Status:** draft

Sources: [[2026-07-01_howden-about-page]]
