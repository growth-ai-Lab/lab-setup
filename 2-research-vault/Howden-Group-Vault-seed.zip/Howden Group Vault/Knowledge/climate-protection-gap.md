---
type: knowledge
claim: In 2024 about 60% of catastrophe losses (~US$223bn) were uninsured, underscoring a large climate protection gap.
domain: gaps
sources:
  - "[[2026-06-01_csrd-article]]"
source_type: external
data_as_of: 2026-06-01
geography: global
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# In 2024 about 60% of catastrophe losses (~US$223bn) were uninsured, underscoring a large climate protection gap.

**Domain:** gaps · **Geography/scope:** global · **Data as of:** 2026-06-01 · **Status:** draft

Sources: [[2026-06-01_csrd-article]]
