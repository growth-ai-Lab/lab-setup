---
type: knowledge
claim: Hard-to-abate sectors under EU/UK CBAM need risk structuring for CCS and hydrogen projects to make them attractive to lenders and insurers.
domain: customer-needs
sources:
  - "[[2026-06-04_cbam-article]]"
source_type: external
data_as_of: 2026-06-04
geography: emea
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Hard-to-abate sectors under EU/UK CBAM need risk structuring for CCS and hydrogen projects to make them attractive to lenders and insurers.

**Domain:** customer-needs · **Geography/scope:** emea · **Data as of:** 2026-06-04 · **Status:** draft

Sources: [[2026-06-04_cbam-article]]
