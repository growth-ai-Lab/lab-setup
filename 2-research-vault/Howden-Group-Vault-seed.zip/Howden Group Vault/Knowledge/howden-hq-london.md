---
type: knowledge
claim: Howden Group Holdings is headquartered at One Creechurch Place, London EC3A 5AF, and describes itself as the largest independent employee-owned international broker.
domain: company
sources:
  - "[[2026-07-01_howden-about-page]]"
source_type: external
data_as_of: 2026-07-01
geography: global
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Howden Group Holdings is headquartered at One Creechurch Place, London EC3A 5AF, and describes itself as the largest independent employee-owned international broker.

**Domain:** company · **Geography/scope:** global · **Data as of:** 2026-07-01 · **Status:** draft

Sources: [[2026-07-01_howden-about-page]]
