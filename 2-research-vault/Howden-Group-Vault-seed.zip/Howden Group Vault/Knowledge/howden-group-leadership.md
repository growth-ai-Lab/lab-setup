---
type: knowledge
claim: David Howden CBE is Group CEO; Susan Panuccio became CFO (Jan 2026); David Shalders is COO; Mike Parrish is CEO Americas.
domain: company
sources:
  - "[[2026-07-01_howden-key-people-page]]"
source_type: external
data_as_of: 2026-07-01
geography: global
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# David Howden CBE is Group CEO; Susan Panuccio became CFO (Jan 2026); David Shalders is COO; Mike Parrish is CEO Americas.

**Domain:** company · **Geography/scope:** global · **Data as of:** 2026-07-01 · **Status:** draft

Sources: [[2026-07-01_howden-key-people-page]]
