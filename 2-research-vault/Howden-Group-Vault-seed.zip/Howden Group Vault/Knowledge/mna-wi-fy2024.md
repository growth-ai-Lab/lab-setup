---
type: knowledge
claim: Howden M&A placed 1,462 policies across 872 deals in FY2024, with €21.3bn of W&I limit and €131bn aggregate enterprise value advised.
domain: market
sources:
  - "[[2025-03-01_mna-annual-review-2025]]"
source_type: external
data_as_of: 2024-12-31
geography: emea
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Howden M&A placed 1,462 policies across 872 deals in FY2024, with €21.3bn of W&I limit and €131bn aggregate enterprise value advised.

**Domain:** market · **Geography/scope:** emea · **Data as of:** 2024-12-31 · **Status:** draft

Sources: [[2025-03-01_mna-annual-review-2025]]
