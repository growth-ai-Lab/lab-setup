---
type: knowledge
claim: Howden launched US retail broking in August 2025 (combining Atlantic Group and Gravitas), reaching 1,000+ colleagues and 50+ locations, led by CEO Mike Parrish.
domain: company
sources:
  - "[[2026-01-05_insurance-journal-ownership-ipo]]"
source_type: external
data_as_of: 2025-08-01
geography: us
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Howden launched US retail broking in August 2025 (combining Atlantic Group and Gravitas), reaching 1,000+ colleagues and 50+ locations, led by CEO Mike Parrish.

**Domain:** company · **Geography/scope:** us · **Data as of:** 2025-08-01 · **Status:** draft

Sources: [[2026-01-05_insurance-journal-ownership-ipo]]
