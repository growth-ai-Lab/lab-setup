---
type: knowledge
claim: Howden reported CY2025 adjusted revenue of £3.52bn; it moved its year-end from September to December, with a 15-month transition filing showing £4.23bn IFRS revenue.
domain: company
sources:
  - "[[2026-06-01_insurance-age-cy2025-revenue]]"
source_type: external
data_as_of: 2025-12-31
geography: global
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Howden reported CY2025 adjusted revenue of £3.52bn; it moved its year-end from September to December, with a 15-month transition filing showing £4.23bn IFRS revenue.

**Domain:** company · **Geography/scope:** global · **Data as of:** 2025-12-31 · **Status:** draft

Sources: [[2026-06-01_insurance-age-cy2025-revenue]]
