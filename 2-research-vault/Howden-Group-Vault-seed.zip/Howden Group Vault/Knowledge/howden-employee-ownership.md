---
type: knowledge
claim: Howden is employee-owned; staff collectively own >30% and there are ~5,300 employee-shareholders (2026), alongside General Atlantic, Hg and La Caisse.
domain: company
sources:
  - "[[2026-01-05_insurance-journal-ownership-ipo]]"
  - "[[2025-02-05_howden-fy2024-results]]"
source_type: external
data_as_of: 2026-01-05
geography: global
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Howden is employee-owned; staff collectively own >30% and there are ~5,300 employee-shareholders (2026), alongside General Atlantic, Hg and La Caisse.

**Domain:** company · **Geography/scope:** global · **Data as of:** 2026-01-05 · **Status:** draft

Sources: [[2026-01-05_insurance-journal-ownership-ipo]], [[2025-02-05_howden-fy2024-results]]
