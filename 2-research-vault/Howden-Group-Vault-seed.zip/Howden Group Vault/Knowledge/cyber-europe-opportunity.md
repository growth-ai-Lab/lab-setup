---
type: knowledge
claim: Cyber attacks cost ~€307bn across Germany, France, Italy and Spain over 2020-25; cyber-insurance penetration there is ~22-29% vs 39% in the UK, implying ~€1.2bn of premium upside.
domain: market
sources:
  - "[[2025-09-01_cyber-report-2025]]"
source_type: external
data_as_of: 2025-09-01
geography: europe
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Cyber attacks cost ~€307bn across Germany, France, Italy and Spain over 2020-25; cyber-insurance penetration there is ~22-29% vs 39% in the UK, implying ~€1.2bn of premium upside.

**Domain:** market · **Geography/scope:** europe · **Data as of:** 2025-09-01 · **Status:** draft

Sources: [[2025-09-01_cyber-report-2025]]
