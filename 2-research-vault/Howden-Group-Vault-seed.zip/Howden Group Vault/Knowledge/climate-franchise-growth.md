---
type: knowledge
claim: Climate Risk & Resilience is a stated growth pillar, evidenced by the CCS facility, first carbon-credit W&I policy, Climate Parametrics practice, and Gold Standard/Verra CORSIA gatekeeper appointments.
domain: growth-trajectory
sources:
  - "[[2024-01-29_ccs-facility-article]]"
  - "[[2024-06-21_carbon-credits-wi-article]]"
  - "[[2023-10-17_climate-parametrics-article]]"
  - "[[2025-07-17_gold-standard-corsia]]"
source_type: external
data_as_of: 2025-07-17
geography: global
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Climate Risk & Resilience is a stated growth pillar, evidenced by the CCS facility, first carbon-credit W&I policy, Climate Parametrics practice, and Gold Standard/Verra CORSIA gatekeeper appointments.

**Domain:** growth-trajectory · **Geography/scope:** global · **Data as of:** 2025-07-17 · **Status:** draft

Sources: [[2024-01-29_ccs-facility-article]], [[2024-06-21_carbon-credits-wi-article]], [[2023-10-17_climate-parametrics-article]], [[2025-07-17_gold-standard-corsia]]
