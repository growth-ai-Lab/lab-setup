---
type: knowledge
claim: Howden's equity was valued at ~£10bn in 2024 with an enterprise value approaching £20bn.
domain: company
sources:
  - "[[2026-01-05_insurance-journal-ownership-ipo]]"
  - "[[2025-02-05_howden-fy2024-results]]"
source_type: external
data_as_of: 2024-12-31
geography: global
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Howden's equity was valued at ~£10bn in 2024 with an enterprise value approaching £20bn.

**Domain:** company · **Geography/scope:** global · **Data as of:** 2024-12-31 · **Status:** draft

Sources: [[2026-01-05_insurance-journal-ownership-ipo]], [[2025-02-05_howden-fy2024-results]]
