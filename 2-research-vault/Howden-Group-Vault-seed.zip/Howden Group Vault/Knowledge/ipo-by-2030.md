---
type: knowledge
claim: David Howden has stated an intention to complete an IPO by 2030, without committing to a venue (an attributed intention, not a confirmed transaction).
domain: growth-trajectory
sources:
  - "[[2026-01-05_insurance-journal-ownership-ipo]]"
source_type: external
data_as_of: 2026-01-05
geography: global
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# David Howden has stated an intention to complete an IPO by 2030, without committing to a venue (an attributed intention, not a confirmed transaction).

**Domain:** growth-trajectory · **Geography/scope:** global · **Data as of:** 2026-01-05 · **Status:** draft

Sources: [[2026-01-05_insurance-journal-ownership-ipo]]
