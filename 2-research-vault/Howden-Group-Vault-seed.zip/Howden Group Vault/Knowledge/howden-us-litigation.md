---
type: knowledge
claim: Alliant, Aon, Marsh, WTW and Brown & Brown brought legal actions over Howden's US hiring; Brown & Brown cited ~275 departed staff and a revenue impact rising from US$23m to US$31m. These are reported allegations, not findings.
domain: company
sources:
  - "[[2026-01-28_insurance-journal-us-litigation]]"
source_type: external
data_as_of: 2026-01-28
geography: us
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Alliant, Aon, Marsh, WTW and Brown & Brown brought legal actions over Howden's US hiring; Brown & Brown cited ~275 departed staff and a revenue impact rising from US$23m to US$31m. These are reported allegations, not findings.

**Domain:** company · **Geography/scope:** us · **Data as of:** 2026-01-28 · **Status:** draft

Sources: [[2026-01-28_insurance-journal-us-litigation]]
