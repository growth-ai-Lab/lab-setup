---
type: knowledge
claim: London is the world's largest insurance market (>US$100bn premiums/yr) and is where Howden Specialty is headquartered and places complex risks.
domain: industry
sources:
  - "[[2023-11-01_specialty-overview-flexability-pdf]]"
source_type: external
data_as_of: 2023-11-01
geography: global
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# London is the world's largest insurance market (>US$100bn premiums/yr) and is where Howden Specialty is headquartered and places complex risks.

**Domain:** industry · **Geography/scope:** global · **Data as of:** 2023-11-01 · **Status:** draft

Sources: [[2023-11-01_specialty-overview-flexability-pdf]]
