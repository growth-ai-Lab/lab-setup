---
type: knowledge
claim: Howden completed its acquisition of UK pensions/employee-benefits firm Barnett Waddingham in April 2025.
domain: company
sources:
  - "[[2025-04-07_money-marketing-barnett-waddingham]]"
source_type: external
data_as_of: 2025-04-07
geography: uk
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Howden completed its acquisition of UK pensions/employee-benefits firm Barnett Waddingham in April 2025.

**Domain:** company · **Geography/scope:** uk · **Data as of:** 2025-04-07 · **Status:** draft

Sources: [[2025-04-07_money-marketing-barnett-waddingham]]
