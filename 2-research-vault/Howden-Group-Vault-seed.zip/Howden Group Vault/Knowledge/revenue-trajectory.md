---
type: knowledge
claim: Howden's adjusted revenue grew from £777m (FY2020) to £3.52bn (CY2025); Howden cites a four-year organic revenue CAGR of ~40%.
domain: growth-trajectory
sources:
  - "[[2022-01-20_insurance-times-fy2021]]"
  - "[[2023-01-30_insurance-business-fy2022]]"
  - "[[2025-02-05_howden-fy2024-results]]"
  - "[[2026-06-01_insurance-age-cy2025-revenue]]"
source_type: external
data_as_of: 2025-12-31
geography: global
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Howden's adjusted revenue grew from £777m (FY2020) to £3.52bn (CY2025); Howden cites a four-year organic revenue CAGR of ~40%.

**Domain:** growth-trajectory · **Geography/scope:** global · **Data as of:** 2025-12-31 · **Status:** draft

Sources: [[2022-01-20_insurance-times-fy2021]], [[2023-01-30_insurance-business-fy2022]], [[2025-02-05_howden-fy2024-results]], [[2026-06-01_insurance-age-cy2025-revenue]]
