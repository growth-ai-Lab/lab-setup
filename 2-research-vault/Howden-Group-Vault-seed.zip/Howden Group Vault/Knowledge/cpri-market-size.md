---
type: knowledge
claim: The credit & political risk plus surety market has a premium base of ~US$49bn across six product segments.
domain: market
sources:
  - "[[2025-06-01_cpri-report-2025]]"
source_type: external
data_as_of: 2025-06-01
geography: global
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# The credit & political risk plus surety market has a premium base of ~US$49bn across six product segments.

**Domain:** market · **Geography/scope:** global · **Data as of:** 2025-06-01 · **Status:** draft

Sources: [[2025-06-01_cpri-report-2025]]
