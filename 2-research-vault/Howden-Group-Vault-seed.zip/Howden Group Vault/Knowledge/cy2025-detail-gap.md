---
type: knowledge
claim: Howden's CY2025 EBITDA and divisional split are not public because of the one-off 15-month year-end transition; only headline revenue is available.
domain: gaps
sources:
  - "[[2026-06-01_insurance-age-cy2025-revenue]]"
source_type: external
data_as_of: 2025-12-31
geography: global
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Howden's CY2025 EBITDA and divisional split are not public because of the one-off 15-month year-end transition; only headline revenue is available.

**Domain:** gaps · **Geography/scope:** global · **Data as of:** 2025-12-31 · **Status:** draft

Sources: [[2026-06-01_insurance-age-cy2025-revenue]]
