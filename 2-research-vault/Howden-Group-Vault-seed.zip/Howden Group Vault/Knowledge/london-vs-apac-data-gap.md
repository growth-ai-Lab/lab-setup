---
type: knowledge
claim: Much of Howden's granular specialty performance data comes from Asia Pacific capability reports; equivalent London/global figures are not separately published, so APAC figures must not be read as global.
domain: gaps
sources:
  - "[[2023-10-01_marine-cargo-apac-pdf]]"
  - "[[2023-10-01_nr-construction-apac-pdf]]"
  - "[[2023-10-01_intl-property-apac-pdf]]"
source_type: external
data_as_of: 2023-10-01
geography: apac
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Much of Howden's granular specialty performance data comes from Asia Pacific capability reports; equivalent London/global figures are not separately published, so APAC figures must not be read as global.

**Domain:** gaps · **Geography/scope:** apac · **Data as of:** 2023-10-01 · **Status:** draft

Sources: [[2023-10-01_marine-cargo-apac-pdf]], [[2023-10-01_nr-construction-apac-pdf]], [[2023-10-01_intl-property-apac-pdf]]
