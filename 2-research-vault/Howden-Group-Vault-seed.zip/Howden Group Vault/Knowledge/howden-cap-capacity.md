---
type: knowledge
claim: Howden CAP has 90+ professionals and manages US$1bn+ of credit limits, with stated access to up to US$4bn Political Risk capacity and US$3.9bn Sovereign Non-Payment capacity.
domain: company
sources:
  - "[[2026-07-01_cap-political-risks-page]]"
source_type: external
data_as_of: 2026-07-01
geography: global
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Howden CAP has 90+ professionals and manages US$1bn+ of credit limits, with stated access to up to US$4bn Political Risk capacity and US$3.9bn Sovereign Non-Payment capacity.

**Domain:** company · **Geography/scope:** global · **Data as of:** 2026-07-01 · **Status:** draft

Sources: [[2026-07-01_cap-political-risks-page]]
