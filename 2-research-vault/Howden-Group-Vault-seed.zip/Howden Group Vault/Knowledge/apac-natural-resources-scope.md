---
type: knowledge
claim: In Asia Pacific, Howden Specialty's Natural Resources & Construction practice handles US$1.2bn+ premium annually with 95 specialists and 750+ clients — an APAC-hub scope, not global.
domain: company
sources:
  - "[[2023-10-01_nr-construction-apac-pdf]]"
source_type: external
data_as_of: 2023-10-01
geography: apac
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# In Asia Pacific, Howden Specialty's Natural Resources & Construction practice handles US$1.2bn+ premium annually with 95 specialists and 750+ clients — an APAC-hub scope, not global.

**Domain:** company · **Geography/scope:** apac · **Data as of:** 2023-10-01 · **Status:** draft

Sources: [[2023-10-01_nr-construction-apac-pdf]]
