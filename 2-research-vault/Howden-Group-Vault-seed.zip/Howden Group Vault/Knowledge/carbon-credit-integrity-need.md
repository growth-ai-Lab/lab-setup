---
type: knowledge
claim: Buyers need assurance of carbon-credit provenance and quality; Howden placed the first Carbon Credits W&I policy (Mere Plantations) to let credits sell at a premium.
domain: customer-needs
sources:
  - "[[2024-06-21_carbon-credits-wi-article]]"
source_type: external
data_as_of: 2024-06-21
geography: global
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Buyers need assurance of carbon-credit provenance and quality; Howden placed the first Carbon Credits W&I policy (Mere Plantations) to let credits sell at a premium.

**Domain:** customer-needs · **Geography/scope:** global · **Data as of:** 2024-06-21 · **Status:** draft

Sources: [[2024-06-21_carbon-credits-wi-article]]
