# Conventions
[origin: core — the contract every agent working in this vault is bound by]

Read this before writing anything to the vault. The full schema (frontmatter fields, examples) lives in
the initialization skill's `references/vault-structure.md`; this file is the operating contract in brief.

## Note types
- **Source** (`Sources/`) — one per external thing consulted. It is the origin; it cites nothing.
- **Knowledge** (`Knowledge/`) — one discrete verifiable claim, citing its Source(s).
- **Hypothesis** (`Hypotheses/`) — a testable claim built from Knowledge notes (not Sources directly).

The chain is always Source -> Knowledge -> Hypothesis.

## Required frontmatter
Every note carries provenance: `created_by`, `created_date`, `last_updated_by`, `last_updated`.
- Source: `type, title, domain, source_type, data_as_of, geography, review_status` (+ `url/author/published` if known)
- Knowledge: `type, claim, domain, sources, source_type, data_as_of, geography, review_status`
- Hypothesis: `type, claim, domain, evidence, falsification_criterion, addresses, status`

## Filenames
- `Sources/<yyyy-mm-dd>_<slug>.md`
- `Knowledge/<slug>.md`
- `Hypotheses/<slug>.md`
Slugs are lowercase, hyphen-separated, descriptive.

## review_status
- `draft` — captured, not yet verified against a live source. Default for anything new.
- `verified` — checked against a live source by a human or review pass. Never set without checking.
- `example` — shipped teaching example; never counted as evidence.

## Geography / scope
Record the geographic or entity scope of every source and claim in `geography`
(global | region e.g. apac/emea/europe | country e.g. uk/us | single-entity), inheriting it from source
to knowledge. Never present a region- or subsidiary-specific figure (e.g. an "APAC capability report")
as a global or whole-company fact — flag the mismatch. See `research-method.md` for the full playbook.

## Domains
One `domain` per note, drawn only from `Meta/Taxonomy.md`. Never invent a domain in a note.

## MOCs
No global index. Each domain has one MOC in `MOCs/`. Add every new note to its domain's MOC, and check
the MOC before creating a note to avoid duplicates.

## No cascade edits
When new information contradicts an existing note, flag it — add a `> [!review]` callout naming the
conflicting note and date, and lower `review_status` to `draft` if it was `verified`. Never silently
rewrite another note. A human or review pass resolves it.

## Multi-agent boot protocol
Before writing anything, an agent must: (1) read `Meta/Taxonomy.md` and this file; (2) check the relevant
domain MOC; (3) never invent a domain, skip provenance, mark `verified` without a live source, or cascade-edit.
