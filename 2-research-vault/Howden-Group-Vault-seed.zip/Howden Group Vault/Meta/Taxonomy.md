# Taxonomy
[origin: core — the controlled list of domains for this vault]

Every note is tagged with exactly one `domain`, drawn only from this list. Never invent a new
domain in a note; new domains are appended here with explicit user approval, recording who added
the entry and when.

## Domains
- `company` — Howden's own company: identity, ownership, financials, divisions, leadership, footprint.
- `industry` — the broader insurance-broking industry / market structure Howden operates in.
- `market` — market size, segments, dynamics, pricing, demand signals across Howden's lines.
- `customer-needs` — client jobs-to-be-done, pain points, unmet needs.
- `gaps` — where the market or the company falls short; whitespace and open questions.
- `growth-trajectory` — trends, momentum, M&A, forecasts, growth levers.

## Change log
- 2026-07-13 — seeded with the six default domains (research-agent).
