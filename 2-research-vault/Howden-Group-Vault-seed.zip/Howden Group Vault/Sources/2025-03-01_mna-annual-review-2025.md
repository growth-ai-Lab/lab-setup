---
type: source
title: Howden M&A Annual Review 2025 (FY2024 data, PDF)
domain: market
source_type: report
url: https://www.howdengroup.com/sites/huk.howdenprod.com/files/2025-03/howden-m-and-a-2025-annual-review.pdf
author: Howden M&A
published: 2025-03-01
data_as_of: 2024-12-31
geography: emea
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Howden M&A Annual Review 2025 (FY2024 data, PDF)

External source consulted during the Howden research. See linked Knowledge notes for the discrete claims drawn from it.

- **Publisher/author:** Howden M&A
- **Published:** 2025-03-01
- **Data as of:** 2024-12-31
- **Geographic scope:** emea
- **URL:** https://www.howdengroup.com/sites/huk.howdenprod.com/files/2025-03/howden-m-and-a-2025-annual-review.pdf
