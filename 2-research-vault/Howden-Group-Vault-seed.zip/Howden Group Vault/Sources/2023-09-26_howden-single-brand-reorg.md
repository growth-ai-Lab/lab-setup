---
type: source
title: Howden to unify business under single management structure
domain: company
source_type: press-release
url: https://www.howdengroupholdings.com/news-insights/howden-to-unify-business-under-single-management-structure
author: Howden Group Holdings
published: 2023-09-26
data_as_of: 2023-09-26
geography: global
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Howden to unify business under single management structure

External source consulted during the Howden research. See linked Knowledge notes for the discrete claims drawn from it.

- **Publisher/author:** Howden Group Holdings
- **Published:** 2023-09-26
- **Data as of:** 2023-09-26
- **Geographic scope:** global
- **URL:** https://www.howdengroupholdings.com/news-insights/howden-to-unify-business-under-single-management-structure
