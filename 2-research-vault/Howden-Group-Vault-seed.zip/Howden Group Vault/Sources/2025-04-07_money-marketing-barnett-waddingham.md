---
type: source
title: Money Marketing — Howden completes Barnett Waddingham acquisition
domain: company
source_type: article
url: https://www.moneymarketing.co.uk/news/howden-completes-acquisition-of-barnett-waddingham/
author: Money Marketing
published: 2025-04-07
data_as_of: 2025-04-07
geography: uk
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Money Marketing — Howden completes Barnett Waddingham acquisition

External source consulted during the Howden research. See linked Knowledge notes for the discrete claims drawn from it.

- **Publisher/author:** Money Marketing
- **Published:** 2025-04-07
- **Data as of:** 2025-04-07
- **Geographic scope:** uk
- **URL:** https://www.moneymarketing.co.uk/news/howden-completes-acquisition-of-barnett-waddingham/
