# Sources

One note per external source consulted. A Source cites nothing — it is the origin of claims.
