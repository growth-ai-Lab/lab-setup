---
type: source
title: Howden Group Holdings — Key People
domain: company
source_type: webpage
url: https://www.howdengroupholdings.com/about-us/key-people
author: Howden Group Holdings
published: 
data_as_of: 2026-07-01
geography: global
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Howden Group Holdings — Key People

External source consulted during the Howden research. See linked Knowledge notes for the discrete claims drawn from it.

- **Publisher/author:** Howden Group Holdings
- **Published:** n/a
- **Data as of:** 2026-07-01
- **Geographic scope:** global
- **URL:** https://www.howdengroupholdings.com/about-us/key-people
