---
type: source
title: Insurance Age — Howden revenue topped £3.5bn in 2025
domain: growth-trajectory
source_type: article
url: https://www.insuranceage.co.uk/insight/7958529/howden-reveals-revenue-topped-ps35bn-in-2025
author: Insurance Age
published: 2026-06-01
data_as_of: 2025-12-31
geography: global
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Insurance Age — Howden revenue topped £3.5bn in 2025

External source consulted during the Howden research. See linked Knowledge notes for the discrete claims drawn from it.

- **Publisher/author:** Insurance Age
- **Published:** 2026-06-01
- **Data as of:** 2025-12-31
- **Geographic scope:** global
- **URL:** https://www.insuranceage.co.uk/insight/7958529/howden-reveals-revenue-topped-ps35bn-in-2025
