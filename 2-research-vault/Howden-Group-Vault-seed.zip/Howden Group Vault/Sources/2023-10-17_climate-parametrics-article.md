---
type: source
title: Howden launches Howden Climate Parametrics practice
domain: growth-trajectory
source_type: press-release
url: https://www.howdengroup.com/uk-en/howden-launches-climate-parametric
author: Howden
published: 2023-10-17
data_as_of: 2023-10-17
geography: global
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Howden launches Howden Climate Parametrics practice

External source consulted during the Howden research. See linked Knowledge notes for the discrete claims drawn from it.

- **Publisher/author:** Howden
- **Published:** 2023-10-17
- **Data as of:** 2023-10-17
- **Geographic scope:** global
- **URL:** https://www.howdengroup.com/uk-en/howden-launches-climate-parametric
