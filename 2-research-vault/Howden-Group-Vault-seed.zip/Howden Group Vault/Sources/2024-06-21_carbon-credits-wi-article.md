---
type: source
title: Howden launches first Carbon Credits W&I policy (Mere Plantations)
domain: customer-needs
source_type: press-release
url: https://www.howdengroup.com/uk-en/news-insights/howden-launches-first-its-kind-warranty-indemnity-policy-sale-mere-plantations-carbon-credits
author: Howden
published: 2024-06-21
data_as_of: 2024-06-21
geography: global
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Howden launches first Carbon Credits W&I policy (Mere Plantations)

External source consulted during the Howden research. See linked Knowledge notes for the discrete claims drawn from it.

- **Publisher/author:** Howden
- **Published:** 2024-06-21
- **Data as of:** 2024-06-21
- **Geographic scope:** global
- **URL:** https://www.howdengroup.com/uk-en/news-insights/howden-launches-first-its-kind-warranty-indemnity-policy-sale-mere-plantations-carbon-credits
