---
type: source
title: Howden to acquire Evelyn Partners' employee-benefits arm
domain: company
source_type: press-release
url: https://www.howdengroupholdings.com/news/howden-to-acquire-the-employee-benefits-consultancy-arm-of-evelyn-partners
author: Howden Group Holdings
published: 2025-11-11
data_as_of: 2025-11-11
geography: uk
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Howden to acquire Evelyn Partners' employee-benefits arm

External source consulted during the Howden research. See linked Knowledge notes for the discrete claims drawn from it.

- **Publisher/author:** Howden Group Holdings
- **Published:** 2025-11-11
- **Data as of:** 2025-11-11
- **Geographic scope:** uk
- **URL:** https://www.howdengroupholdings.com/news/howden-to-acquire-the-employee-benefits-consultancy-arm-of-evelyn-partners
