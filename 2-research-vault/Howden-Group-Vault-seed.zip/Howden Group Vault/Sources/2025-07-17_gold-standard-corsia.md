---
type: source
title: Howden partners with Gold Standard on CORSIA carbon-credit insurance
domain: growth-trajectory
source_type: press-release
url: https://www.howdengroup.com/uk-en/news-insights/howden-partners-with-gold-standard-to-assess-insurance-policies-for-aviation-carbon-credit-scheme
author: Howden
published: 2025-07-17
data_as_of: 2025-07-17
geography: global
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Howden partners with Gold Standard on CORSIA carbon-credit insurance

External source consulted during the Howden research. See linked Knowledge notes for the discrete claims drawn from it.

- **Publisher/author:** Howden
- **Published:** 2025-07-17
- **Data as of:** 2025-07-17
- **Geographic scope:** global
- **URL:** https://www.howdengroup.com/uk-en/news-insights/howden-partners-with-gold-standard-to-assess-insurance-policies-for-aviation-carbon-credit-scheme
