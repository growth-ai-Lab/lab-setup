---
type: source
title: Introducing our Construction Practice (PDF)
domain: company
source_type: report
url: https://www.howdengroup.com/sites/huk.howdenprod.com/files/2022-11/Construction-Brochure-September-2022.pdf
author: Howden Specialty
published: 2022-09-01
data_as_of: 2022-09-01
geography: global
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Introducing our Construction Practice (PDF)

External source consulted during the Howden research. See linked Knowledge notes for the discrete claims drawn from it.

- **Publisher/author:** Howden Specialty
- **Published:** 2022-09-01
- **Data as of:** 2022-09-01
- **Geographic scope:** global
- **URL:** https://www.howdengroup.com/sites/huk.howdenprod.com/files/2022-11/Construction-Brochure-September-2022.pdf
