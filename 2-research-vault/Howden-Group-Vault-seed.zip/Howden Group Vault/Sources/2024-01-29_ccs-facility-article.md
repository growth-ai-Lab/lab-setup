---
type: source
title: Howden launches first-of-its-kind CCS insurance facility
domain: market
source_type: press-release
url: https://www.howdengroup.com/uk-en/news/howden-launches-first-of-its-kind-carbon-capture-and-storage-insurance-facility
author: Howden
published: 2024-01-29
data_as_of: 2024-01-29
geography: global
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Howden launches first-of-its-kind CCS insurance facility

External source consulted during the Howden research. See linked Knowledge notes for the discrete claims drawn from it.

- **Publisher/author:** Howden
- **Published:** 2024-01-29
- **Data as of:** 2024-01-29
- **Geographic scope:** global
- **URL:** https://www.howdengroup.com/uk-en/news/howden-launches-first-of-its-kind-carbon-capture-and-storage-insurance-facility
