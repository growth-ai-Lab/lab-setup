---
type: source
title: Howden announces 2024 full-year results
domain: company
source_type: press-release
url: https://www.howdengroupholdings.com/news/howden-announces-2024-full-year-results
author: Howden Group Holdings
published: 2025-02-05
data_as_of: 2024-12-31
geography: global
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Howden announces 2024 full-year results

External source consulted during the Howden research. See linked Knowledge notes for the discrete claims drawn from it.

- **Publisher/author:** Howden Group Holdings
- **Published:** 2025-02-05
- **Data as of:** 2024-12-31
- **Geographic scope:** global
- **URL:** https://www.howdengroupholdings.com/news/howden-announces-2024-full-year-results
