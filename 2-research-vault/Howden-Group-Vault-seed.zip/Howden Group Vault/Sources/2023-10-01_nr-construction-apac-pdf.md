---
type: source
title: Howden Specialty APAC — Natural Resources & Construction (PDF)
domain: company
source_type: report
url: https://www.howdengroup.com/sites/huk.howdenprod.com/files/2023-10/natural_resources_construction_apac_digital.pdf
author: Howden Specialty Asia Pacific
published: 2023-10-01
data_as_of: 2023-10-01
geography: apac
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Howden Specialty APAC — Natural Resources & Construction (PDF)

External source consulted during the Howden research. See linked Knowledge notes for the discrete claims drawn from it.

- **Publisher/author:** Howden Specialty Asia Pacific
- **Published:** 2023-10-01
- **Data as of:** 2023-10-01
- **Geographic scope:** apac
- **URL:** https://www.howdengroup.com/sites/huk.howdenprod.com/files/2023-10/natural_resources_construction_apac_digital.pdf
