---
type: source
title: Insurance Journal — Howden ownership, valuation and IPO plans
domain: company
source_type: article
url: https://www.insurancejournal.com/news/national/2026/01/05/853065.htm
author: Insurance Journal
published: 2026-01-05
data_as_of: 2026-01-05
geography: global
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Insurance Journal — Howden ownership, valuation and IPO plans

External source consulted during the Howden research. See linked Knowledge notes for the discrete claims drawn from it.

- **Publisher/author:** Insurance Journal
- **Published:** 2026-01-05
- **Data as of:** 2026-01-05
- **Geographic scope:** global
- **URL:** https://www.insurancejournal.com/news/national/2026/01/05/853065.htm
