---
type: source
title: Insurance Times — Howden FY2021 results
domain: growth-trajectory
source_type: article
url: https://www.insurancetimes.co.uk/news/howden-group-boosts-revenue-by-48-in-2021-thanks-to-organic-growth-uptick/1440064.article
author: Insurance Times
published: 2022-01-20
data_as_of: 2021-09-30
geography: global
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Insurance Times — Howden FY2021 results

External source consulted during the Howden research. See linked Knowledge notes for the discrete claims drawn from it.

- **Publisher/author:** Insurance Times
- **Published:** 2022-01-20
- **Data as of:** 2021-09-30
- **Geographic scope:** global
- **URL:** https://www.insurancetimes.co.uk/news/howden-group-boosts-revenue-by-48-in-2021-thanks-to-organic-growth-uptick/1440064.article
