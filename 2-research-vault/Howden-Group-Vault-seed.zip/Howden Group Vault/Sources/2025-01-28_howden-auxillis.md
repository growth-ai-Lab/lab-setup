---
type: source
title: Howden strategic partnership with Auxillis (non-fault motor claims)
domain: customer-needs
source_type: press-release
url: https://www.howdengroup.com/uk-en/news-insights/howden-announces-strategic-partnership-auxillis-enhance-services-commercial-and-sme-clients
author: Howden
published: 2025-01-28
data_as_of: 2025-01-28
geography: uk
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Howden strategic partnership with Auxillis (non-fault motor claims)

External source consulted during the Howden research. See linked Knowledge notes for the discrete claims drawn from it.

- **Publisher/author:** Howden
- **Published:** 2025-01-28
- **Data as of:** 2025-01-28
- **Geographic scope:** uk
- **URL:** https://www.howdengroup.com/uk-en/news-insights/howden-announces-strategic-partnership-auxillis-enhance-services-commercial-and-sme-clients
