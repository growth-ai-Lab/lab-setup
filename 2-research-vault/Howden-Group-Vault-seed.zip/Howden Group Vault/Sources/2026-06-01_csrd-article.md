---
type: source
title: Changes in EU sustainability reporting — what SMEs need to know
domain: market
source_type: article
url: https://www.howdengroup.com/uk-en/news-insights/crsd-omnibus-explained-what-smes-need-to-know
author: Howden UK
published: 2026-06-01
data_as_of: 2026-06-01
geography: emea
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Changes in EU sustainability reporting — what SMEs need to know

External source consulted during the Howden research. See linked Knowledge notes for the discrete claims drawn from it.

- **Publisher/author:** Howden UK
- **Published:** 2026-06-01
- **Data as of:** 2026-06-01
- **Geographic scope:** emea
- **URL:** https://www.howdengroup.com/uk-en/news-insights/crsd-omnibus-explained-what-smes-need-to-know
