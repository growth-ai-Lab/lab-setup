---
type: source
title: Insurance Business — Howden FY2022 results
domain: growth-trajectory
source_type: article
url: https://www.insurancebusinessmag.com/us/news/breaking-news/howden-group-announces-fullyear-financial-results-434376.aspx
author: Insurance Business
published: 2023-01-30
data_as_of: 2022-09-30
geography: global
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Insurance Business — Howden FY2022 results

External source consulted during the Howden research. See linked Knowledge notes for the discrete claims drawn from it.

- **Publisher/author:** Insurance Business
- **Published:** 2023-01-30
- **Data as of:** 2022-09-30
- **Geographic scope:** global
- **URL:** https://www.insurancebusinessmag.com/us/news/breaking-news/howden-group-announces-fullyear-financial-results-434376.aspx
