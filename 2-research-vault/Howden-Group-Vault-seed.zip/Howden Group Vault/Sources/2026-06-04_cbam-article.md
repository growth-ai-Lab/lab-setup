---
type: source
title: Carbon borders & competitiveness — CBAM and hard-to-abate sectors
domain: customer-needs
source_type: article
url: https://www.howdengroup.com/uk-en/news-insights/carbon-border-rules-eu-uk-market-access-hard-to-abate-sectors
author: Howden UK
published: 2026-06-04
data_as_of: 2026-06-04
geography: emea
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Carbon borders & competitiveness — CBAM and hard-to-abate sectors

External source consulted during the Howden research. See linked Knowledge notes for the discrete claims drawn from it.

- **Publisher/author:** Howden UK
- **Published:** 2026-06-04
- **Data as of:** 2026-06-04
- **Geographic scope:** emea
- **URL:** https://www.howdengroup.com/uk-en/news-insights/carbon-border-rules-eu-uk-market-access-hard-to-abate-sectors
