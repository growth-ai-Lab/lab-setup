---
type: source
title: Howden Specialty — Terrorism & Political Violence brochure (PDF)
domain: company
source_type: report
url: https://www.howdengroup.com/sites/huk.howdenprod.com/files/2024-01/h274272_p628410_5409_howden_specialty_terrorism_political_violence_non_us_brochure_digital_digital_2024update.pdf
author: Howden Specialty
published: 2024-01-01
data_as_of: 2024-01-01
geography: global
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Howden Specialty — Terrorism & Political Violence brochure (PDF)

External source consulted during the Howden research. See linked Knowledge notes for the discrete claims drawn from it.

- **Publisher/author:** Howden Specialty
- **Published:** 2024-01-01
- **Data as of:** 2024-01-01
- **Geographic scope:** global
- **URL:** https://www.howdengroup.com/sites/huk.howdenprod.com/files/2024-01/h274272_p628410_5409_howden_specialty_terrorism_political_violence_non_us_brochure_digital_digital_2024update.pdf
