---
type: source
title: Howden UK — Political Risks & Structured Credit (CAP)
domain: company
source_type: webpage
url: https://www.howdengroup.com/uk-en/cover/political-risks-structured-credit-insurance
author: Howden
published: 
data_as_of: 2026-07-01
geography: global
review_status: draft
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Howden UK — Political Risks & Structured Credit (CAP)

External source consulted during the Howden research. See linked Knowledge notes for the discrete claims drawn from it.

- **Publisher/author:** Howden
- **Published:** n/a
- **Data as of:** 2026-07-01
- **Geographic scope:** global
- **URL:** https://www.howdengroup.com/uk-en/cover/political-risks-structured-credit-insurance
