# Gaps
[origin: core MOC — entry point for the `gaps` domain]

Where the market or company falls short; whitespace and open questions.

## Knowledge
- [[climate-protection-gap]]
- [[cy2025-detail-gap]]
- [[london-vs-apac-data-gap]]

## Hypotheses
- [[sme-embedded-cyber-ir]]
