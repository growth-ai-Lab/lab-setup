# Customer-Needs
[origin: core MOC — entry point for the `customer-needs` domain]

Client jobs-to-be-done, pain points and unmet needs Howden addresses.

## Knowledge
- [[sme-cyber-need]]
- [[carbon-credit-integrity-need]]
- [[decarbonisation-project-risk-need]]
- [[non-fault-motor-need]]
- [[pi-financial-adviser-trends]]

## Hypotheses
- (none yet)
