# Market
[origin: core MOC — entry point for the `market` domain]

Market size, dynamics, pricing and demand signals across Howden's lines.

## Knowledge
- [[cyber-market-state-2025]]
- [[cpri-market-size]]
- [[do-market-softening]]
- [[cyber-europe-opportunity]]
- [[physical-risk-premium-2030]]
- [[ccs-insurance-market-2030]]
- [[mna-wi-fy2024]]

## Hypotheses
- [[parametric-cloud-outage]]
- [[ai-liability-line]]
- [[critical-minerals-cpri]]
