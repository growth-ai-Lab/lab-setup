# Industry
[origin: core MOC — entry point for the `industry` domain]

The broader insurance-broking industry and market structure Howden operates in.

## Knowledge
- [[london-market-scale]]
- [[reinsurance-organic-growth]]

## Hypotheses
- (none yet)
