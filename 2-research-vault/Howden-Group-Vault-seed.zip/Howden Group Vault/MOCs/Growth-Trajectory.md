# Growth-Trajectory
[origin: core MOC — entry point for the `growth-trajectory` domain]

Trends, momentum, M&A, and growth levers over time.

## Knowledge
- [[revenue-trajectory]]
- [[ipo-by-2030]]
- [[climate-franchise-growth]]
- [[geographic-expansion]]

## Hypotheses
- [[carbon-credit-wi-scaling]]
- [[ccs-scale-cover]]
- [[climate-parametrics-brand-vs-revenue]]
- [[us-retail-scale]]
