# Company
[origin: core MOC — entry point for the `company` domain]

Howden's own company: identity, ownership, financials, divisions, leadership, footprint.

## Knowledge
- [[howden-founded-1994]]
- [[howden-employee-ownership]]
- [[howden-hq-london]]
- [[howden-premium-under-mgmt]]
- [[howden-fy2024-revenue]]
- [[howden-cy2025-revenue]]
- [[howden-valuation-2024]]
- [[howden-credit-ratings]]
- [[howden-divisions]]
- [[howden-uk-retail-footprint]]
- [[howden-cap-capacity]]
- [[tepfin-platform]]
- [[howden-us-launch]]
- [[howden-us-litigation]]
- [[howden-group-leadership]]
- [[howden-mna-volume-fy2024]]
- [[acq-barnett-waddingham]]
- [[acq-evelyn-partners-epfs]]
- [[apac-marine-cargo-scope]]
- [[apac-natural-resources-scope]]
- [[apac-intl-property-scope]]

## Hypotheses
- (none yet)
