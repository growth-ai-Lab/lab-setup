---
type: hypothesis
claim: Organic US retail build-out will drive the group's next growth phase despite competitor litigation.
domain: growth-trajectory
evidence:
  - "[[howden-us-launch]]"
  - "[[revenue-trajectory]]"
  - "[[geographic-expansion]]"
falsification_criterion: the US book fails to scale or litigation materially impairs the launch.
addresses: US market entry / growth trajectory
status: proposed
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Organic US retail build-out will drive the group's next growth phase despite competitor litigation.

**Domain:** growth-trajectory · **Status:** proposed

**Falsification criterion:** the US book fails to scale or litigation materially impairs the launch.

**Addresses:** US market entry / growth trajectory

Evidence: [[howden-us-launch]], [[revenue-trajectory]], [[geographic-expansion]]
