# Hypotheses

Testable claims built from Knowledge notes (never Sources directly), each with a falsification criterion.
