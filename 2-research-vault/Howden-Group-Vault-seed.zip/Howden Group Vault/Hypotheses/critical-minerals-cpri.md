---
type: hypothesis
claim: CPRI demand grows with critical-minerals competition and geopolitical volatility.
domain: market
evidence:
  - "[[cpri-market-size]]"
falsification_criterion: CPRI premium growth continues to lag other specialty lines.
addresses: cross-border trade & investment risk
status: proposed
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# CPRI demand grows with critical-minerals competition and geopolitical volatility.

**Domain:** market · **Status:** proposed

**Falsification criterion:** CPRI premium growth continues to lag other specialty lines.

**Addresses:** cross-border trade & investment risk

Evidence: [[cpri-market-size]]
