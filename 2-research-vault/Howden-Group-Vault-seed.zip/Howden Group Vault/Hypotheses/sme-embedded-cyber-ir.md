---
type: hypothesis
claim: Embedding incident-response into SME cyber cover will capture underserved demand and lift retention.
domain: gaps
evidence:
  - "[[sme-cyber-need]]"
  - "[[cyber-europe-opportunity]]"
  - "[[cyber-market-state-2025]]"
falsification_criterion: SME cyber attach rates and Cyber+ retention do not rise materially over 2-3 years.
addresses: the SME cyber protection gap
status: proposed
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# Embedding incident-response into SME cyber cover will capture underserved demand and lift retention.

**Domain:** gaps · **Status:** proposed

**Falsification criterion:** SME cyber attach rates and Cyber+ retention do not rise materially over 2-3 years.

**Addresses:** the SME cyber protection gap

Evidence: [[sme-cyber-need]], [[cyber-europe-opportunity]], [[cyber-market-state-2025]]
