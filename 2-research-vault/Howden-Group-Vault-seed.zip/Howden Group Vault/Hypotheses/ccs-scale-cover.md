---
type: hypothesis
claim: CCS leakage cover scales as hub-and-cluster projects mature, supported by CBAM incentives.
domain: growth-trajectory
evidence:
  - "[[decarbonisation-project-risk-need]]"
  - "[[ccs-insurance-market-2030]]"
falsification_criterion: CCS project pipeline stalls and the facility writes little premium.
addresses: decarbonisation project risk
status: proposed
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# CCS leakage cover scales as hub-and-cluster projects mature, supported by CBAM incentives.

**Domain:** growth-trajectory · **Status:** proposed

**Falsification criterion:** CCS project pipeline stalls and the facility writes little premium.

**Addresses:** decarbonisation project risk

Evidence: [[decarbonisation-project-risk-need]], [[ccs-insurance-market-2030]]
