---
type: hypothesis
claim: AI liability / model-risk cover is an emerging revenue line as AI-linked claims rise.
domain: market
evidence:
  - "[[do-market-softening]]"
falsification_criterion: AI-liability demand fails to materialise into placeable premium.
addresses: AI/model-risk exposure for mid-large B2B
status: proposed
created_by: research-agent
created_date: 2026-07-13
last_updated_by: research-agent
last_updated: 2026-07-13
---

# AI liability / model-risk cover is an emerging revenue line as AI-linked claims rise.

**Domain:** market · **Status:** proposed

**Falsification criterion:** AI-liability demand fails to materialise into placeable premium.

**Addresses:** AI/model-risk exposure for mid-large B2B

Evidence: [[do-market-softening]]
